'use strict';

document.addEventListener('DOMContentLoaded', function () {
  // 危险操作二次确认
  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (form instanceof HTMLFormElement && form.dataset.confirm) {
      if (!window.confirm(form.dataset.confirm)) {
        event.preventDefault();
      }
    }
  });

  // 复制分享链接
  document.querySelectorAll('[data-copy]').forEach(function (button) {
    button.addEventListener('click', function () {
      var target = document.querySelector(button.dataset.copy);
      var text = target ? target.value : button.dataset.copyText;
      if (!text) return;
      var done = function () {
        var original = button.textContent;
        button.textContent = '已复制';
        window.setTimeout(function () { button.textContent = original; }, 1600);
      };
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done).catch(function () {});
      } else if (target) {
        target.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
      }
    });
  });

  // 上传区：显示所选文件名
  document.querySelectorAll('[data-drop]').forEach(function (zone) {
    var input = zone.querySelector('input[type="file"]');
    var label = zone.querySelector('[data-drop-file]');
    if (!input) return;
    var show = function () {
      if (input.files && input.files.length > 0) {
        var names = [];
        var total = 0;
        for (var i = 0; i < input.files.length; i++) {
          names.push(input.files[i].name);
          total += input.files[i].size;
        }
        if (label) {
          label.textContent = names.join('、') + '（' + formatSize(total) + '）';
        }
      }
    };
    input.addEventListener('change', show);
    zone.addEventListener('click', function (event) {
      if (event.target !== input) input.click();
    });
    ['dragenter', 'dragover'].forEach(function (name) {
      zone.addEventListener(name, function (event) {
        event.preventDefault();
        zone.classList.add('is-over');
      });
    });
    ['dragleave', 'drop'].forEach(function (name) {
      zone.addEventListener(name, function (event) {
        event.preventDefault();
        zone.classList.remove('is-over');
      });
    });
    zone.addEventListener('drop', function (event) {
      if (event.dataTransfer && event.dataTransfer.files.length) {
        input.files = event.dataTransfer.files;
        show();
      }
    });
  });

  // 密码可见性
  document.querySelectorAll('[data-toggle-password]').forEach(function (button) {
    button.addEventListener('click', function () {
      var input = document.querySelector(button.dataset.togglePassword);
      if (!input) return;
      var isPassword = input.type === 'password';
      input.type = isPassword ? 'text' : 'password';
      button.textContent = isPassword ? '隐藏' : '显示';
    });
  });
});

function formatSize(bytes) {
  if (bytes <= 0) return '0 B';
  var units = ['B', 'KB', 'MB', 'GB', 'TB'];
  var i = Math.floor(Math.log(bytes) / Math.log(1024));
  i = Math.min(i, units.length - 1);
  return (bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1) + ' ' + units[i];
}

<?php
declare(strict_types=1);

/**
 * 蜜罐入口
 * 前台页脚有一个正常用户不可见的链接指向这里，只有自动抓取程序会跟进。
 * 访问即视为采集行为：记录并封禁，对外返回普通 404，不暴露拦截逻辑。
 */
require dirname(__DIR__) . '/app/bootstrap.php';

antibot_log('honeypot', '/trap.php');
antibot_ban_current('honeypot', max(60, setting_int('antibot_ban_minutes', 60)));

http_response_code(404);
header('Content-Type: text/html; charset=utf-8');
echo '<!doctype html><html lang="en"><meta charset="utf-8"><title>404 Not Found</title>'
    . '<div style="max-width:480px;margin:18vh auto;font:15px/1.7 system-ui,sans-serif;color:#667085;text-align:center">'
    . '<h1 style="font-size:22px;color:#101828">404</h1><p>The page you requested could not be found.</p>'
    . '</div></html>';

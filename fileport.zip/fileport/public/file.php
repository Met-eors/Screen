<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

$token = (string) ($_GET['id'] ?? '');
$file  = find_file_by_token($token);
if (!$file) {
    http_response_code(404);
    $pageTitle = '文件不存在';
    require APP_PATH . '/views/header.php';
    echo '<div class="card"><div class="empty"><div class="empty-icon">' . icon('close', 22) . '</div>'
        . '<div class="empty-title">文件不存在</div><div class="empty-text">链接可能已失效，或文件已被删除。</div>'
        . '<div style="margin-top:18px"><a class="btn" href="' . e(url('/index.php')) . '">返回文件库</a></div></div></div>';
    require APP_PATH . '/views/footer.php';
    exit;
}

$viewer    = current_user();
$canManage = is_admin();
$isOwner   = $viewer !== null && $file['user_id'] !== null && (int) $file['user_id'] === (int) $viewer['id'];
$canShare  = ($canManage || $isOwner) && (int) $file['status'] !== 2;

if (((int) $file['status'] !== 1 || (int) $file['is_public'] !== 1) && !$canManage && !$isOwner) {
    http_response_code(403);
    $pageTitle = '文件不可访问';
    require APP_PATH . '/views/header.php';
    echo '<div class="card"><div class="empty"><div class="empty-icon">' . icon('lock', 22) . '</div>'
        . '<div class="empty-title">该文件暂不可访问</div><div class="empty-text">文件已下架或设为私有，仅管理员可见。</div>'
        . '<div style="margin-top:18px"><a class="btn" href="' . e(url('/index.php')) . '">返回文件库</a></div></div></div>';
    require APP_PATH . '/views/footer.php';
    exit;
}

// 管理员在本页创建分享链接
$newShareUrl = '';
if ($canShare && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['action'] ?? '') === 'create_share') {
    $password  = trim((string) ($_POST['share_password'] ?? ''));
    $days      = max(0, min(365, (int) ($_POST['expires_days'] ?? 0)));
    $maxDl     = max(0, min(100000, (int) ($_POST['max_downloads'] ?? 0)));
    $expiresAt = $days > 0 ? date('Y-m-d H:i:s', time() + $days * 86400) : null;

    if ($password !== '' && strlen($password) < 4) {
        flash('error', '分享密码至少 4 个字符。');
    } else {
        $share = create_share((int) $file['id'], $password, $expiresAt, $maxDl, (int) (current_user()['id'] ?? 0));
        $_SESSION['last_share'] = $share['token'];
        flash('success', '分享链接已创建。');
    }
    redirect('/file.php?id=' . $file['token']);
}

if (!empty($_SESSION['last_share'])) {
    $newShareUrl = url('/s.php?t=' . $_SESSION['last_share']);
}

$color = ext_color((string) $file['ext']);
$pageTitle = $file['title'];
$activeNav = 'files';
require APP_PATH . '/views/header.php';
?>

<?php if ((int) $file['status'] === 2): ?>
  <div class="alert alert-warning" style="margin-bottom:14px">
    该文件正在等待管理员审核，通过前不会出现在文件库中，也无法通过分享链接下载。
  </div>
<?php endif; ?>

<div class="detail-layout">
  <div class="card card-pad">
    <div class="detail-head">
      <div class="detail-icon file-icon <?= e($color) ?>"><?= e($file['ext']) ?></div>
      <div style="min-width:0">
        <h1 class="detail-title"><?= e($file['title']) ?></h1>
        <div class="detail-sub">
          <?= e($file['original_name']) ?>
          <?php if ((int) $file['status'] === 2): ?>
            <span class="badge badge-warning" style="margin-left:8px">待审核</span>
          <?php elseif ((int) $file['status'] !== 1): ?>
            <span class="badge badge-danger" style="margin-left:8px">已下架</span>
          <?php endif; ?>
          <?php if ((int) $file['is_public'] !== 1): ?><span class="badge badge-warning" style="margin-left:8px">私有</span><?php endif; ?>
        </div>
      </div>
    </div>

    <?php if (trim((string) $file['description']) !== ''): ?>
      <div style="margin-top:22px;padding-top:20px;border-top:1px solid var(--border)">
        <div class="section-title" style="font-size:14px;margin-bottom:10px">文件说明</div>
        <div class="prose"><?= e($file['description']) ?></div>
      </div>
    <?php endif; ?>

    <div style="margin-top:24px">
      <div class="section-title" style="font-size:14px;margin-bottom:4px">文件信息</div>
      <div class="meta-list">
        <div class="meta-row"><span class="meta-key">文件名</span><span class="meta-val"><?= e($file['original_name']) ?></span></div>
        <div class="meta-row"><span class="meta-key">文件大小</span><span class="meta-val"><?= e(fmt_bytes((int) $file['size'])) ?></span></div>
        <div class="meta-row"><span class="meta-key">文件类型</span><span class="meta-val"><?= e(strtoupper((string) $file['ext'])) ?> · <?= e(mime_for_ext((string) $file['ext'])) ?></span></div>
        <div class="meta-row"><span class="meta-key">所属分类</span><span class="meta-val"><?= e(category_name($file['category_id'] !== null ? (int) $file['category_id'] : null)) ?></span></div>
        <div class="meta-row"><span class="meta-key">上传时间</span><span class="meta-val"><?= e(fmt_time((string) $file['created_at'])) ?></span></div>
        <div class="meta-row"><span class="meta-key">下载次数</span><span class="meta-val"><?= (int) $file['download_count'] ?> 次</span></div>
        <div class="meta-row"><span class="meta-key">SHA-256 校验值</span><span class="meta-val mono"><?= e($file['sha256']) ?></span></div>
      </div>
      <div class="hint" style="margin-top:10px">下载后可用该值校验文件完整性。</div>
    </div>
  </div>

  <aside>
    <div class="card card-pad download-panel">
      <div class="download-size"><?= e(fmt_bytes((int) $file['size'])) ?></div>
      <div class="download-type"><?= e(strtoupper((string) $file['ext'])) ?> 文件 · <?= e($file['category_name'] ?? category_name($file['category_id'] !== null ? (int) $file['category_id'] : null)) ?></div>

      <a class="btn btn-primary btn-block" style="margin-top:16px" href="<?= e(url('/download.php?t=' . $file['token'])) ?>">
        <?= icon('download', 17) ?> 下载
      </a>

      <div class="hint" style="margin-top:10px;text-align:center">
        单个 IP 每分钟最多下载 <?= e(setting('downloads_per_minute')) ?> 次
      </div>

      <?php if ($canShare): ?>
        <div class="share-box">
          <div class="section-title" style="font-size:13.5px">创建分享链接</div>
          <form method="post" class="form-grid" style="margin-top:10px;gap:10px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_share">
            <div class="form-row">
              <input class="field-input" type="text" name="share_password" placeholder="访问密码（可选，至少 4 位）" maxlength="64" autocomplete="new-password">
            </div>
            <div class="inline-fields">
              <input class="field-input" type="number" name="expires_days" min="0" max="365" placeholder="0" style="max-width:90px">
              <span class="unit">天后过期</span>
            </div>
            <div class="inline-fields">
              <input class="field-input" type="number" name="max_downloads" min="0" max="100000" placeholder="0" style="max-width:90px">
              <span class="unit">次下载上限</span>
            </div>
            <button class="btn btn-sm btn-block" type="submit"><?= icon('link', 15) ?> 生成分享链接</button>
          </form>

          <?php if ($newShareUrl !== ''): ?>
            <div style="margin-top:12px">
              <div class="label" style="margin-bottom:6px">分享地址</div>
              <div class="copy-row">
                <input class="field-input" id="share-url" type="text" value="<?= e($newShareUrl) ?>" readonly>
                <button class="btn btn-sm" type="button" data-copy="#share-url">复制</button>
              </div>
            </div>
          <?php endif; ?>

          <div style="margin-top:10px">
            <a class="hint" href="<?= e(url($canManage ? '/admin/shares.php?file=' . $file['id'] : '/account.php')) ?>"><?= $canManage ? '管理此文件的全部分享' : '在「我的」中管理分享' ?></a>
          </div>
        </div>
      <?php endif; ?>
    </div>

    <?php if ($canManage): ?>
      <div class="card card-pad" style="margin-top:14px">
        <div class="section-title" style="font-size:13.5px">管理操作</div>
        <div class="form-actions" style="margin-top:12px;flex-wrap:wrap">
          <a class="btn btn-sm" href="<?= e(url('/admin/files.php?edit=' . $file['id'])) ?>"><?= icon('edit', 15) ?> 编辑</a>
          <form method="post" action="<?= e(url('/admin/files.php')) ?>" data-confirm="确定删除该文件？物理文件将同时移除，且无法恢复。">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="file_id" value="<?= (int) $file['id'] ?>">
            <button class="btn btn-sm btn-danger" type="submit"><?= icon('trash', 15) ?> 删除</button>
          </form>
        </div>
      </div>
    <?php endif; ?>
  </aside>
</div>

<?php require APP_PATH . '/views/footer.php'; ?>

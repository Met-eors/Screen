<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

$user = require_login();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'delete_file') {
        $fid  = (int) ($_POST['file_id'] ?? 0);
        $file = db_one('SELECT * FROM files WHERE id = ? AND user_id = ?', [$fid, $user['id']]);
        if (!$file) {
            flash('error', '文件不存在或无权操作。');
        } else {
            delete_file($fid);
            flash('success', '文件已删除。');
        }
        redirect('/account.php');
    }

    if ($action === 'revoke_share') {
        $sid   = (int) ($_POST['share_id'] ?? 0);
        $share = db_one('SELECT * FROM shares WHERE id = ? AND created_by = ?', [$sid, $user['id']]);
        if (!$share) {
            flash('error', '分享不存在或无权操作。');
        } else {
            db_exec('UPDATE shares SET status = 0 WHERE id = ?', [$sid]);
            audit('share_revoke', '分享 ' . substr((string) $share['token'], 0, 8) . '...', '用户自行撤销');
            flash('success', '分享链接已撤销。');
        }
        redirect('/account.php');
    }

    if ($action === 'password') {
        $old  = (string) ($_POST['old_password'] ?? '');
        $new  = (string) ($_POST['new_password'] ?? '');
        $new2 = (string) ($_POST['new_password_confirm'] ?? '');

        if (!password_verify($old, (string) $user['password_hash'])) {
            flash('error', '当前密码不正确。');
        } elseif ($new !== $new2) {
            flash('error', '两次输入的新密码不一致。');
        } elseif (($pe = password_policy($new)) !== null) {
            flash('error', $pe);
        } else {
            db_exec('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            session_regenerate_id(true);
            audit('password_change', $user['username'], null);
            flash('success', '密码已更新。');
        }
        redirect('/account.php');
    }
}

$myFiles = db_all(
    'SELECT * FROM files WHERE user_id = ? ORDER BY id DESC LIMIT 100',
    [$user['id']]
);
$myShares = db_all(
    'SELECT s.*, f.title, f.original_name, f.status AS file_status FROM shares s JOIN files f ON f.id = s.file_id
     WHERE s.created_by = ? ORDER BY s.id DESC LIMIT 50',
    [$user['id']]
);
$totals = db_one(
    'SELECT COUNT(*) AS files, COALESCE(SUM(download_count),0) AS downloads FROM files WHERE user_id = ?',
    [$user['id']]
) ?? ['files' => 0, 'downloads' => 0];

$pageTitle = '我的空间';
$activeNav = 'account';
require APP_PATH . '/views/header.php';
?>
<div class="section-head" style="margin-top:0">
  <div>
    <div class="section-title"><?= e($user['username']) ?></div>
    <div class="section-sub"><?= e($user['email']) ?> · 注册于 <?= e(fmt_time((string) $user['created_at'], 'Y-m-d')) ?></div>
  </div>
  <div class="toolbar">
    <?php if (setting_bool('allow_user_upload') || is_admin()): ?>
      <a class="btn btn-primary btn-sm" href="<?= e(url('/upload.php')) ?>"><?= icon('upload', 15) ?> 上传文件</a>
    <?php endif; ?>
  </div>
</div>

<div class="stat-grid" style="margin-bottom:22px">
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">我的文件</span><span class="stat-icon"><?= icon('file', 16) ?></span></div>
    <div class="stat-value"><?= (int) $totals['files'] ?></div>
    <div class="stat-foot">已上传文件总数</div>
  </div>
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">累计下载</span><span class="stat-icon green"><?= icon('download', 16) ?></span></div>
    <div class="stat-value"><?= number_format((int) $totals['downloads']) ?></div>
    <div class="stat-foot">你的文件被下载次数</div>
  </div>
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">分享链接</span><span class="stat-icon slate"><?= icon('link', 16) ?></span></div>
    <div class="stat-value"><?= count($myShares) ?></div>
    <div class="stat-foot">进行中的分享</div>
  </div>
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">账号角色</span><span class="stat-icon orange"><?= icon('shield', 16) ?></span></div>
    <div class="stat-value" style="font-size:20px"><?= $user['role'] === 'admin' ? '管理员' : '普通用户' ?></div>
    <div class="stat-foot">上次登录 <?= e(fmt_ago($user['last_login_at'])) ?></div>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-head">
      <div>
        <div class="card-title">我的文件</div>
        <div class="card-desc">最多展示最近 100 个文件</div>
      </div>
    </div>
    <?php if (!$myFiles): ?>
      <div class="empty" style="padding:44px 24px">
        <div class="empty-icon"><?= icon('file', 20) ?></div>
        <div class="empty-title">还没有上传文件</div>
        <div class="empty-text">上传后可在此管理并生成分享链接。</div>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>文件</th><th>大小</th><th>下载</th><th>状态</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($myFiles as $f): ?>
            <tr>
              <td>
                <div class="td-file">
                  <span class="file-icon <?= e(ext_color((string) $f['ext'])) ?>"><?= e($f['ext']) ?></span>
                  <div style="min-width:0">
                    <a class="cell-strong truncate" style="display:block" href="<?= e(url('/file.php?id=' . $f['token'])) ?>"><?= e($f['title']) ?></a>
                    <span class="cell-muted"><?= e(fmt_ago((string) $f['created_at'])) ?></span>
                  </div>
                </div>
              </td>
              <td class="cell-muted"><?= e(fmt_bytes((int) $f['size'])) ?></td>
              <td class="cell-muted"><?= (int) $f['download_count'] ?></td>
              <td>
                <?php if ((int) $f['status'] === 1): ?>
                  <span class="badge badge-success">已上架</span>
                <?php else: ?>
                  <span class="badge badge-danger">已下架</span>
                <?php endif; ?>
              </td>
              <td class="cell-actions">
                <form method="post" data-confirm="确定删除该文件？操作不可恢复。">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete_file">
                  <input type="hidden" name="file_id" value="<?= (int) $f['id'] ?>">
                  <button class="btn btn-sm btn-ghost" type="submit">删除</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div style="display:grid;gap:18px">
    <div class="card card-pad">
      <div class="card-title">修改密码</div>
      <form method="post" class="form-grid" style="margin-top:14px;gap:12px" autocomplete="off">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="password">
        <div class="form-row">
          <label class="label" for="old_password">当前密码</label>
          <input class="field-input" id="old_password" type="password" name="old_password" required maxlength="72">
        </div>
        <div class="form-row">
          <label class="label" for="new_password">新密码</label>
          <input class="field-input" id="new_password" type="password" name="new_password" required minlength="8" maxlength="72">
        </div>
        <div class="form-row">
          <label class="label" for="new_password_confirm">确认新密码</label>
          <input class="field-input" id="new_password_confirm" type="password" name="new_password_confirm" required maxlength="72">
        </div>
        <button class="btn btn-sm" type="submit">更新密码</button>
      </form>
    </div>

    <div class="card">
      <div class="card-head"><div class="card-title">我的分享</div></div>
      <?php if (!$myShares): ?>
        <div class="empty" style="padding:32px 20px">
          <div class="empty-title" style="font-size:14px">暂无分享链接</div>
          <div class="empty-text">在文件详情页可生成带密码与有效期的分享。</div>
        </div>
      <?php else: ?>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>文件</th><th>状态</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($myShares as $s):
                $sErr = share_error($s); ?>
              <tr>
                <td>
                  <div class="cell-strong truncate"><?= e($s['title']) ?></div>
                  <span class="cell-muted">
                    <?= $s['expires_at'] ? e(fmt_time((string) $s['expires_at'], 'm-d H:i')) . ' 过期' : '长期' ?>
                    · <?= (int) $s['download_count'] ?> 次
                  </span>
                </td>
                <td>
                  <?php if ($sErr === null): ?>
                    <span class="badge badge-success">有效</span>
                  <?php else: ?>
                    <span class="badge">失效</span>
                  <?php endif; ?>
                </td>
                <td class="cell-actions">
                  <?php if ($sErr === null): ?>
                    <form method="post" data-confirm="确定撤销该分享链接？">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="revoke_share">
                      <input type="hidden" name="share_id" value="<?= (int) $s['id'] ?>">
                      <button class="btn btn-sm btn-ghost" type="submit">撤销</button>
                    </form>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require APP_PATH . '/views/footer.php'; ?>

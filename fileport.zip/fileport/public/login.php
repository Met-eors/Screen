<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

$next = safe_next($_GET['next'] ?? $_POST['next'] ?? '');
if (current_user()) {
    redirect($next);
}

$error = '';
$login = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $login = trim((string) ($_POST['login'] ?? ''));
    [$ok, $err] = attempt_login($login, (string) ($_POST['password'] ?? ''));
    if ($ok) {
        $target = is_admin() && $next === '/index.php' ? '/admin/index.php' : $next;
        flash('success', '欢迎回来。');
        redirect($target);
    }
    $error = $err;
}

$pageTitle = '登录';
require APP_PATH . '/views/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-head">
      <span class="brand-mark"><?= icon('download', 20) ?></span>
      <h1 class="auth-title">登录账号</h1>
    </div>

    <?php if ($error !== ''): ?>
      <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" class="form-grid" autocomplete="on">
      <?= csrf_field() ?>
      <input type="hidden" name="next" value="<?= e($next) ?>">

      <div class="form-row">
        <label class="label" for="login">用户名或邮箱</label>
        <input class="field-input" id="login" type="text" name="login" value="<?= e($login) ?>" required maxlength="190" autocomplete="username" autofocus>
      </div>

      <div class="form-row">
        <label class="label" for="password">密码</label>
        <input class="field-input" id="password" type="password" name="password" required maxlength="72" autocomplete="current-password">
      </div>

      <button class="btn btn-primary btn-block" type="submit">登录</button>
    </form>

    <div class="auth-foot">
      <?php if (setting_bool('allow_register')): ?>
        还没有账号？<a href="<?= e(url('/register.php')) ?>">立即注册</a>
      <?php else: ?>
        本站暂未开放注册，请联系管理员开通账号。
      <?php endif; ?>
    </div>

    <div class="auth-note">
      连续 <?= e(setting('login_max_attempts')) ?> 次密码错误将锁定 <?= e(setting('login_lock_minutes')) ?> 分钟。
    </div>
  </div>
</div>
<?php require APP_PATH . '/views/footer.php'; ?>

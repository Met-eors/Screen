<?php
declare(strict_types=1);

/**
 * 安全下载入口
 * 对外只暴露随机 token，物理路径与真实文件名不会出现在 URL 中。
 */
require dirname(__DIR__) . '/app/bootstrap.php';

$fileToken  = (string) ($_GET['t'] ?? '');
$shareToken = (string) ($_GET['s'] ?? '');
$share      = null;
$file       = null;

if ($shareToken !== '') {
    $share = find_share($shareToken);
    if (!$share) {
        download_error(404, '分享链接无效', '该分享链接不存在或格式不正确。');
    }
    $err = share_error($share);
    if ($err !== null) {
        download_error(410, '分享链接不可用', $err);
    }
    if (!share_is_unlocked($share)) {
        redirect('/s.php?t=' . $share['token']);
    }
    $file = db_one('SELECT * FROM files WHERE id = ?', [$share['file_id']]);
    if (!$file) {
        download_error(404, '文件不存在', '文件可能已被删除。');
    }
} else {
    $file = find_file_by_token($fileToken);
    if (!$file) {
        download_error(404, '文件不存在', '下载链接无效或文件已被删除。');
    }
    $isVisible = (int) $file['status'] === 1 && (int) $file['is_public'] === 1;
    if (!$isVisible) {
        $viewer  = current_user();
        $isOwner = $viewer !== null && $file['user_id'] !== null
            && (int) $file['user_id'] === (int) $viewer['id'];
        if (!is_admin() && !$isOwner) {
            download_error(403, '文件不可下载', '该文件已下架或设为私有。');
        }
    }
    if (setting_bool('require_login_download') && !current_user()) {
        redirect('/login.php?next=' . urlencode('/download.php?t=' . $file['token']));
    }
}

if ((int) $file['status'] !== 1) {
    download_error(403, '文件不可下载', '该文件已下架。');
}

// ---------------- 限流：同一 IP 每分钟下载次数 ----------------
$limit = setting_int('downloads_per_minute', 5);
if ($limit > 0) {
    $window  = 60;
    $recent  = rate_count('download', $window);
    if ($recent >= $limit) {
        $oldest = db_val(
            'SELECT MIN(created_at) FROM rate_hits WHERE ip = ? AND action = ? AND created_at >= ?',
            [client_ip(), 'download', date('Y-m-d H:i:s', time() - $window)]
        );
        $retry = $oldest ? max(1, 60 - (time() - strtotime((string) $oldest))) : 60;

        db_exec(
            'INSERT INTO download_logs (file_id, share_id, user_id, ip, user_agent, result, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$file['id'], $share['id'] ?? null, current_user()['id'] ?? null, client_ip(),
                mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255), 'limited', now()]
        );

        http_response_code(429);
        header('Retry-After: ' . $retry);
        $pageTitle = '下载过于频繁';
        $activeNav = 'files';
        require APP_PATH . '/views/header.php';
        ?>
        <div class="card card-pad" style="max-width:560px;margin:48px auto;text-align:center">
          <div class="empty-icon" style="width:56px;height:56px"><?= icon('clock', 24) ?></div>
          <h1 style="font-size:20px;font-weight:680;margin-top:6px">下载过于频繁</h1>
          <p style="color:var(--text-2);margin-top:8px;font-size:14px">
            当前网络在 1 分钟内的下载次数已达上限（<?= $limit ?> 次）。为防止滥用与盗链，本站对下载频率做了限制。
          </p>
          <p style="color:var(--text-3);font-size:13px;margin-top:14px">请在 <strong style="color:var(--text)"><?= (int) $retry ?></strong> 秒后重试。</p>
          <div style="margin-top:22px;display:flex;gap:10px;justify-content:center">
            <a class="btn" href="<?= e(url('/index.php')) ?>">返回文件库</a>
            <a class="btn btn-primary" href="<?= e(url('/download.php?t=' . $file['token'])) ?>">重新下载</a>
          </div>
        </div>
        <?php
        require APP_PATH . '/views/footer.php';
        exit;
    }
}

// ---------------- 计数与日志 ----------------
rate_hit('download');

if ($share !== null) {
    db_exec('UPDATE shares SET download_count = download_count + 1 WHERE id = ?', [$share['id']]);
}
db_exec('UPDATE files SET download_count = download_count + 1 WHERE id = ?', [$file['id']]);
db_exec(
    'INSERT INTO download_logs (file_id, share_id, user_id, ip, user_agent, result, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [$file['id'], $share['id'] ?? null, current_user()['id'] ?? null, client_ip(),
        mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255), 'ok', now()]
);

send_file_download($file);

/** 统一的下载错误页 */
function download_error(int $status, string $title, string $message): never
{
    http_response_code($status);
    $pageTitle = $title;
    $activeNav = 'files';
    require APP_PATH . '/views/header.php';
    echo '<div class="card"><div class="empty"><div class="empty-icon">' . icon('close', 22) . '</div>'
        . '<div class="empty-title">' . e($title) . '</div>'
        . '<div class="empty-text">' . e($message) . '</div>'
        . '<div style="margin-top:18px"><a class="btn" href="' . e(url('/index.php')) . '">返回文件库</a></div></div></div>';
    require APP_PATH . '/views/footer.php';
    exit;
}

<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

if (!setting_bool('allow_register')) {
    http_response_code(403);
    $pageTitle = '注册已关闭';
    require APP_PATH . '/views/header.php';
    echo '<div class="card"><div class="empty"><div class="empty-icon">' . icon('lock', 22) . '</div>'
        . '<div class="empty-title">暂未开放注册</div><div class="empty-text">请联系站点管理员为你开通账号。</div>'
        . '<div style="margin-top:18px"><a class="btn" href="' . e(url('/index.php')) . '">返回文件库</a></div></div></div>';
    require APP_PATH . '/views/footer.php';
    exit;
}

$error  = '';
$uname  = '';
$email  = '';
$useCaptcha = setting_bool('captcha_enabled');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $uname = trim((string) ($_POST['username'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $pass  = (string) ($_POST['password'] ?? '');
    $pass2 = (string) ($_POST['password_confirm'] ?? '');

    if ($useCaptcha && !captcha_check($_POST['captcha'] ?? '')) {
        $error = '人机验证答案不正确，请重新计算。';
    } elseif ($pass !== $pass2) {
        $error = '两次输入的密码不一致。';
    } else {
        [$ok, $err] = register_user($uname, $email, $pass);
        if ($ok) {
            flash('success', '注册成功，已自动登录。');
            redirect('/index.php');
        }
        $error = $err;
    }
}

$pageTitle = '注册';
require APP_PATH . '/views/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-head">
      <span class="brand-mark"><?= icon('user', 20) ?></span>
      <h1 class="auth-title">创建账号</h1>
    </div>

    <?php if ($error !== ''): ?>
      <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" class="form-grid" autocomplete="on">
      <?= csrf_field() ?>

      <div class="form-row">
        <label class="label" for="username">用户名</label>
        <input class="field-input" id="username" type="text" name="username" value="<?= e($uname) ?>" required
               minlength="3" maxlength="20" pattern="[A-Za-z0-9_]{3,20}" autocomplete="username">
        <span class="hint">3-20 位字母、数字或下划线，注册后不可修改。</span>
      </div>

      <div class="form-row">
        <label class="label" for="email">邮箱</label>
        <input class="field-input" id="email" type="email" name="email" value="<?= e($email) ?>" required maxlength="190" autocomplete="email">
      </div>

      <div class="form-row">
        <label class="label" for="password">密码</label>
        <input class="field-input" id="password" type="password" name="password" required minlength="8" maxlength="72" autocomplete="new-password">
        <span class="hint">至少 8 位，需同时包含字母和数字。</span>
      </div>

      <div class="form-row">
        <label class="label" for="password_confirm">确认密码</label>
        <input class="field-input" id="password_confirm" type="password" name="password_confirm" required maxlength="72" autocomplete="new-password">
      </div>

      <?php if ($useCaptcha): ?>
        <div class="form-row">
          <label class="label" for="captcha">人机验证</label>
          <div class="inline-fields">
            <span class="hint" style="font-size:14px;color:var(--text);font-weight:600"><?= e(captcha_question()) ?> =</span>
            <input class="field-input" id="captcha" type="text" name="captcha" inputmode="numeric" required maxlength="3" autocomplete="off" style="max-width:110px">
          </div>
        </div>
      <?php endif; ?>

      <button class="btn btn-primary btn-block" type="submit">创建账号</button>
    </form>

    <div class="auth-foot">
      已有账号？<a href="<?= e(url('/login.php')) ?>">直接登录</a>
    </div>
  </div>
</div>
<?php require APP_PATH . '/views/footer.php'; ?>

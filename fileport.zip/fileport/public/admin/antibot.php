<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
$admin = require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'save') {
        $pageLimit = max(0, min(2000, (int) ($_POST['antibot_page_limit'] ?? 150)));
        $banMin    = max(5, min(43200, (int) ($_POST['antibot_ban_minutes'] ?? 60)));

        $raw = strtolower((string) ($_POST['antibot_ua_keywords'] ?? ''));
        $kw  = [];
        foreach (preg_split('/[\s,，;；]+/u', $raw) ?: [] as $item) {
            $item = trim($item);
            if ($item !== '' && mb_strlen($item) <= 40) {
                $kw[$item] = true;
            }
            if (count($kw) >= 60) {
                break;
            }
        }
        $keywords = implode(',', array_keys($kw));

        setting_set('antibot_page_limit', (string) $pageLimit);
        setting_set('antibot_ban_minutes', (string) $banMin);
        setting_set('antibot_ua_keywords', $keywords);
        foreach (['antibot_enabled', 'antibot_block_empty_ua', 'antibot_auto_ban', 'antibot_honeypot', 'antibot_noindex'] as $k) {
            setting_set($k, !empty($_POST[$k]) ? '1' : '0');
        }
        audit('antibot_settings', null, '防爬配置更新');
        flash('success', '防爬配置已保存。');
        redirect('/admin/antibot.php');
    }

    if ($action === 'ban') {
        $ip = trim((string) ($_POST['ip'] ?? ''));
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            flash('error', 'IP 地址格式不正确。');
        } elseif ($ip === client_ip()) {
            flash('error', '不能封禁当前正在使用的 IP 地址。');
        } else {
            $minutes = max(5, min(43200, (int) ($_POST['minutes'] ?? setting_int('antibot_ban_minutes', 60))));
            $expires = date('Y-m-d H:i:s', time() + $minutes * 60);
            $reason  = '防爬规则：' . antibot_reason_label((string) ($_POST['reason'] ?? 'manual'));

            if (db_val('SELECT COUNT(*) FROM ip_bans WHERE ip = ?', [$ip], 0) > 0) {
                db_exec('UPDATE ip_bans SET reason = ?, expires_at = ?, created_at = ? WHERE ip = ?', [$reason, $expires, now(), $ip]);
            } else {
                db_exec(
                    'INSERT INTO ip_bans (ip, reason, expires_at, created_by, created_at) VALUES (?, ?, ?, ?, ?)',
                    [$ip, $reason, $expires, (int) $admin['id'], now()]
                );
            }
            audit('antibot_ban', $ip, $reason);
            flash('success', '已封禁 ' . $ip . '，解封时间 ' . fmt_time($expires) . '。');
        }
        redirect('/admin/antibot.php');
    }

    if ($action === 'clear') {
        db_exec('DELETE FROM crawler_hits WHERE created_at < ?', [date('Y-m-d H:i:s', time() - 30 * 86400)]);
        audit('antibot_clear', null, '清理 30 天前的拦截记录');
        flash('success', '已清理 30 天前的拦截记录。');
        redirect('/admin/antibot.php');
    }
}

$s = settings_all(true);
$since24 = date('Y-m-d H:i:s', time() - 86400);

$todayHits = (int) db_val('SELECT COUNT(*) FROM crawler_hits WHERE created_at >= ?', [$since24], 0);
$todayIps  = (int) db_val('SELECT COUNT(DISTINCT ip) FROM crawler_hits WHERE created_at >= ?', [$since24], 0);
$banCount  = (int) db_val('SELECT COUNT(*) FROM ip_bans', [], 0);
$topReason = db_one(
    'SELECT reason, COUNT(*) AS hits FROM crawler_hits WHERE created_at >= ? GROUP BY reason ORDER BY hits DESC LIMIT 1',
    [$since24]
);

$hits = db_all('SELECT * FROM crawler_hits ORDER BY id DESC LIMIT 100');
$bannedIps = [];
foreach (db_all('SELECT ip, expires_at FROM ip_bans') as $row) {
    $bannedIps[(string) $row['ip']] = (string) ($row['expires_at'] ?? '');
}

$adminTitle    = '防爬';
$adminNav      = 'antibot';
$adminSubtitle = '识别采集器、限制页面频率、蜜罐诱捕与自动封禁';
require APP_PATH . '/views/admin_header.php';
?>
<div class="stat-grid" style="margin-bottom:18px">
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">24 小时拦截</span><span class="stat-icon orange"><?= icon('shield', 16) ?></span></div>
    <div class="stat-value"><?= number_format($todayHits) ?></div>
    <div class="stat-foot">来自 <?= number_format($todayIps) ?> 个 IP</div>
  </div>
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">当前封禁</span><span class="stat-icon slate"><?= icon('ban', 16) ?></span></div>
    <div class="stat-value"><?= number_format($banCount) ?></div>
    <div class="stat-foot"><a href="<?= e(url('/admin/bans.php')) ?>">查看封禁列表</a></div>
  </div>
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">主要命中原因</span><span class="stat-icon"><?= icon('list', 16) ?></span></div>
    <div class="stat-value" style="font-size:19px"><?= $topReason ? e(antibot_reason_label((string) $topReason['reason'])) : '—' ?></div>
    <div class="stat-foot"><?= $topReason ? number_format((int) $topReason['hits']) . ' 次' : '暂无记录' ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">防爬状态</span><span class="stat-icon green"><?= icon('lock', 16) ?></span></div>
    <div class="stat-value" style="font-size:19px"><?= setting_bool('antibot_enabled') ? '已启用' : '已关闭' ?></div>
    <div class="stat-foot">页面阈值 <?= (int) $s['antibot_page_limit'] ?> 次 / 分钟</div>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-head">
      <div class="card-title">拦截记录</div>
      <form method="post" data-confirm="将删除 30 天前的拦截记录，确定继续？">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="clear">
        <button class="btn btn-sm btn-ghost" type="submit">清理旧记录</button>
      </form>
    </div>
    <?php if (!$hits): ?>
      <div class="empty" style="padding:52px 24px">
        <div class="empty-icon"><?= icon('shield', 20) ?></div>
        <div class="empty-title">暂无拦截记录</div>
        <div class="empty-text">正常访客不会触发这里的规则。</div>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>时间</th><th>IP</th><th>原因</th><th>User-Agent</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($hits as $h): ?>
            <tr>
              <td class="cell-muted" style="white-space:nowrap"><?= e(fmt_time((string) $h['created_at'], 'm-d H:i')) ?></td>
              <td class="mono cell-strong"><?= e($h['ip']) ?></td>
              <td><span class="badge badge-warning"><?= e(antibot_reason_label((string) $h['reason'])) ?></span></td>
              <td class="cell-muted truncate" style="max-width:220px" title="<?= e((string) $h['user_agent']) ?>"><?= e($h['user_agent'] ?: '空') ?></td>
              <td class="cell-actions">
                <?php if (isset($bannedIps[(string) $h['ip']])): ?>
                  <span class="badge badge-danger">已封禁</span>
                <?php elseif ($h['ip'] !== client_ip()): ?>
                  <form method="post" data-confirm="封禁该 IP？">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="ban">
                    <input type="hidden" name="ip" value="<?= e($h['ip']) ?>">
                    <input type="hidden" name="reason" value="<?= e($h['reason']) ?>">
                    <button class="btn btn-sm btn-ghost" type="submit">封禁</button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="card-desc" style="padding:0 18px 16px">仅显示最近 100 条记录，同类 IP 会自动去重统计。</div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head"><div class="card-title">防爬配置</div></div>
    <form method="post" class="card-pad settings-section">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">

      <div class="settings-row">
        <div><div class="settings-label">启用防爬</div><div class="settings-help">关闭后下面的规则全部停止，后台始终不受影响。</div></div>
        <div class="settings-field">
          <label class="switch">
            <input type="checkbox" name="antibot_enabled" value="1"<?= $s['antibot_enabled'] === '1' ? ' checked' : '' ?>>
            <span class="switch-track"></span>
            <span class="switch-text">开启防护</span>
          </label>
        </div>
      </div>

      <div class="settings-row">
        <div><div class="settings-label">拦截空 User-Agent</div><div class="settings-help">浏览器都会发送 UA，空值基本来自脚本请求。</div></div>
        <div class="settings-field">
          <label class="switch">
            <input type="checkbox" name="antibot_block_empty_ua" value="1"<?= $s['antibot_block_empty_ua'] === '1' ? ' checked' : '' ?>>
            <span class="switch-track"></span>
            <span class="switch-text">拦截</span>
          </label>
        </div>
      </div>

      <div class="settings-row">
        <div><div class="settings-label">User-Agent 关键字</div><div class="settings-help">逗号分隔，不区分大小写。命中即拒绝，可自行增删。</div></div>
        <div class="settings-field">
          <textarea class="field-input" name="antibot_ua_keywords" rows="4" style="min-height:96px"><?= e($s['antibot_ua_keywords']) ?></textarea>
        </div>
      </div>

      <div class="settings-row">
        <div><div class="settings-label">页面访问频率</div><div class="settings-help">同一 IP 每分钟最多访问多少个页面，超出返回 429。填 0 关闭该项。</div></div>
        <div class="settings-field inline-fields">
          <input class="field-input" type="number" name="antibot_page_limit" value="<?= (int) $s['antibot_page_limit'] ?>" min="0" max="2000">
          <span class="unit">页 / 分钟</span>
        </div>
      </div>

      <div class="settings-row">
        <div><div class="settings-label">自动封禁</div><div class="settings-help">同一 IP 10 分钟内触发 5 次即自动封禁，时长可调。</div></div>
        <div class="settings-field" style="display:grid;gap:10px;justify-items:end">
          <label class="switch">
            <input type="checkbox" name="antibot_auto_ban" value="1"<?= $s['antibot_auto_ban'] === '1' ? ' checked' : '' ?>>
            <span class="switch-track"></span>
            <span class="switch-text">自动封禁</span>
          </label>
          <div class="inline-fields">
            <input class="field-input" type="number" name="antibot_ban_minutes" value="<?= (int) $s['antibot_ban_minutes'] ?>" min="5" max="43200">
            <span class="unit">分钟</span>
          </div>
        </div>
      </div>

      <div class="settings-row">
        <div><div class="settings-label">蜜罐链接</div><div class="settings-help">页脚放置一个不可见链接，正常用户不会点击，采程序跟进后立即封禁。</div></div>
        <div class="settings-field">
          <label class="switch">
            <input type="checkbox" name="antibot_honeypot" value="1"<?= $s['antibot_honeypot'] === '1' ? ' checked' : '' ?>>
            <span class="switch-track"></span>
            <span class="switch-text">启用</span>
          </label>
        </div>
      </div>

      <div class="settings-row">
        <div><div class="settings-label">禁止搜索引擎索引</div><div class="settings-help">输出 noindex 响应头。需要被收录时不要开启。</div></div>
        <div class="settings-field">
          <label class="switch">
            <input type="checkbox" name="antibot_noindex" value="1"<?= $s['antibot_noindex'] === '1' ? ' checked' : '' ?>>
            <span class="switch-track"></span>
            <span class="switch-text">noindex</span>
          </label>
        </div>
      </div>

      <div class="form-actions" style="margin-top:4px">
        <button class="btn btn-primary" type="submit">保存配置</button>
      </div>
    </form>
  </div>
</div>
<?php require APP_PATH . '/views/admin_footer.php'; ?>

<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
$admin = require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'create') {
        $ip     = trim((string) ($_POST['ip'] ?? ''));
        $reason = trim((string) ($_POST['reason'] ?? ''));
        $hours  = (int) ($_POST['hours'] ?? 0);

        $validIp = filter_var($ip, FILTER_VALIDATE_IP) !== false;
        $validCidr = false;
        if (!$validIp && str_contains($ip, '/')) {
            [$sub, $bits] = explode('/', $ip, 2);
            $validCidr = filter_var($sub, FILTER_VALIDATE_IP) !== false && ctype_digit($bits)
                && (int) $bits >= 0 && (int) $bits <= (str_contains($sub, ':') ? 128 : 32);
        }

        if (!$validIp && !$validCidr) {
            flash('error', '请输入有效的 IP 地址或 CIDR 网段，例如 203.0.113.5 或 203.0.113.0/24。');
        } elseif ($ip === client_ip()) {
            flash('error', '不能封禁当前正在使用的 IP 地址。');
        } elseif (db_val('SELECT COUNT(*) FROM ip_bans WHERE ip = ?', [$ip], 0) > 0) {
            flash('error', '该规则已存在。');
        } else {
            $expires = $hours > 0 ? date('Y-m-d H:i:s', time() + $hours * 3600) : null;
            db_exec(
                'INSERT INTO ip_bans (ip, reason, expires_at, created_by, created_at) VALUES (?, ?, ?, ?, ?)',
                [$ip, $reason !== '' ? mb_substr($reason, 0, 200) : null, $expires, (int) $admin['id'], now()]
            );
            audit('ban_create', $ip, $reason !== '' ? $reason : '无备注');
            flash('success', '已添加封禁规则：' . $ip . ($expires ? '（至 ' . fmt_time($expires) . '）' : '（永久）'));
        }
    } elseif ($action === 'delete') {
        $id  = (int) ($_POST['ban_id'] ?? 0);
        $ban = db_one('SELECT * FROM ip_bans WHERE id = ?', [$id]);
        if ($ban) {
            db_exec('DELETE FROM ip_bans WHERE id = ?', [$id]);
            audit('ban_delete', (string) $ban['ip'], null);
            flash('success', '已解除封禁：' . $ban['ip']);
        }
    }
    redirect('/admin/bans.php');
}

$bans = db_all('SELECT * FROM ip_bans ORDER BY id DESC LIMIT 500');
$recentLimited = db_all(
    "SELECT ip, COUNT(*) AS hits FROM download_logs
     WHERE result = 'limited' AND created_at >= ? GROUP BY ip ORDER BY hits DESC LIMIT 8",
    [date('Y-m-d H:i:s', time() - 86400)]
);

$adminTitle    = 'IP 封禁';
$adminNav      = 'bans';
$adminSubtitle = '按 IP 或网段阻断访问，命中后全站立即生效';
require APP_PATH . '/views/admin_header.php';
?>
<div class="grid-2">
  <div class="card">
    <div class="card-head"><div class="card-title">封禁列表</div><span class="badge"><?= count($bans) ?> 条</span></div>
    <?php if (!$bans): ?>
      <div class="empty" style="padding:48px 24px">
        <div class="empty-icon"><?= icon('ban', 20) ?></div>
        <div class="empty-title">暂无封禁规则</div>
        <div class="empty-text">可在右侧添加 IP 或 CIDR 网段。</div>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>IP / 网段</th><th>原因</th><th>到期</th><th>创建时间</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($bans as $b):
              $expired = $b['expires_at'] !== null && strtotime((string) $b['expires_at']) < time(); ?>
            <tr>
              <td class="mono cell-strong"><?= e($b['ip']) ?></td>
              <td class="cell-muted truncate" style="max-width:180px"><?= e($b['reason'] ?: '—') ?></td>
              <td>
                <?php if ($b['expires_at'] === null): ?>
                  <span class="badge badge-danger">永久</span>
                <?php elseif ($expired): ?>
                  <span class="badge">已过期</span>
                <?php else: ?>
                  <span class="badge badge-warning"><?= e(fmt_time((string) $b['expires_at'], 'm-d H:i')) ?></span>
                <?php endif; ?>
              </td>
              <td class="cell-muted"><?= e(fmt_time((string) $b['created_at'], 'Y-m-d H:i')) ?></td>
              <td class="cell-actions">
                <form method="post" data-confirm="确定解除该封禁？">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="ban_id" value="<?= (int) $b['id'] ?>">
                  <button class="btn btn-sm btn-ghost" type="submit">解除</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div style="display:grid;gap:18px">
    <div class="card card-pad">
      <div class="card-title">添加封禁</div>
      <form method="post" class="form-grid" style="margin-top:16px;gap:14px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <div class="form-row">
          <label class="label" for="ip">IP 或 CIDR 网段</label>
          <input class="field-input" id="ip" type="text" name="ip" required maxlength="45" placeholder="203.0.113.5 或 203.0.113.0/24">
          <span class="hint">支持 IPv4、IPv6 与网段写法，网段最多 /32。</span>
        </div>
        <div class="form-row">
          <label class="label" for="reason">原因</label>
          <input class="field-input" id="reason" type="text" name="reason" maxlength="200" placeholder="例如：恶意爬取下载链接">
        </div>
        <div class="form-row">
          <label class="label" for="hours">封禁时长</label>
          <select class="field-input" id="hours" name="hours">
            <option value="1">1 小时</option>
            <option value="24" selected>1 天</option>
            <option value="168">7 天</option>
            <option value="720">30 天</option>
            <option value="0">永久</option>
          </select>
        </div>
        <button class="btn btn-primary" type="submit"><?= icon('ban', 15) ?> 添加封禁</button>
      </form>
    </div>

    <div class="card card-pad">
      <div class="card-title" style="font-size:13.5px">近 24 小时限流最多的 IP</div>
      <div class="mini-list" style="margin-top:8px">
        <?php if (!$recentLimited): ?>
          <div class="empty" style="padding:22px 0"><div class="empty-title" style="font-size:13px">暂无触发记录</div></div>
        <?php endif; ?>
        <?php foreach ($recentLimited as $r): ?>
          <div class="mini-item">
            <div class="mini-main"><div class="mini-title mono" style="font-size:12.5px"><?= e($r['ip']) ?></div></div>
            <span class="mini-value"><?= (int) $r['hits'] ?> 次被拦截</span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<?php require APP_PATH . '/views/admin_footer.php'; ?>

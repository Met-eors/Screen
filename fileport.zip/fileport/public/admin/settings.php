<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_admin();

$saved = false;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $siteName = trim((string) ($_POST['site_name'] ?? ''));
    $tagline  = trim((string) ($_POST['site_tagline'] ?? ''));
    $notice   = trim((string) ($_POST['site_notice'] ?? ''));

    $perMinute = max(0, min(1000, (int) ($_POST['downloads_per_minute'] ?? 5)));
    $maxUpload = max(1, min(4096, (int) ($_POST['max_upload_mb'] ?? 100)));
    $perPage   = max(6, min(48, (int) ($_POST['per_page'] ?? 12)));
    $attempts  = max(3, min(20, (int) ($_POST['login_max_attempts'] ?? 5)));
    $lockMin   = max(1, min(1440, (int) ($_POST['login_lock_minutes'] ?? 15)));

    $extRaw = strtolower((string) ($_POST['allowed_extensions'] ?? ''));
    $exts = [];
    foreach (preg_split('/[\s,，;；]+/u', $extRaw) ?: [] as $ext) {
        $ext = trim(ltrim($ext, '.'));
        if ($ext !== '' && preg_match('/^[a-z0-9]{1,16}$/', $ext) && !in_array($ext, hard_blocked_extensions(), true)) {
            $exts[$ext] = true;
        }
    }
    $exts = array_keys($exts);

    if ($siteName === '' || mb_strlen($siteName) > 60) {
        flash('error', '站点名称不能为空，且不超过 60 个字符。');
    } elseif (!$exts) {
        flash('error', '至少需要保留一种允许上传的扩展名。');
    } else {
        setting_set('site_name', $siteName);
        setting_set('site_tagline', mb_substr($tagline, 0, 120));
        setting_set('site_notice', mb_substr($notice, 0, 300));
        setting_set('downloads_per_minute', (string) $perMinute);
        setting_set('max_upload_mb', (string) $maxUpload);
        setting_set('per_page', (string) $perPage);
        setting_set('login_max_attempts', (string) $attempts);
        setting_set('login_lock_minutes', (string) $lockMin);
        setting_set('allowed_extensions', implode(',', $exts));
        foreach (['allow_user_upload', 'allow_register', 'require_login_download', 'maintenance_mode', 'captcha_enabled'] as $k) {
            setting_set($k, !empty($_POST[$k]) ? '1' : '0');
        }
        audit('settings_update', null, '更新站点设置');
        flash('success', '设置已保存。');
        redirect('/admin/settings.php');
    }
    redirect('/admin/settings.php');
}

$s = settings_all(true);
$iniUpload = ini_get('upload_max_filesize');
$iniPost   = ini_get('post_max_size');
$effective = upload_limit_bytes();

$adminTitle    = '系统设置';
$adminNav      = 'settings';
$adminSubtitle = '站点信息、下载策略、上传限制与安全开关';
require APP_PATH . '/views/admin_header.php';
?>
<form method="post">
  <?= csrf_field() ?>

  <div class="card" style="margin-bottom:18px">
    <div class="card-head">
      <div>
        <div class="card-title">基本信息</div>
        <div class="card-desc">站点名称与副标题</div>
      </div>
    </div>
    <div class="card-pad settings-section">
      <div class="settings-row">
        <div><div class="settings-label">站点名称</div><div class="settings-help">显示在浏览器标题与导航栏。</div></div>
        <div class="settings-field"><input class="field-input" type="text" name="site_name" value="<?= e($s['site_name']) ?>" required maxlength="60"></div>
      </div>
      <div class="settings-row">
        <div><div class="settings-label">站点副标题</div><div class="settings-help">用于页面描述，留空则使用站点名称。</div></div>
        <div class="settings-field"><input class="field-input" type="text" name="site_tagline" value="<?= e($s['site_tagline']) ?>" maxlength="120"></div>
      </div>
      <div class="settings-row">
        <div><div class="settings-label">全站公告</div><div class="settings-help">留空则不显示公告条。</div></div>
        <div class="settings-field"><input class="field-input" type="text" name="site_notice" value="<?= e($s['site_notice']) ?>" maxlength="300" placeholder="例如：本周六 02:00 进行维护"></div>
      </div>
      <div class="settings-row">
        <div><div class="settings-label">每页文件数</div><div class="settings-help">文件库列表的分页大小。</div></div>
        <div class="settings-field inline-fields">
          <input class="field-input" type="number" name="per_page" value="<?= (int) $s['per_page'] ?>" min="6" max="48">
          <span class="unit">个 / 页</span>
        </div>
      </div>
    </div>
  </div>

  <div class="card" style="margin-bottom:18px">
    <div class="card-head">
      <div>
        <div class="card-title">下载策略</div>
        <div class="card-desc">限制下载频率，防止盗链与批量抓取</div>
      </div>
    </div>
    <div class="card-pad settings-section">
      <div class="settings-row">
        <div>
          <div class="settings-label">单 IP 每分钟下载次数</div>
          <div class="settings-help">超出后返回 429 并提示剩余等待时间。填 0 表示不限制（不建议）。</div>
        </div>
        <div class="settings-field inline-fields">
          <input class="field-input" type="number" name="downloads_per_minute" value="<?= (int) $s['downloads_per_minute'] ?>" min="0" max="1000">
          <span class="unit">次 / 分钟</span>
        </div>
      </div>
      <div class="settings-row">
        <div><div class="settings-label">下载前必须登录</div><div class="settings-help">开启后游客无法直接下载，分享链接不受此限制。</div></div>
        <div class="settings-field">
          <label class="switch">
            <input type="checkbox" name="require_login_download" value="1"<?= $s['require_login_download'] === '1' ? ' checked' : '' ?>>
            <span class="switch-track"></span>
            <span class="switch-text">仅登录用户可下载</span>
          </label>
        </div>
      </div>
    </div>
  </div>

  <div class="card" style="margin-bottom:18px">
    <div class="card-head">
      <div>
        <div class="card-title">上传设置</div>
        <div class="card-desc">控制用户上传开关、大小上限与允许的类型</div>
      </div>
    </div>
    <div class="card-pad settings-section">
      <div class="settings-row">
        <div><div class="settings-label">开放用户上传</div><div class="settings-help">关闭后仅管理员可在后台上传，前台不再显示上传入口。</div></div>
        <div class="settings-field">
          <label class="switch">
            <input type="checkbox" name="allow_user_upload" value="1"<?= $s['allow_user_upload'] === '1' ? ' checked' : '' ?>>
            <span class="switch-track"></span>
            <span class="switch-text">允许注册用户上传文件</span>
          </label>
        </div>
      </div>
      <div class="settings-row">
        <div>
          <div class="settings-label">最大上传文件大小</div>
          <div class="settings-help">
            当前 PHP 配置：upload_max_filesize = <?= e($iniUpload) ?>，post_max_size = <?= e($iniPost) ?>。<br>
            实际生效上限为 <strong><?= e(fmt_bytes($effective)) ?></strong>（取设置值与 PHP 配置的较小值）。
          </div>
        </div>
        <div class="settings-field inline-fields">
          <input class="field-input" type="number" name="max_upload_mb" value="<?= (int) $s['max_upload_mb'] ?>" min="1" max="4096">
          <span class="unit">MB</span>
        </div>
      </div>
      <div class="settings-row">
        <div><div class="settings-label">允许的扩展名</div><div class="settings-help">逗号分隔，不带点。脚本与可执行类型会被系统强制拒绝，即使写在这里也无效。</div></div>
        <div class="settings-field">
          <textarea class="field-input" name="allowed_extensions" rows="3" style="min-height:80px"><?= e($s['allowed_extensions']) ?></textarea>
        </div>
      </div>
    </div>
  </div>

  <div class="card" style="margin-bottom:18px">
    <div class="card-head">
      <div>
        <div class="card-title">账号与安全</div>
        <div class="card-desc">注册策略、人机验证与登录锁定</div>
      </div>
    </div>
    <div class="card-pad settings-section">
      <div class="settings-row">
        <div><div class="settings-label">开放用户注册</div><div class="settings-help">关闭后注册页直接拒绝，已有账号不受影响。</div></div>
        <div class="settings-field">
          <label class="switch">
            <input type="checkbox" name="allow_register" value="1"<?= $s['allow_register'] === '1' ? ' checked' : '' ?>>
            <span class="switch-track"></span>
            <span class="switch-text">允许访客自助注册</span>
          </label>
        </div>
      </div>
      <div class="settings-row">
        <div><div class="settings-label">注册人机验证</div><div class="settings-help">使用算术题验证，无需图片组件，对无障碍更友好。</div></div>
        <div class="settings-field">
          <label class="switch">
            <input type="checkbox" name="captcha_enabled" value="1"<?= $s['captcha_enabled'] === '1' ? ' checked' : '' ?>>
            <span class="switch-track"></span>
            <span class="switch-text">注册时要求验证</span>
          </label>
        </div>
      </div>
      <div class="settings-row">
        <div><div class="settings-label">登录失败锁定</div><div class="settings-help">连续失败达到次数后临时锁定账号。</div></div>
        <div class="settings-field inline-fields">
          <input class="field-input" type="number" name="login_max_attempts" value="<?= (int) $s['login_max_attempts'] ?>" min="3" max="20">
          <span class="unit">次失败，锁定</span>
          <input class="field-input" type="number" name="login_lock_minutes" value="<?= (int) $s['login_lock_minutes'] ?>" min="1" max="1440">
          <span class="unit">分钟</span>
        </div>
      </div>
    </div>
  </div>

  <div class="card" style="margin-bottom:18px">
    <div class="card-head">
      <div>
        <div class="card-title">维护模式</div>
        <div class="card-desc">开启后前台返回 503，仅管理员可访问</div>
      </div>
    </div>
    <div class="card-pad">
      <label class="switch">
        <input type="checkbox" name="maintenance_mode" value="1"<?= $s['maintenance_mode'] === '1' ? ' checked' : '' ?>>
        <span class="switch-track"></span>
        <span class="switch-text">启用维护模式</span>
      </label>
    </div>
  </div>

  <div class="form-actions">
    <button class="btn btn-primary" type="submit">保存设置</button>
    <a class="btn btn-ghost" href="<?= e(url('/index.php')) ?>">查看前台</a>
  </div>
</form>

<?php require APP_PATH . '/views/admin_footer.php'; ?>

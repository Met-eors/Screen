<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_admin();

$fileCount      = (int) db_val('SELECT COUNT(*) FROM files', [], 0);
$totalDownloads = (int) db_val('SELECT COALESCE(SUM(download_count),0) FROM files', [], 0);
$userCount      = (int) db_val('SELECT COUNT(*) FROM users', [], 0);
$shareCount     = (int) db_val('SELECT COUNT(*) FROM shares WHERE status = 1', [], 0);
$storageBytes   = (int) db_val('SELECT COALESCE(SUM(size),0) FROM files', [], 0);
$todayDownloads = (int) db_val(
    "SELECT COUNT(*) FROM download_logs WHERE result = 'ok' AND created_at >= ?",
    [date('Y-m-d 00:00:00')],
    0
);
$limitedToday = (int) db_val(
    "SELECT COUNT(*) FROM download_logs WHERE result = 'limited' AND created_at >= ?",
    [date('Y-m-d 00:00:00')],
    0
);

// 近 7 天下载趋势
$trend = [];
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-{$i} day"));
    $trend[$day] = 0;
}
$rows = db_all(
    "SELECT DATE(created_at) AS d, COUNT(*) AS c FROM download_logs
     WHERE result = 'ok' AND created_at >= ? GROUP BY DATE(created_at)",
    [date('Y-m-d 00:00:00', strtotime('-6 day'))]
);
foreach ($rows as $r) {
    if (isset($trend[$r['d']])) {
        $trend[$r['d']] = (int) $r['c'];
    }
}
$trendMax = max(1, max($trend));

$topFiles = db_all('SELECT * FROM files ORDER BY download_count DESC, id DESC LIMIT 5');
$recent   = db_all(
    'SELECT l.*, f.title, f.token FROM download_logs l
     LEFT JOIN files f ON f.id = l.file_id
     ORDER BY l.id DESC LIMIT 8'
);

$freeBytes = @disk_free_space(storage_root());
$dbOk = db_val('SELECT 1') !== null;

$adminTitle   = '仪表盘';
$adminNav     = 'dashboard';
$adminSubtitle = '站点运行概况与最近动态';
require APP_PATH . '/views/admin_header.php';
?>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">文件总数</span><span class="stat-icon"><?= icon('file', 16) ?></span></div>
    <div class="stat-value"><?= number_format($fileCount) ?></div>
    <div class="stat-foot">占用存储 <?= e(fmt_bytes($storageBytes)) ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">累计下载</span><span class="stat-icon green"><?= icon('download', 16) ?></span></div>
    <div class="stat-value"><?= number_format($totalDownloads) ?></div>
    <div class="stat-foot">今日 <?= number_format($todayDownloads) ?> 次</div>
  </div>
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">注册用户</span><span class="stat-icon slate"><?= icon('users', 16) ?></span></div>
    <div class="stat-value"><?= number_format($userCount) ?></div>
    <div class="stat-foot">有效分享 <?= number_format($shareCount) ?> 个</div>
  </div>
  <div class="stat-card">
    <div class="stat-head"><span class="stat-label">限流拦截</span><span class="stat-icon orange"><?= icon('shield', 16) ?></span></div>
    <div class="stat-value"><?= number_format($limitedToday) ?></div>
    <div class="stat-foot">今日被限流拒绝的下载</div>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-head">
      <div>
        <div class="card-title">下载趋势</div>
        <div class="card-desc">最近 7 天成功下载次数</div>
      </div>
      <span class="badge badge-primary">7 天</span>
    </div>
    <div class="card-pad">
      <div class="bars">
        <?php foreach ($trend as $day => $count): $h = (int) round($count / $trendMax * 100); ?>
          <div class="bar-col" title="<?= e($day) ?>：<?= $count ?> 次">
            <span class="bar-val"><?= $count ?></span>
            <div class="bar<?= $count === 0 ? ' is-zero' : '' ?>" style="height:<?= max(2, $h) ?>%"></div>
            <span class="bar-label"><?= e(date('m-d', strtotime($day))) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-head">
      <div>
        <div class="card-title">热门文件</div>
        <div class="card-desc">按累计下载量排序</div>
      </div>
    </div>
    <div class="card-pad" style="padding-top:6px;padding-bottom:10px">
      <?php if (!$topFiles): ?>
        <div class="empty" style="padding:30px 0">
          <div class="empty-title" style="font-size:13.5px">暂无数据</div>
        </div>
      <?php else: ?>
        <div class="mini-list">
          <?php foreach ($topFiles as $i => $f): ?>
            <div class="mini-item">
              <span class="badge" style="width:22px;justify-content:center"><?= $i + 1 ?></span>
              <div class="mini-main">
                <div class="mini-title"><?= e($f['title']) ?></div>
                <div class="mini-sub"><?= e(fmt_bytes((int) $f['size'])) ?> · <?= e(fmt_ago((string) $f['created_at'])) ?></div>
              </div>
              <span class="mini-value"><?= (int) $f['download_count'] ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-head">
      <div class="card-title">最近下载</div>
      <a class="btn btn-sm btn-ghost" href="<?= e(url('/admin/logs.php')) ?>">全部日志</a>
    </div>
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>文件</th><th>来源 IP</th><th>结果</th><th>时间</th></tr></thead>
        <tbody>
        <?php if (!$recent): ?>
          <tr><td colspan="4"><div class="empty" style="padding:26px 0"><div class="empty-title" style="font-size:13.5px">暂无下载记录</div></div></td></tr>
        <?php endif; ?>
        <?php foreach ($recent as $r): ?>
          <tr>
            <td class="truncate"><?= e($r['title'] ?: '已删除的文件') ?></td>
            <td class="cell-muted mono"><?= e($r['ip']) ?></td>
            <td>
              <span class="badge <?= e(result_badge_class((string) $r['result'])) ?>"><?= e(download_result_label((string) $r['result'])) ?></span>
            </td>
            <td class="cell-muted"><?= e(fmt_ago((string) $r['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <div class="card-head">
      <div class="card-title">运行状态</div>
    </div>
    <div class="card-pad" style="padding-top:8px">
      <div class="meta-list">
        <div class="meta-row"><span class="meta-key">PHP 版本</span><span class="meta-val"><?= e(PHP_VERSION) ?></span></div>
        <div class="meta-row"><span class="meta-key">数据库</span><span class="meta-val"><?= $dbOk ? '已连接' : '异常' ?></span></div>
        <div class="meta-row"><span class="meta-key">上传上限</span><span class="meta-val"><?= e(fmt_bytes(upload_limit_bytes())) ?></span></div>
        <div class="meta-row"><span class="meta-key">存储占用</span><span class="meta-val"><?= e(fmt_bytes($storageBytes)) ?></span></div>
        <div class="meta-row"><span class="meta-key">磁盘剩余</span><span class="meta-val"><?= $freeBytes !== false ? e(fmt_bytes((int) $freeBytes)) : '未知' ?></span></div>
        <div class="meta-row"><span class="meta-key">下载限流</span><span class="meta-val"><?= setting_int('downloads_per_minute', 5) ?> 次 / 分钟 / IP</span></div>
        <div class="meta-row"><span class="meta-key">用户上传</span><span class="meta-val"><?= setting_bool('allow_user_upload') ? '已开放' : '已关闭' ?></span></div>
        <div class="meta-row"><span class="meta-key">维护模式</span><span class="meta-val"><?= setting_bool('maintenance_mode') ? '开启' : '关闭' ?></span></div>
      </div>
    </div>
  </div>
</div>

<?php require APP_PATH . '/views/admin_footer.php'; ?>

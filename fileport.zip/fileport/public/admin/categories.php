<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $id     = (int) ($_POST['id'] ?? 0);
    $name   = trim((string) ($_POST['name'] ?? ''));
    $sort   = (int) ($_POST['sort'] ?? 0);

    if ($action === 'create') {
        if ($name === '' || mb_strlen($name) > 50) {
            flash('error', '分类名称不能为空且不超过 50 字。');
        } elseif (db_val('SELECT COUNT(*) FROM categories WHERE name = ?', [$name], 0) > 0) {
            flash('error', '同名分类已存在。');
        } else {
            $slug = 'c' . substr(bin2hex(random_bytes(4)), 0, 8);
            db_exec('INSERT INTO categories (name, slug, sort, created_at) VALUES (?, ?, ?, ?)', [$name, $slug, $sort, now()]);
            audit('category_create', $name, null);
            flash('success', '分类已创建。');
        }
    } elseif ($action === 'update') {
        if ($name === '' || mb_strlen($name) > 50) {
            flash('error', '分类名称不能为空且不超过 50 字。');
        } else {
            db_exec('UPDATE categories SET name = ?, sort = ? WHERE id = ?', [$name, $sort, $id]);
            audit('category_update', $name, 'ID ' . $id);
            flash('success', '分类已更新。');
        }
    } elseif ($action === 'delete') {
        $used = (int) db_val('SELECT COUNT(*) FROM files WHERE category_id = ?', [$id], 0);
        db_exec('UPDATE files SET category_id = NULL WHERE category_id = ?', [$id]);
        db_exec('DELETE FROM categories WHERE id = ?', [$id]);
        audit('category_delete', 'ID ' . $id, '解绑文件 ' . $used . ' 个');
        flash('success', '分类已删除，' . $used . ' 个文件转为未分类。');
    }
    redirect('/admin/categories.php');
}

$editId = (int) ($_GET['edit'] ?? 0);
$edit   = $editId > 0 ? db_one('SELECT * FROM categories WHERE id = ?', [$editId]) : null;
$cats   = db_all(
    'SELECT c.*, (SELECT COUNT(*) FROM files f WHERE f.category_id = c.id) AS file_count
     FROM categories c ORDER BY c.sort ASC, c.id ASC'
);

$adminTitle    = '分类管理';
$adminNav      = 'categories';
$adminSubtitle = '为文件建立清晰的分类结构';
require APP_PATH . '/views/admin_header.php';
?>
<div class="grid-2">
  <div class="card">
    <div class="card-head"><div class="card-title">所有分类</div><span class="badge"><?= count($cats) ?> 个</span></div>
    <?php if (!$cats): ?>
      <div class="empty" style="padding:44px 24px">
        <div class="empty-icon"><?= icon('tag', 20) ?></div>
        <div class="empty-title">还没有分类</div>
        <div class="empty-text">在右侧创建第一个分类。</div>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>名称</th><th>文件数</th><th>排序</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($cats as $c): ?>
            <tr>
              <td class="cell-strong"><?= e($c['name']) ?></td>
              <td class="cell-muted"><?= (int) $c['file_count'] ?></td>
              <td class="cell-muted"><?= (int) $c['sort'] ?></td>
              <td class="cell-actions">
                <div class="row-actions">
                  <a class="btn btn-sm btn-ghost" href="<?= e(url('/admin/categories.php?edit=' . $c['id'])) ?>">编辑</a>
                  <form method="post" data-confirm="删除分类后，该分类下的文件将变为未分类，确定继续？">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
                    <button class="btn btn-sm btn-ghost" type="submit" style="color:var(--danger)">删除</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="card card-pad">
    <div class="card-title"><?= $edit ? '编辑分类' : '新建分类' ?></div>
    <form method="post" class="form-grid" style="margin-top:16px;gap:14px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
      <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>

      <div class="form-row">
        <label class="label" for="name">分类名称</label>
        <input class="field-input" id="name" type="text" name="name" value="<?= e($edit['name'] ?? '') ?>" required maxlength="50" placeholder="例如：软件工具">
      </div>
      <div class="form-row">
        <label class="label" for="sort">排序值</label>
        <input class="field-input" id="sort" type="number" name="sort" value="<?= (int) ($edit['sort'] ?? 0) ?>" min="-999" max="999">
        <span class="hint">数值越小越靠前。</span>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= $edit ? '保存修改' : '创建分类' ?></button>
        <?php if ($edit): ?><a class="btn btn-ghost" href="<?= e(url('/admin/categories.php')) ?>">取消</a><?php endif; ?>
      </div>
    </form>
  </div>
</div>
<?php require APP_PATH . '/views/admin_footer.php'; ?>

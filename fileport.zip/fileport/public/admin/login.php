<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';

$next = safe_next($_GET['next'] ?? $_POST['next'] ?? '/admin/index.php');
if (is_admin()) {
    redirect($next);
}

$error = '';
$login = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $login = trim((string) ($_POST['login'] ?? ''));
    [$ok, $err] = attempt_login($login, (string) ($_POST['password'] ?? ''));
    if ($ok) {
        if (is_admin()) {
            redirect($next);
        }
        logout_user();
        session_start();
        flash('error', '该账号没有后台管理权限。');
        redirect('/admin/login.php');
    }
    $error = $err;
}

$pageTitle = '后台登录';
require APP_PATH . '/views/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-head">
      <span class="brand-mark" style="background:var(--text)"><?= icon('shield', 20) ?></span>
      <h1 class="auth-title">管理后台</h1>
      <p class="auth-sub">仅限管理员账号登录，所有操作均记录审计日志</p>
    </div>

    <?php if ($error !== ''): ?>
      <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" class="form-grid">
      <?= csrf_field() ?>
      <input type="hidden" name="next" value="<?= e($next) ?>">
      <div class="form-row">
        <label class="label" for="login">管理员账号</label>
        <input class="field-input" id="login" type="text" name="login" value="<?= e($login) ?>" required maxlength="190" autocomplete="username" autofocus>
      </div>
      <div class="form-row">
        <label class="label" for="password">密码</label>
        <input class="field-input" id="password" type="password" name="password" required maxlength="72" autocomplete="current-password">
      </div>
      <button class="btn btn-primary btn-block" type="submit">进入后台</button>
    </form>

    <div class="auth-foot"><a href="<?= e(url('/index.php')) ?>">返回前台</a></div>

    <div class="auth-note">
      同一 IP 每分钟最多 <?= 12 ?> 次登录尝试，连续失败会触发账号临时锁定。
    </div>
  </div>
</div>
<?php require APP_PATH . '/views/footer.php'; ?>

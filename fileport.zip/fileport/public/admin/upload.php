<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
$admin = require_admin();

$error = '';
$limit = upload_limit_bytes();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $result = handle_upload(
        $_FILES['file'] ?? [],
        (string) ($_POST['title'] ?? ''),
        (string) ($_POST['description'] ?? ''),
        (int) ($_POST['category_id'] ?? 0) ?: null,
        null,
        !empty($_POST['is_public'])
    );
    if ($result['ok']) {
        flash('success', '文件上传成功。');
        redirect('/admin/files.php');
    }
    $error = $result['error'];
}

$adminTitle    = '上传文件';
$adminNav      = 'files';
$adminSubtitle = '以管理员身份上传，文件不会记录归属用户';
require APP_PATH . '/views/admin_header.php';
?>
<div style="max-width:760px">
  <?php if ($error !== ''): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data" class="card card-pad">
    <?= csrf_field() ?>
    <input type="hidden" name="MAX_FILE_SIZE" value="<?= $limit ?>">

    <div class="form-grid">
      <div class="file-drop" data-drop>
        <input type="file" name="file" required>
        <div class="drop-icon"><?= icon('upload', 26) ?></div>
        <div class="drop-title">点击选择或拖拽文件到此处</div>
        <div class="drop-hint">服务端上限 <?= e(fmt_bytes($limit)) ?>，超出将被拒绝</div>
        <div class="drop-file" data-drop-file></div>
      </div>

      <div class="form-row">
        <label class="label" for="title">标题</label>
        <input class="field-input" id="title" type="text" name="title" maxlength="200" placeholder="留空则使用文件名">
      </div>

      <div class="form-row">
        <label class="label" for="description">描述</label>
        <textarea class="field-input" id="description" name="description" maxlength="5000" placeholder="可选"></textarea>
      </div>

      <div class="form-row-2">
        <div class="form-row">
          <label class="label" for="category_id">分类</label>
          <select class="field-input" id="category_id" name="category_id">
            <option value="0">未分类</option>
            <?php foreach (categories_all() as $c): ?>
              <option value="<?= (int) $c['id'] ?>"><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-row">
          <span class="label">可见性</span>
          <div class="check-row" style="padding-top:9px">
            <input type="checkbox" id="is_public" name="is_public" value="1" checked>
            <label for="is_public"><span class="check-label">公开显示在文件库</span></label>
          </div>
        </div>
      </div>

      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= icon('upload', 16) ?> 上传</button>
        <a class="btn btn-ghost" href="<?= e(url('/admin/files.php')) ?>">返回列表</a>
      </div>
    </div>
  </form>

  <div class="auth-note">
    允许的扩展名：<?= e(implode(', ', allowed_extensions())) ?>。
    脚本与可执行类型即便加入白名单也会被系统强制拒绝。
  </div>
</div>
<?php require APP_PATH . '/views/admin_footer.php'; ?>

<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $id     = (int) ($_POST['share_id'] ?? 0);
    $share  = $id > 0 ? db_one('SELECT * FROM shares WHERE id = ?', [$id]) : null;

    if (!$share) {
        flash('error', '分享不存在。');
    } elseif ($action === 'revoke') {
        db_exec('UPDATE shares SET status = 0 WHERE id = ?', [$id]);
        audit('share_revoke', '分享 ID ' . $id, null);
        flash('success', '分享链接已撤销。');
    } elseif ($action === 'delete') {
        db_exec('DELETE FROM shares WHERE id = ?', [$id]);
        audit('share_delete', '分享 ID ' . $id, null);
        flash('success', '分享记录已删除。');
    }
    redirect('/admin/shares.php');
}

$fileId = (int) ($_GET['file'] ?? 0);
$filter = (string) ($_GET['filter'] ?? 'all');
$page   = max(1, (int) ($_GET['page'] ?? 1));
$per    = 20;

$where  = ['1=1'];
$params = [];
if ($fileId > 0) {
    $where[]  = 's.file_id = ?';
    $params[] = $fileId;
}
if ($filter === 'active') {
    $where[] = 's.status = 1 AND f.status = 1 AND (s.expires_at IS NULL OR s.expires_at > NOW())
                AND (s.max_downloads = 0 OR s.download_count < s.max_downloads)';
} elseif ($filter === 'dead') {
    $where[] = '(s.status = 0 OR f.status = 0 OR (s.expires_at IS NOT NULL AND s.expires_at <= NOW())
                OR (s.max_downloads > 0 AND s.download_count >= s.max_downloads))';
}
$whereSql = implode(' AND ', $where);
$total = (int) db_val(
    "SELECT COUNT(*) FROM shares s JOIN files f ON f.id = s.file_id WHERE {$whereSql}",
    $params,
    0
);
$offset = ($page - 1) * $per;
$shares = db_all(
    "SELECT s.*, f.title, f.original_name, f.status AS file_status, f.token AS file_token, f.size
     FROM shares s JOIN files f ON f.id = s.file_id
     WHERE {$whereSql} ORDER BY s.id DESC LIMIT {$per} OFFSET {$offset}",
    $params
);

$adminTitle    = '分享链接';
$adminNav      = 'shares';
$adminSubtitle = '查看、撤销与清理带权限控制的分享';
require APP_PATH . '/views/admin_header.php';
?>
<div class="card">
  <div class="card-head" style="flex-wrap:wrap">
    <div class="toolbar">
      <a class="chip<?= $filter === 'all' ? ' is-active' : '' ?>" href="?filter=all<?= $fileId ? '&file=' . $fileId : '' ?>">全部</a>
      <a class="chip<?= $filter === 'active' ? ' is-active' : '' ?>" href="?filter=active<?= $fileId ? '&file=' . $fileId : '' ?>">有效</a>
      <a class="chip<?= $filter === 'dead' ? ' is-active' : '' ?>" href="?filter=dead<?= $fileId ? '&file=' . $fileId : '' ?>">已失效</a>
      <?php if ($fileId): ?>
        <a class="btn btn-sm btn-ghost" href="<?= e(url('/admin/shares.php')) ?>">清除文件筛选</a>
      <?php endif; ?>
    </div>
    <span class="badge">共 <?= $total ?> 条</span>
  </div>

  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>文件</th><th>分享链接</th><th>权限</th><th>用量</th><th>状态</th><th></th></tr></thead>
      <tbody>
      <?php if (!$shares): ?>
        <tr><td colspan="6"><div class="empty" style="padding:40px 0"><div class="empty-title" style="font-size:14px">暂无分享记录</div></div></td></tr>
      <?php endif; ?>
      <?php foreach ($shares as $s):
          $err  = share_error($s);
          $url  = url('/s.php?t=' . $s['token']);
          $left = (int) $s['max_downloads'] > 0 ? max(0, (int) $s['max_downloads'] - (int) $s['download_count']) : -1;
      ?>
        <tr>
          <td>
            <div class="cell-strong truncate" style="max-width:220px"><?= e($s['title']) ?></div>
            <span class="cell-muted"><?= e(fmt_bytes((int) $s['size'])) ?></span>
          </td>
          <td style="min-width:260px">
            <div class="copy-row">
              <input class="field-input" id="share-<?= (int) $s['id'] ?>" type="text" value="<?= e($url) ?>" readonly style="font-size:11.5px">
              <button class="btn btn-sm" type="button" data-copy="#share-<?= (int) $s['id'] ?>">复制</button>
            </div>
          </td>
          <td class="cell-muted">
            <?= $s['password_hash'] ? '密码保护' : '无密码' ?><br>
            <?= $s['expires_at'] ? e(fmt_time((string) $s['expires_at'], 'Y-m-d H:i')) . ' 过期' : '长期有效' ?>
          </td>
          <td class="cell-muted">
            <?= (int) $s['download_count'] ?> 次<?= $left >= 0 ? ' / 剩 ' . $left : ' / 不限' ?>
          </td>
          <td>
            <?php if ($err === null): ?>
              <span class="badge badge-success">有效</span>
            <?php else: ?>
              <span class="badge">失效</span>
            <?php endif; ?>
          </td>
          <td class="cell-actions">
            <div class="row-actions">
              <?php if ((int) $s['status'] === 1): ?>
                <form method="post" data-confirm="撤销后此链接立即失效，确定继续？">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="revoke">
                  <input type="hidden" name="share_id" value="<?= (int) $s['id'] ?>">
                  <button class="btn btn-sm btn-ghost" type="submit">撤销</button>
                </form>
              <?php endif; ?>
              <form method="post" data-confirm="删除这条分享记录？">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="share_id" value="<?= (int) $s['id'] ?>">
                <button class="btn btn-sm btn-ghost" type="submit" style="color:var(--danger)">删除</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($total > $per): ?>
    <div class="card-pad"><?= render_pagination($page, $total, $per, ['filter' => $filter, 'file' => $fileId ?: null]) ?></div>
  <?php endif; ?>
</div>
<?php require APP_PATH . '/views/admin_footer.php'; ?>

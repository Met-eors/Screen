<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_admin();

$tab    = ($_GET['tab'] ?? 'download') === 'audit' ? 'audit' : 'download';
$page   = max(1, (int) ($_GET['page'] ?? 1));
$per    = 30;
$offset = ($page - 1) * $per;

$ip     = trim((string) ($_GET['ip'] ?? ''));
$result = (string) ($_GET['result'] ?? '');
$action = trim((string) ($_GET['action'] ?? ''));

if ($tab === 'download') {
    $where  = ['1=1'];
    $params = [];
    if ($ip !== '') {
        $where[]  = 'l.ip = ?';
        $params[] = $ip;
    }
    if (in_array($result, ['ok', 'limited', 'password', 'denied'], true)) {
        $where[]  = 'l.result = ?';
        $params[] = $result;
    }
    $whereSql = implode(' AND ', $where);
    $total = (int) db_val("SELECT COUNT(*) FROM download_logs l WHERE {$whereSql}", $params, 0);
    $rows = db_all(
        "SELECT l.*, f.title, f.token FROM download_logs l LEFT JOIN files f ON f.id = l.file_id
         WHERE {$whereSql} ORDER BY l.id DESC LIMIT {$per} OFFSET {$offset}",
        $params
    );
} else {
    $where  = ['1=1'];
    $params = [];
    if ($ip !== '') {
        $where[]  = 'ip = ?';
        $params[] = $ip;
    }
    if ($action !== '') {
        $where[]  = 'action LIKE ?';
        $params[] = '%' . $action . '%';
    }
    $whereSql = implode(' AND ', $where);
    $total = (int) db_val("SELECT COUNT(*) FROM audit_logs WHERE {$whereSql}", $params, 0);
    $rows = db_all(
        "SELECT * FROM audit_logs WHERE {$whereSql} ORDER BY id DESC LIMIT {$per} OFFSET {$offset}",
        $params
    );
}

$adminTitle    = '日志审计';
$adminNav      = 'logs';
$adminSubtitle = '所有下载行为与后台操作均可追溯';
require APP_PATH . '/views/admin_header.php';
?>
<div class="card">
  <div class="card-head" style="flex-wrap:wrap">
    <div class="toolbar">
      <a class="chip<?= $tab === 'download' ? ' is-active' : '' ?>" href="?tab=download">下载日志</a>
      <a class="chip<?= $tab === 'audit' ? ' is-active' : '' ?>" href="?tab=audit">操作审计</a>
    </div>
    <form class="toolbar" method="get" style="flex:1;justify-content:flex-end">
      <input type="hidden" name="tab" value="<?= e($tab) ?>">
      <input class="field-input" type="text" name="ip" value="<?= e($ip) ?>" placeholder="按 IP 精确筛选" maxlength="45" style="max-width:170px">
      <?php if ($tab === 'download'): ?>
        <select class="field-input" name="result" style="max-width:130px">
          <option value="">全部结果</option>
          <option value="ok"<?= $result === 'ok' ? ' selected' : '' ?>>成功</option>
          <option value="limited"<?= $result === 'limited' ? ' selected' : '' ?>>被限流</option>
          <option value="password"<?= $result === 'password' ? ' selected' : '' ?>>密码错误</option>
          <option value="denied"<?= $result === 'denied' ? ' selected' : '' ?>>被拒绝</option>
        </select>
      <?php else: ?>
        <input class="field-input" type="text" name="action" value="<?= e($action) ?>" placeholder="操作类型，如 login" maxlength="50" style="max-width:180px">
      <?php endif; ?>
      <button class="btn" type="submit">筛选</button>
      <span class="badge"><?= $total ?> 条</span>
    </form>
  </div>

  <div class="table-wrap">
    <?php if ($tab === 'download'): ?>
      <table class="table">
        <thead><tr><th>时间</th><th>文件</th><th>IP</th><th>账号</th><th>结果</th><th>来源</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?>
          <tr><td colspan="6"><div class="empty" style="padding:40px 0"><div class="empty-title" style="font-size:14px">暂无记录</div></div></td></tr>
        <?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="cell-muted" style="white-space:nowrap"><?= e(fmt_time((string) $r['created_at'], 'm-d H:i:s')) ?></td>
            <td>
              <?php if ($r['title']): ?>
                <a class="cell-strong truncate" style="display:block;max-width:240px" href="<?= e(url('/file.php?id=' . $r['token'])) ?>" target="_blank" rel="noopener"><?= e($r['title']) ?></a>
              <?php else: ?>
                <span class="cell-muted">已删除的文件 #<?= (int) $r['file_id'] ?></span>
              <?php endif; ?>
            </td>
            <td class="mono cell-muted"><?= e($r['ip']) ?></td>
            <td class="cell-muted"><?= $r['user_id'] ? '#' . (int) $r['user_id'] : '游客' ?><?= $r['share_id'] ? ' · 分享' : '' ?></td>
            <td>
              <span class="badge <?= e(result_badge_class((string) $r['result'])) ?>"><?= e(download_result_label((string) $r['result'])) ?></span>
            </td>
            <td class="cell-muted truncate" style="max-width:220px" title="<?= e($r['user_agent']) ?>"><?= e(excerpt($r['user_agent'], 46)) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <table class="table">
        <thead><tr><th>时间</th><th>操作者</th><th>动作</th><th>对象</th><th>详情</th><th>IP</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?>
          <tr><td colspan="6"><div class="empty" style="padding:40px 0"><div class="empty-title" style="font-size:14px">暂无记录</div></div></td></tr>
        <?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="cell-muted" style="white-space:nowrap"><?= e(fmt_time((string) $r['created_at'], 'm-d H:i:s')) ?></td>
            <td class="cell-strong"><?= e($r['username'] ?: '系统') ?></td>
            <td><span class="badge"><?= e($r['action']) ?></span></td>
            <td class="cell-muted truncate" style="max-width:220px"><?= e($r['target'] ?: '—') ?></td>
            <td class="cell-muted truncate" style="max-width:260px" title="<?= e($r['detail']) ?>"><?= e(excerpt($r['detail'], 60) ?: '—') ?></td>
            <td class="mono cell-muted"><?= e($r['ip'] ?: '—') ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <?php if ($total > $per): ?>
    <div class="card-pad">
      <?= render_pagination($page, $total, $per, ['tab' => $tab, 'ip' => $ip ?: null, 'result' => $result ?: null, 'action' => $action ?: null]) ?>
    </div>
  <?php endif; ?>
</div>
<?php require APP_PATH . '/views/admin_footer.php'; ?>

<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
$admin = require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $id     = (int) ($_POST['user_id'] ?? 0);
    $target = $id > 0 ? db_one('SELECT * FROM users WHERE id = ?', [$id]) : null;

    if (!$target) {
        flash('error', '用户不存在。');
        redirect('/admin/users.php');
    }
    if ($id === (int) $admin['id'] && in_array($action, ['toggle', 'role', 'delete'], true)) {
        flash('error', '不能对当前登录账号执行该操作。');
        redirect('/admin/users.php');
    }

    if ($action === 'toggle') {
        $new = (int) $target['status'] === 1 ? 0 : 1;
        db_exec('UPDATE users SET status = ? WHERE id = ?', [$new, $id]);
        audit('user_status', (string) $target['username'], $new === 1 ? '启用' : '禁用');
        flash('success', $new === 1 ? '账号已启用。' : '账号已禁用。');
    } elseif ($action === 'role') {
        $newRole = $target['role'] === 'admin' ? 'user' : 'admin';
        db_exec('UPDATE users SET role = ? WHERE id = ?', [$newRole, $id]);
        audit('user_role', (string) $target['username'], '变更为 ' . $newRole);
        flash('success', '角色已更新为 ' . ($newRole === 'admin' ? '管理员' : '普通用户') . '。');
    } elseif ($action === 'reset_pw') {
        $plain = 'Fp' . random_int(1000, 9999) . bin2hex(random_bytes(2));
        db_exec('UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?', [
            password_hash($plain, PASSWORD_DEFAULT), $id,
        ]);
        audit('user_reset_password', (string) $target['username'], '管理员重置密码');
        flash('warning', '已重置「' . $target['username'] . '」的密码为：' . $plain . '（请立即转告用户并提醒修改）');
    } elseif ($action === 'delete') {
        db_exec('UPDATE files SET user_id = NULL WHERE user_id = ?', [$id]);
        db_exec('UPDATE shares SET created_by = NULL WHERE created_by = ?', [$id]);
        db_exec('DELETE FROM users WHERE id = ?', [$id]);
        audit('user_delete', (string) $target['username'], '用户上传的文件已保留并转为无主');
        flash('success', '用户已删除，其文件保留但不再归属该账号。');
    }
    redirect('/admin/users.php');
}

$q    = trim((string) ($_GET['q'] ?? ''));
$role = (string) ($_GET['role'] ?? '');
$page = max(1, (int) ($_GET['page'] ?? 1));
$per  = 20;

$where  = ['1=1'];
$params = [];
if ($q !== '') {
    $like   = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
    $where[] = '(username LIKE ? OR email LIKE ?)';
    array_push($params, $like, $like);
}
if ($role === 'admin' || $role === 'user') {
    $where[]  = 'role = ?';
    $params[] = $role;
}
$whereSql = implode(' AND ', $where);
$total = (int) db_val("SELECT COUNT(*) FROM users WHERE {$whereSql}", $params, 0);
$offset = ($page - 1) * $per;
$users = db_all(
    "SELECT u.*, (SELECT COUNT(*) FROM files f WHERE f.user_id = u.id) AS file_count
     FROM users u WHERE {$whereSql} ORDER BY u.id DESC LIMIT {$per} OFFSET {$offset}",
    $params
);

$adminTitle    = '用户管理';
$adminNav      = 'users';
$adminSubtitle = '账号状态、权限与密码管理';
require APP_PATH . '/views/admin_header.php';
?>
<div class="card">
  <div class="card-head" style="flex-wrap:wrap">
    <form class="toolbar" method="get" style="flex:1">
      <div class="toolbar-search">
        <span class="search-mini-icon"><?= icon('search', 16) ?></span>
        <input class="field-input" type="search" name="q" value="<?= e($q) ?>" placeholder="搜索用户名或邮箱" maxlength="80">
      </div>
      <select class="field-input" name="role" style="max-width:130px">
        <option value="">全部角色</option>
        <option value="admin"<?= $role === 'admin' ? ' selected' : '' ?>>管理员</option>
        <option value="user"<?= $role === 'user' ? ' selected' : '' ?>>普通用户</option>
      </select>
      <button class="btn" type="submit">筛选</button>
      <span class="spacer"></span>
      <span class="badge">共 <?= $total ?> 个账号</span>
    </form>
  </div>

  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>用户</th><th>角色</th><th>状态</th><th>文件</th><th>最后登录</th><th>注册时间</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td>
            <div class="td-file" style="min-width:200px">
              <span class="avatar"><?= e(mb_strtoupper(mb_substr((string) $u['username'], 0, 1))) ?></span>
              <div style="min-width:0">
                <div class="cell-strong"><?= e($u['username']) ?><?= (int) $u['id'] === (int) $admin['id'] ? ' <span class="badge">你</span>' : '' ?></div>
                <div class="cell-muted truncate"><?= e($u['email']) ?></div>
              </div>
            </div>
          </td>
          <td>
            <?php if ($u['role'] === 'admin'): ?>
              <span class="badge badge-primary">管理员</span>
            <?php else: ?>
              <span class="badge">用户</span>
            <?php endif; ?>
          </td>
          <td>
            <?php if ((int) $u['status'] === 1): ?>
              <span class="badge badge-success">正常</span>
            <?php else: ?>
              <span class="badge badge-danger">禁用</span>
            <?php endif; ?>
          </td>
          <td class="cell-muted"><?= (int) $u['file_count'] ?></td>
          <td class="cell-muted"><?= e(fmt_ago($u['last_login_at'])) ?></td>
          <td class="cell-muted"><?= e(fmt_time((string) $u['created_at'], 'Y-m-d')) ?></td>
          <td class="cell-actions">
            <div class="row-actions">
              <form method="post" data-confirm="确定重置该用户的密码？">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="reset_pw">
                <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                <button class="btn btn-sm btn-ghost" type="submit">重置密码</button>
              </form>
              <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="role">
                <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                <button class="btn btn-sm btn-ghost" type="submit"><?= $u['role'] === 'admin' ? '降为普通' : '设为管理员' ?></button>
              </form>
              <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                <button class="btn btn-sm btn-ghost" type="submit"><?= (int) $u['status'] === 1 ? '禁用' : '启用' ?></button>
              </form>
              <form method="post" data-confirm="确定删除该用户？其上传的文件将被保留但不再归属任何账号。">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                <button class="btn btn-sm btn-ghost" type="submit" style="color:var(--danger)">删除</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($total > $per): ?>
    <div class="card-pad"><?= render_pagination($page, $total, $per, ['q' => $q, 'role' => $role ?: null]) ?></div>
  <?php endif; ?>
</div>
<?php require APP_PATH . '/views/admin_footer.php'; ?>

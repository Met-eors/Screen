<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
$admin = require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $id     = (int) ($_POST['file_id'] ?? 0);
    $file   = $id > 0 ? db_one('SELECT * FROM files WHERE id = ?', [$id]) : null;

    if (!$file) {
        flash('error', '文件不存在。');
        redirect('/admin/files.php');
    }

    if ($action === 'delete') {
        delete_file($id);
        flash('success', '文件「' . $file['title'] . '」已删除。');
    } elseif ($action === 'toggle') {
        $new = (int) $file['status'] === 1 ? 0 : 1;
        db_exec('UPDATE files SET status = ?, updated_at = ? WHERE id = ?', [$new, now(), $id]);
        audit('file_status', (string) $file['original_name'], $new === 1 ? '上架' : '下架');
        flash('success', $new === 1 ? '文件已上架。' : '文件已下架。');
    } elseif ($action === 'update') {
        $title = trim((string) ($_POST['title'] ?? ''));
        $desc  = trim((string) ($_POST['description'] ?? ''));
        $catId = (int) ($_POST['category_id'] ?? 0);
        if ($title === '') {
            flash('error', '标题不能为空。');
        } else {
            db_exec(
                'UPDATE files SET title = ?, description = ?, category_id = ?, is_public = ?, updated_at = ? WHERE id = ?',
                [
                    mb_substr($title, 0, 200),
                    $desc !== '' ? mb_substr($desc, 0, 5000) : null,
                    $catId > 0 ? $catId : null,
                    !empty($_POST['is_public']) ? 1 : 0,
                    now(),
                    $id,
                ]
            );
            audit('file_update', (string) $file['original_name'], '标题：' . $title);
            flash('success', '文件信息已更新。');
        }
    }
    redirect('/admin/files.php');
}

$q      = trim((string) ($_GET['q'] ?? ''));
$cat    = (int) ($_GET['cat'] ?? 0);
$status = (string) ($_GET['status'] ?? '');
$page   = max(1, (int) ($_GET['page'] ?? 1));
$per    = 20;

$where  = ['1=1'];
$params = [];
if ($q !== '') {
    $like   = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
    $where[] = '(f.title LIKE ? OR f.original_name LIKE ?)';
    array_push($params, $like, $like);
}
if ($cat > 0) {
    $where[]  = 'f.category_id = ?';
    $params[] = $cat;
}
if ($status === 'on') {
    $where[] = 'f.status = 1';
} elseif ($status === 'off') {
    $where[] = 'f.status = 0';
}
$whereSql = implode(' AND ', $where);
$total = (int) db_val("SELECT COUNT(*) FROM files f WHERE {$whereSql}", $params, 0);
$offset = ($page - 1) * $per;
$files = db_all(
    "SELECT f.*, u.username, c.name AS category_name
     FROM files f
     LEFT JOIN users u ON u.id = f.user_id
     LEFT JOIN categories c ON c.id = f.category_id
     WHERE {$whereSql} ORDER BY f.id DESC LIMIT {$per} OFFSET {$offset}",
    $params
);

$editFile = null;
if (!empty($_GET['edit'])) {
    $editFile = db_one('SELECT * FROM files WHERE id = ?', [(int) $_GET['edit']]);
}

$adminTitle    = '文件管理';
$adminNav      = 'files';
$adminSubtitle = '上传、编辑、上下架与删除文件';
require APP_PATH . '/views/admin_header.php';
?>

<?php if ($editFile): ?>
  <div class="card">
    <div class="card-head">
      <div>
        <div class="card-title">编辑文件</div>
        <div class="card-desc"><?= e($editFile['original_name']) ?> · <?= e(fmt_bytes((int) $editFile['size'])) ?></div>
      </div>
      <a class="btn btn-sm btn-ghost" href="<?= e(url('/admin/files.php')) ?>">取消</a>
    </div>
    <form method="post" class="card-pad">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="update">
      <input type="hidden" name="file_id" value="<?= (int) $editFile['id'] ?>">
      <div class="form-grid">
        <div class="form-row">
          <label class="label" for="title">标题</label>
          <input class="field-input" id="title" type="text" name="title" value="<?= e($editFile['title']) ?>" required maxlength="200">
        </div>
        <div class="form-row">
          <label class="label" for="description">描述</label>
          <textarea class="field-input" id="description" name="description" maxlength="5000"><?= e($editFile['description']) ?></textarea>
        </div>
        <div class="form-row-2">
          <div class="form-row">
            <label class="label" for="category_id">分类</label>
            <select class="field-input" id="category_id" name="category_id">
              <option value="0">未分类</option>
              <?php foreach (categories_all() as $c): ?>
                <option value="<?= (int) $c['id'] ?>"<?= (int) $editFile['category_id'] === (int) $c['id'] ? ' selected' : '' ?>><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-row">
            <span class="label">可见性</span>
            <div class="check-row" style="padding-top:9px">
              <input type="checkbox" id="is_public" name="is_public" value="1"<?= (int) $editFile['is_public'] === 1 ? ' checked' : '' ?>>
              <label for="is_public"><span class="check-label">公开显示在文件库</span></label>
            </div>
          </div>
        </div>
        <div class="form-actions">
          <button class="btn btn-primary" type="submit">保存修改</button>
          <a class="btn btn-ghost" href="<?= e(url('/file.php?id=' . $editFile['token'])) ?>" target="_blank" rel="noopener">前台查看</a>
        </div>
      </div>
    </form>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-head" style="flex-wrap:wrap">
    <form class="toolbar" method="get" style="flex:1">
      <div class="toolbar-search">
        <span class="search-mini-icon"><?= icon('search', 16) ?></span>
        <input class="field-input" type="search" name="q" value="<?= e($q) ?>" placeholder="搜索标题或文件名" maxlength="80">
      </div>
      <select class="field-input" name="cat" style="max-width:150px">
        <option value="0">全部分类</option>
        <?php foreach (categories_all() as $c): ?>
          <option value="<?= (int) $c['id'] ?>"<?= $cat === (int) $c['id'] ? ' selected' : '' ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
      <select class="field-input" name="status" style="max-width:120px">
        <option value="">全部状态</option>
        <option value="on"<?= $status === 'on' ? ' selected' : '' ?>>已上架</option>
        <option value="off"<?= $status === 'off' ? ' selected' : '' ?>>已下架</option>
      </select>
      <button class="btn" type="submit">筛选</button>
      <span class="spacer"></span>
      <a class="btn btn-primary" href="<?= e(url('/admin/upload.php')) ?>"><?= icon('plus', 15) ?> 上传文件</a>
    </form>
  </div>

  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr><th>文件</th><th>大小</th><th>分类</th><th>上传者</th><th>下载</th><th>状态</th><th>时间</th><th></th></tr>
      </thead>
      <tbody>
      <?php if (!$files): ?>
        <tr><td colspan="8"><div class="empty" style="padding:40px 0"><div class="empty-title" style="font-size:14px">没有符合条件的文件</div></div></td></tr>
      <?php endif; ?>
      <?php foreach ($files as $f): ?>
        <tr>
          <td>
            <div class="td-file">
              <span class="file-icon <?= e(ext_color((string) $f['ext'])) ?>"><?= e($f['ext']) ?></span>
              <div style="min-width:0">
                <a class="cell-strong truncate" style="display:block" href="<?= e(url('/file.php?id=' . $f['token'])) ?>" target="_blank" rel="noopener"><?= e($f['title']) ?></a>
                <span class="cell-muted truncate" style="display:block"><?= e($f['original_name']) ?></span>
              </div>
            </div>
          </td>
          <td class="cell-muted"><?= e(fmt_bytes((int) $f['size'])) ?></td>
          <td class="cell-muted"><?= e($f['category_name'] ?: '未分类') ?></td>
          <td class="cell-muted"><?= e($f['username'] ?: '管理员') ?></td>
          <td class="cell-muted"><?= (int) $f['download_count'] ?></td>
          <td>
            <?php if ((int) $f['status'] === 1): ?>
              <span class="badge badge-success">上架</span>
            <?php else: ?>
              <span class="badge badge-danger">下架</span>
            <?php endif; ?>
            <?php if ((int) $f['is_public'] !== 1): ?><span class="badge badge-warning">私有</span><?php endif; ?>
          </td>
          <td class="cell-muted"><?= e(fmt_time((string) $f['created_at'], 'm-d H:i')) ?></td>
          <td class="cell-actions">
            <div class="row-actions">
              <a class="btn btn-sm btn-ghost" href="<?= e(url('/admin/files.php?edit=' . $f['id'])) ?>">编辑</a>
              <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="file_id" value="<?= (int) $f['id'] ?>">
                <button class="btn btn-sm btn-ghost" type="submit"><?= (int) $f['status'] === 1 ? '下架' : '上架' ?></button>
              </form>
              <form method="post" data-confirm="删除后物理文件将一并移除，确定继续？">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="file_id" value="<?= (int) $f['id'] ?>">
                <button class="btn btn-sm btn-ghost" type="submit" style="color:var(--danger)">删除</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($total > $per): ?>
    <div class="card-pad">
      <?= render_pagination($page, $total, $per, ['q' => $q, 'cat' => $cat ?: null, 'status' => $status ?: null]) ?>
    </div>
  <?php endif; ?>
</div>

<?php require APP_PATH . '/views/admin_footer.php'; ?>

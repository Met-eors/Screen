<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

$user = current_user();

if (!setting_bool('allow_user_upload') && !is_admin()) {
    http_response_code(403);
    $pageTitle = '上传已关闭';
    require APP_PATH . '/views/header.php';
    echo '<div class="card"><div class="empty"><div class="empty-icon">' . icon('lock', 22) . '</div>'
        . '<div class="empty-title">暂未开放用户上传</div><div class="empty-text">管理员已关闭用户上传功能。如需上传，请联系站点管理员。</div>'
        . '<div style="margin-top:18px"><a class="btn" href="' . e(url('/index.php')) . '">返回文件库</a></div></div></div>';
    require APP_PATH . '/views/footer.php';
    exit;
}

$user = require_login();

$error = '';
$limit = upload_limit_bytes();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (rate_exceeded('upload', 30, 3600)) {
        $error = '本小时上传次数已达上限，请稍后再试。';
    } else {
        rate_hit('upload');
        $result = handle_upload(
            $_FILES['file'] ?? [],
            (string) ($_POST['title'] ?? ''),
            (string) ($_POST['description'] ?? ''),
            (int) ($_POST['category_id'] ?? 0) ?: null,
            (int) $user['id'],
            !empty($_POST['is_public'])
        );
        if ($result['ok']) {
            flash('success', '文件上传成功。');
            redirect('/file.php?id=' . $result['file']['token']);
        }
        $error = $result['error'];
    }
}

$pageTitle = '上传文件';
$activeNav = 'upload';
require APP_PATH . '/views/header.php';
?>
<div style="max-width:720px;margin:0 auto">
  <div class="section-head" style="margin-top:0">
    <div>
      <div class="section-title">上传新文件</div>
      <div class="section-sub">支持 <?= e(implode('、', array_slice(allowed_extensions(), 0, 12))) ?> 等格式，单个文件最大 <?= e(fmt_bytes($limit)) ?></div>
    </div>
  </div>

  <?php if ($error !== ''): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data" class="card card-pad">
    <?= csrf_field() ?>
    <input type="hidden" name="MAX_FILE_SIZE" value="<?= $limit ?>">

    <div class="form-grid">
      <div class="file-drop" data-drop>
        <input type="file" name="file" required aria-label="选择文件">
        <div class="drop-icon"><?= icon('upload', 26) ?></div>
        <div class="drop-title">点击选择或拖拽文件到此处</div>
        <div class="drop-file" data-drop-file></div>
      </div>

      <div class="form-row">
        <label class="label" for="title">文件标题</label>
        <input class="field-input" id="title" type="text" name="title" maxlength="200" placeholder="留空则使用文件名">
      </div>

      <div class="form-row">
        <label class="label" for="description">文件说明（可选）</label>
        <textarea class="field-input" id="description" name="description" maxlength="5000" placeholder="简单描述文件内容、版本或使用方式"></textarea>
      </div>

      <div class="form-row-2">
        <div class="form-row">
          <label class="label" for="category_id">分类</label>
          <select class="field-input" id="category_id" name="category_id">
            <option value="0">未分类</option>
            <?php foreach (categories_all() as $c): ?>
              <option value="<?= (int) $c['id'] ?>"><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-row">
          <span class="label">可见性</span>
          <div class="check-row" style="padding-top:9px">
            <input type="checkbox" id="is_public" name="is_public" value="1" checked>
            <label for="is_public">
              <span class="check-label">在文件库中公开</span>
              <span class="check-desc">取消勾选后仅可通过分享链接访问</span>
            </label>
          </div>
        </div>
      </div>

      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= icon('upload', 16) ?> 开始上传</button>
        <a class="btn btn-ghost" href="<?= e(url('/account.php')) ?>">我的文件</a>
      </div>
    </div>
  </form>

  <div class="auth-note">
    上传的文件会被重命名并以随机路径存储于站点根目录之外，URL 中不包含任何真实路径信息。
    允许的类型：<?= e(implode(', ', allowed_extensions())) ?>
  </div>
</div>
<?php require APP_PATH . '/views/footer.php'; ?>

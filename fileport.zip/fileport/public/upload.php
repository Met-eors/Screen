<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

$user = current_user();

if (!setting_bool('allow_user_upload') && !is_admin()) {
    http_response_code(403);
    $pageTitle = '上传已关闭';
    require APP_PATH . '/views/header.php';
    echo '<div class="card"><div class="empty"><div class="empty-icon">' . icon('lock', 22) . '</div>'
        . '<div class="empty-title">暂未开放用户上传</div><div class="empty-text">管理员已关闭用户上传功能。如需上传，请联系站点管理员。</div>'
        . '<div style="margin-top:18px"><a class="btn" href="' . e(url('/index.php')) . '">返回文件库</a></div></div></div>';
    require APP_PATH . '/views/footer.php';
    exit;
}

$user = require_login();

$error = '';
$limit = upload_limit_bytes();

// 用户配额：每日上传次数与存储占用
$dailyLimit = is_admin() ? 0 : setting_int('user_daily_uploads', 0);
$quotaMb    = is_admin() ? 0 : setting_int('user_storage_quota_mb', 0);
$quotaBytes = $quotaMb * 1048576;

$todayCount = (int) db_val(
    'SELECT COUNT(*) FROM files WHERE user_id = ? AND created_at >= ?',
    [$user['id'], date('Y-m-d 00:00:00')],
    0
);
$usedBytes = (int) db_val('SELECT COALESCE(SUM(size), 0) FROM files WHERE user_id = ?', [$user['id']], 0);

$reachedDaily = $dailyLimit > 0 && $todayCount >= $dailyLimit;
$reachedQuota = $quotaMb > 0 && $usedBytes >= $quotaBytes;
$reviewNeeded = setting_bool('upload_review') && !is_admin();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $incoming = (int) ($_FILES['file']['size'] ?? 0);

    if ($reachedDaily) {
        $error = '今日上传次数已达上限（' . $dailyLimit . ' 次），请明天再试。';
    } elseif ($reachedQuota) {
        $error = '存储空间已用满（配额 ' . $quotaMb . ' MB），请清理后再上传。';
    } elseif ($quotaMb > 0 && $usedBytes + $incoming > $quotaBytes) {
        $error = '剩余空间不足，当前可用 ' . fmt_bytes(max(0, $quotaBytes - $usedBytes)) . '。';
    } elseif (rate_exceeded('upload', 30, 3600)) {
        $error = '本小时上传次数已达上限，请稍后再试。';
    } else {
        rate_hit('upload');
        $result = handle_upload(
            $_FILES['file'] ?? [],
            (string) ($_POST['title'] ?? ''),
            (string) ($_POST['description'] ?? ''),
            (int) ($_POST['category_id'] ?? 0) ?: null,
            (int) $user['id'],
            !empty($_POST['is_public']),
            $reviewNeeded ? 2 : 1
        );
        if ($result['ok']) {
            flash('success', $reviewNeeded ? '上传成功，等待管理员审核后公开。' : '文件上传成功。');
            redirect('/file.php?id=' . $result['file']['token']);
        }
        $error = $result['error'];
    }
}

$pageTitle = '上传文件';
$activeNav = 'upload';
require APP_PATH . '/views/header.php';
?>
<div style="max-width:720px;margin:0 auto">
  <div class="section-head" style="margin-top:0">
    <div>
      <div class="section-title">上传新文件</div>
      <div class="section-sub">支持 <?= e(implode('、', array_slice(allowed_extensions(), 0, 12))) ?> 等格式，单个文件最大 <?= e(fmt_bytes($limit)) ?></div>
    </div>
  </div>

  <?php if ($error !== ''): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
  <?php endif; ?>

  <?php if ($reachedDaily || $reachedQuota): ?>
    <div class="card card-pad" style="margin-bottom:14px">
      <div class="empty" style="padding:18px 0">
        <div class="empty-title"><?= $reachedDaily ? '今日上传次数已用完' : '存储空间已用满' ?></div>
        <div class="empty-text">
          <?php if ($reachedDaily): ?>
            每天最多上传 <?= (int) $dailyLimit ?> 次，明天会重置。
          <?php else: ?>
            配额 <?= (int) $quotaMb ?> MB，已用 <?= e(fmt_bytes($usedBytes)) ?>。可删除自己的旧文件释放空间。
          <?php endif; ?>
        </div>
      </div>
      <div class="form-actions" style="justify-content:center">
        <a class="btn" href="<?= e(url('/account.php')) ?>">我的文件</a>
        <a class="btn btn-ghost" href="<?= e(url('/index.php')) ?>">返回文件库</a>
      </div>
    </div>
  <?php endif; ?>

  <?php if (!$reachedDaily && !$reachedQuota): ?>
  <form method="post" enctype="multipart/form-data" class="card card-pad">
    <?= csrf_field() ?>
    <input type="hidden" name="MAX_FILE_SIZE" value="<?= $limit ?>">

    <div class="form-grid">
      <div class="file-drop" data-drop>
        <input type="file" name="file" required aria-label="选择文件">
        <div class="drop-icon"><?= icon('upload', 26) ?></div>
        <div class="drop-title">点击选择或拖拽文件到此处</div>
        <div class="drop-file" data-drop-file></div>
      </div>

      <div class="form-row">
        <label class="label" for="title">文件标题</label>
        <input class="field-input" id="title" type="text" name="title" maxlength="200" placeholder="留空则使用文件名">
      </div>

      <div class="form-row">
        <label class="label" for="description">文件说明（可选）</label>
        <textarea class="field-input" id="description" name="description" maxlength="5000" placeholder="简单描述文件内容、版本或使用方式"></textarea>
      </div>

      <div class="form-row-2">
        <div class="form-row">
          <label class="label" for="category_id">分类</label>
          <select class="field-input" id="category_id" name="category_id">
            <option value="0">未分类</option>
            <?php foreach (categories_all() as $c): ?>
              <option value="<?= (int) $c['id'] ?>"><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-row">
          <span class="label">可见性</span>
          <div class="check-row" style="padding-top:9px">
            <input type="checkbox" id="is_public" name="is_public" value="1" checked>
            <label for="is_public">
              <span class="check-label">在文件库中公开</span>
              <span class="check-desc">取消勾选后仅可通过分享链接访问</span>
            </label>
          </div>
        </div>
      </div>

      <?php if ($reviewNeeded): ?>
        <div class="hint">提交后需管理员审核，通过后才会出现在文件库中。</div>
      <?php endif; ?>

      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= icon('upload', 16) ?> 开始上传</button>
        <a class="btn btn-ghost" href="<?= e(url('/account.php')) ?>">我的文件</a>
      </div>
    </div>
  </form>
  <?php endif; ?>

  <?php if ($dailyLimit > 0 || $quotaMb > 0): ?>
    <?php
    $quotaParts = [];
    if ($dailyLimit > 0) {
        $quotaParts[] = '今日已上传 ' . $todayCount . ' / ' . $dailyLimit . ' 次';
    }
    if ($quotaMb > 0) {
        $quotaParts[] = '存储已用 ' . fmt_bytes($usedBytes) . ' / ' . $quotaMb . ' MB';
    }
    ?>
    <div class="auth-note"><?= e(implode('，', $quotaParts)) ?></div>
  <?php endif; ?>
</div>
<?php require APP_PATH . '/views/footer.php'; ?>

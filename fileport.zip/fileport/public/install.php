<?php
declare(strict_types=1);

/**
 * 安装向导：检查环境 -> 连接数据库 -> 建表 -> 创建管理员 -> 写入配置
 * 安装完成后会生成 storage/installed.lock，建议随后删除本文件。
 */

$root       = dirname(__DIR__);
$lockFile   = $root . '/storage/installed.lock';
$configFile = $root . '/app/config.local.php';

$config = require $root . '/app/config.php';
$GLOBALS['config'] = $config;
require $root . '/app/helpers.php';

session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Lax']);
if (empty($_SESSION['install_csrf'])) {
    $_SESSION['install_csrf'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['install_csrf'];

$installed = is_file($lockFile);
$errors    = [];
$done      = false;
$form      = [
    'db_host' => '127.0.0.1', 'db_port' => '3306', 'db_name' => 'fileport',
    'db_user' => 'root', 'db_pass' => '', 'site_name' => '文件下载站',
    'admin_user' => '', 'admin_email' => '',
];

$checks = [
    'PHP 版本不低于 8.1'      => version_compare(PHP_VERSION, '8.1.0', '>='),
    'PDO MySQL 扩展已启用'    => extension_loaded('pdo_mysql'),
    'fileinfo 扩展已启用'     => extension_loaded('fileinfo'),
    'mbstring 扩展已启用'     => extension_loaded('mbstring'),
    'openssl 扩展已启用'      => extension_loaded('openssl'),
    'storage 目录可写'        => is_writable($root . '/storage'),
    'app 目录可写'            => is_writable($root . '/app'),
    '尚未安装（无 lock 文件）' => !$installed,
];
$checksOk = !in_array(false, $checks, true);

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && !$installed) {
    foreach ($form as $k => $_) {
        $form[$k] = trim((string) ($_POST[$k] ?? $form[$k]));
    }
    $adminPass  = (string) ($_POST['admin_pass'] ?? '');
    $adminPass2 = (string) ($_POST['admin_pass2'] ?? '');

    if (!hash_equals($csrf, (string) ($_POST['_csrf'] ?? ''))) {
        $errors[] = '请求校验失败，请刷新页面重试。';
    }
    if (!$checksOk) {
        $errors[] = '服务器环境检查未通过，请先解决上方标红的项目。';
    }
    if (!preg_match('/^[A-Za-z0-9_]+$/', $form['db_name'])) {
        $errors[] = '数据库名只能包含字母、数字和下划线。';
    }
    if (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $form['admin_user'])) {
        $errors[] = '管理员用户名需为 3-20 位字母、数字或下划线。';
    }
    if (!filter_var($form['admin_email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = '请填写有效的管理员邮箱。';
    }
    if (strlen($adminPass) < 8 || strlen($adminPass) > 72
        || !preg_match('/[A-Za-z]/', $adminPass) || !preg_match('/\d/', $adminPass)) {
        $errors[] = '管理员密码至少 8 位，且需同时包含字母和数字。';
    }
    if ($adminPass !== $adminPass2) {
        $errors[] = '两次输入的管理员密码不一致。';
    }
    if ($form['site_name'] === '' || mb_strlen($form['site_name']) > 60) {
        $errors[] = '站点名称不能为空，且不超过 60 个字符。';
    }

    if (!$errors) {
        try {
            $dsn = sprintf('mysql:host=%s;port=%d;charset=utf8mb4', $form['db_host'], (int) $form['db_port']);
            $pdo = new PDO($dsn, $form['db_user'], $form['db_pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $form['db_name'] . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
            $pdo->exec('USE `' . $form['db_name'] . '`');

            $schema = (string) file_get_contents($root . '/sql/schema.sql');
            $schema = preg_replace('/^\s*--.*$/m', '', $schema) ?? $schema;
            foreach (array_filter(array_map('trim', explode(';', $schema))) as $stmt) {
                if ($stmt !== '') {
                    $pdo->exec($stmt);
                }
            }

            $exists = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
            if ($exists > 0) {
                throw new RuntimeException('该数据库中已存在用户数据。请换一个数据库名，或先手动清空数据表。');
            }

            $now = date('Y-m-d H:i:s');
            $stmt = $pdo->prepare(
                'INSERT INTO users (username, email, password_hash, role, status, created_at) VALUES (?, ?, ?, ?, 1, ?)'
            );
            $stmt->execute([
                $form['admin_user'],
                $form['admin_email'],
                password_hash($adminPass, PASSWORD_DEFAULT),
                'admin',
                $now,
            ]);

            $defaults = [
                'site_name' => $form['site_name'],
                'site_tagline' => '',
                'downloads_per_minute' => '5',
                'max_upload_mb' => '100',
                'allow_user_upload' => '1',
                'allow_register' => '1',
                'require_login_download' => '0',
                'maintenance_mode' => '0',
                'captcha_enabled' => '1',
                'login_max_attempts' => '5',
                'login_lock_minutes' => '15',
                'per_page' => '12',
                'allowed_extensions' => 'zip,rar,7z,tar,gz,txt,md,pdf,doc,docx,xls,xlsx,ppt,pptx,csv,jpg,jpeg,png,gif,webp,bmp,mp3,wav,flac,mp4,mkv,mov,webm,apk,epub',
            ];
            $ins = $pdo->prepare('INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)');
            foreach ($defaults as $k => $v) {
                $ins->execute([$k, $v]);
            }
            $pdo->prepare('INSERT INTO categories (name, slug, sort, created_at) VALUES (?, ?, ?, ?)')
                ->execute(['默认分类', 'default', 0, $now]);

            $localConfig = "<?php\n// 由安装向导自动生成于 " . $now . "，包含敏感凭据，请勿提交到版本库。\nreturn " . var_export([
                'db' => [
                    'host' => $form['db_host'],
                    'port' => (int) $form['db_port'],
                    'name' => $form['db_name'],
                    'user' => $form['db_user'],
                    'pass' => $form['db_pass'],
                ],
                'app' => [
                    'key' => bin2hex(random_bytes(32)),
                    'debug' => false,
                ],
                'paths' => [
                    'storage' => $root . '/storage/files',
                ],
            ], true) . ";\n";

            if (@file_put_contents($configFile, $localConfig, LOCK_EX) === false) {
                throw new RuntimeException('无法写入 app/config.local.php，请检查目录权限。');
            }
            @chmod($configFile, 0640);

            @file_put_contents($lockFile, 'installed at ' . $now . PHP_EOL, LOCK_EX);
            $done = true;
        } catch (Throwable $e) {
            $errors[] = '安装失败：' . $e->getMessage();
        }
    }
}

$title = $installed ? '已安装' : ($done ? '安装完成' : '安装向导');
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> · 文件下载站</title>
<meta name="robots" content="noindex, nofollow">
<link rel="stylesheet" href="<?= e(url('/assets/css/app.css')) ?>">
</head>
<body>
<main class="container page" style="max-width:820px">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:26px">
    <span class="brand-mark"><?= icon('download', 18) ?></span>
    <div>
      <div style="font-weight:650;font-size:15px">文件下载站 安装向导</div>
    </div>
  </div>

<?php if ($installed): ?>
  <div class="card card-pad">
    <h1 style="font-size:20px;font-weight:680">系统已安装</h1>
    <p style="color:var(--text-2);margin-top:8px;font-size:14px">
      检测到 storage/installed.lock，安装程序已锁定。如需重新安装，请删除该文件并清空数据库。
    </p>
    <div class="form-actions" style="margin-top:18px">
      <a class="btn btn-primary" href="<?= e(url('/admin/login.php')) ?>">进入后台登录</a>
      <a class="btn" href="<?= e(url('/index.php')) ?>">访问前台</a>
    </div>
    <div class="auth-note" style="margin-top:18px">
      安全提示：请立即删除 public/install.php，避免暴露环境信息。
    </div>
  </div>

<?php elseif ($done): ?>
  <div class="card card-pad">
    <div class="badge badge-success">安装成功</div>
    <h1 style="font-size:20px;font-weight:680;margin-top:12px">站点已就绪</h1>
    <p style="color:var(--text-2);margin-top:8px;font-size:14px">
      数据库表结构、管理员账号与默认配置已创建。配置文件位于 app/config.local.php。
    </p>
    <div class="meta-list" style="margin-top:16px">
      <div class="meta-row"><span class="meta-key">管理员账号</span><span class="meta-val"><?= e($form['admin_user']) ?></span></div>
      <div class="meta-row"><span class="meta-key">后台地址</span><span class="meta-val mono"><?= e(url('/admin/login.php')) ?></span></div>
      <div class="meta-row"><span class="meta-key">存储目录</span><span class="meta-val mono"><?= e($root . '/storage/files') ?></span></div>
    </div>
    <div class="alert alert-warning" style="margin-top:18px">
      请立即删除 public/install.php，并确认 storage 目录无法通过 Web 直接访问。
    </div>
    <div class="form-actions" style="margin-top:10px">
      <a class="btn btn-primary" href="<?= e(url('/admin/login.php')) ?>">进入后台</a>
      <a class="btn" href="<?= e(url('/index.php')) ?>">打开前台</a>
    </div>
  </div>

<?php else: ?>
  <?php if ($errors): ?>
    <?php foreach ($errors as $err): ?>
      <div class="alert alert-error"><?= e($err) ?></div>
    <?php endforeach; ?>
  <?php endif; ?>

  <div class="card" style="margin-bottom:18px">
    <div class="card-head"><div class="card-title">环境检查</div><span class="badge">PHP <?= e(PHP_VERSION) ?></span></div>
    <div class="card-pad">
      <div class="meta-list">
        <?php foreach ($checks as $label => $ok): ?>
          <div class="meta-row">
            <span class="meta-key"><?= e($label) ?></span>
            <span class="meta-val">
              <?php if ($ok): ?>
                <span class="badge badge-success">通过</span>
              <?php else: ?>
                <span class="badge badge-danger">未通过</span>
              <?php endif; ?>
            </span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <form method="post" class="card card-pad">
    <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">
    <div class="card-title">数据库与管理员</div>
    <p class="card-desc" style="margin-top:4px">数据库若不存在，安装程序会尝试自动创建。</p>

    <div class="form-grid" style="margin-top:18px">
      <div class="form-row-2">
        <div class="form-row">
          <label class="label" for="db_host">数据库主机</label>
          <input class="field-input" id="db_host" type="text" name="db_host" value="<?= e($form['db_host']) ?>" required maxlength="100">
        </div>
        <div class="form-row">
          <label class="label" for="db_port">端口</label>
          <input class="field-input" id="db_port" type="number" name="db_port" value="<?= e($form['db_port']) ?>" required min="1" max="65535">
        </div>
      </div>
      <div class="form-row">
        <label class="label" for="db_name">数据库名</label>
        <input class="field-input" id="db_name" type="text" name="db_name" value="<?= e($form['db_name']) ?>" required maxlength="64">
      </div>
      <div class="form-row-2">
        <div class="form-row">
          <label class="label" for="db_user">数据库用户</label>
          <input class="field-input" id="db_user" type="text" name="db_user" value="<?= e($form['db_user']) ?>" required maxlength="64" autocomplete="off">
        </div>
        <div class="form-row">
          <label class="label" for="db_pass">数据库密码</label>
          <input class="field-input" id="db_pass" type="password" name="db_pass" value="<?= e($form['db_pass']) ?>" maxlength="128" autocomplete="new-password">
        </div>
      </div>

      <div style="height:1px;background:var(--border);margin:4px 0"></div>

      <div class="form-row">
        <label class="label" for="site_name">站点名称</label>
        <input class="field-input" id="site_name" type="text" name="site_name" value="<?= e($form['site_name']) ?>" required maxlength="60">
      </div>
      <div class="form-row-2">
        <div class="form-row">
          <label class="label" for="admin_user">管理员用户名</label>
          <input class="field-input" id="admin_user" type="text" name="admin_user" value="<?= e($form['admin_user']) ?>" required minlength="3" maxlength="20" pattern="[A-Za-z0-9_]{3,20}" autocomplete="off">
        </div>
        <div class="form-row">
          <label class="label" for="admin_email">管理员邮箱</label>
          <input class="field-input" id="admin_email" type="email" name="admin_email" value="<?= e($form['admin_email']) ?>" required maxlength="190" autocomplete="off">
        </div>
      </div>
      <div class="form-row-2">
        <div class="form-row">
          <label class="label" for="admin_pass">管理员密码</label>
          <input class="field-input" id="admin_pass" type="password" name="admin_pass" required minlength="8" maxlength="72" autocomplete="new-password">
        </div>
        <div class="form-row">
          <label class="label" for="admin_pass2">确认密码</label>
          <input class="field-input" id="admin_pass2" type="password" name="admin_pass2" required maxlength="72" autocomplete="new-password">
        </div>
      </div>
      <span class="hint">密码至少 8 位，需同时包含字母和数字。</span>

      <div class="form-actions">
        <button class="btn btn-primary" type="submit"<?= $checksOk ? '' : ' disabled' ?>>开始安装</button>
        <span class="hint">安装完成后请删除本文件</span>
      </div>
    </div>
  </form>
<?php endif; ?>
</main>
</body>
</html>

<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

$q    = trim((string) ($_GET['q'] ?? ''));
$q    = mb_substr($q, 0, 80);
$cat  = max(0, (int) ($_GET['cat'] ?? 0));
$sort = ($_GET['sort'] ?? 'new') === 'hot' ? 'hot' : 'new';
$page = max(1, (int) ($_GET['page'] ?? 1));
$per  = max(6, min(48, setting_int('per_page', 12)));

$where  = ['f.status = 1', 'f.is_public = 1'];
$params = [];
if ($q !== '') {
    $like     = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
    $where[]  = '(f.title LIKE ? OR f.description LIKE ? OR f.original_name LIKE ?)';
    array_push($params, $like, $like, $like);
}
if ($cat > 0) {
    $where[]  = 'f.category_id = ?';
    $params[] = $cat;
}
$whereSql = implode(' AND ', $where);

$total = (int) db_val("SELECT COUNT(*) FROM files f WHERE {$whereSql}", $params, 0);
$order = $sort === 'hot' ? 'f.download_count DESC, f.id DESC' : 'f.id DESC';
$offset = ($page - 1) * $per;
$files  = db_all(
    "SELECT f.*, c.name AS category_name
     FROM files f LEFT JOIN categories c ON c.id = f.category_id
     WHERE {$whereSql} ORDER BY {$order} LIMIT {$per} OFFSET {$offset}",
    $params
);

$stats = db_one(
    'SELECT COUNT(*) AS total_files, COALESCE(SUM(download_count), 0) AS total_downloads
     FROM files WHERE status = 1 AND is_public = 1'
) ?? ['total_files' => 0, 'total_downloads' => 0];

$pageTitle = $q !== '' ? '搜索：' . $q : '文件库';
$activeNav = 'files';
require APP_PATH . '/views/header.php';
?>

<section class="hero">
  <h1><?= $q !== '' ? '找到 ' . $total . ' 个相关文件' : '文件库' ?></h1>

  <form class="hero-search" action="<?= e(url('/index.php')) ?>" method="get" role="search">
    <input class="field-input" type="search" name="q" value="<?= e($q) ?>" placeholder="输入文件名或关键词" maxlength="80" aria-label="搜索文件">
    <?php if ($cat > 0): ?><input type="hidden" name="cat" value="<?= $cat ?>"><?php endif; ?>
    <button class="btn btn-primary" type="submit"><?= icon('search', 16) ?> 搜索</button>
  </form>

  <div class="hero-stats">
    <div class="hero-stat"><strong><?= number_format((int) $stats['total_files']) ?></strong><span>个公开文件</span></div>
    <div class="hero-stat"><strong><?= number_format((int) $stats['total_downloads']) ?></strong><span>次下载</span></div>
    <div class="hero-stat"><strong><?= e(setting('downloads_per_minute')) ?> 次</strong><span>每分钟下载上限 / IP</span></div>
  </div>
</section>

<div class="section-head">
  <div class="section-title"><?= $q !== '' ? '搜索结果' : '最新文件' ?></div>
  <div class="toolbar">
    <a class="chip<?= $sort === 'new' ? ' is-active' : '' ?>" href="?<?= e(http_build_query(['q' => $q, 'cat' => $cat, 'sort' => 'new'])) ?>">最新</a>
    <a class="chip<?= $sort === 'hot' ? ' is-active' : '' ?>" href="?<?= e(http_build_query(['q' => $q, 'cat' => $cat, 'sort' => 'hot'])) ?>">最热</a>
  </div>
</div>

<?php if (categories_all()): ?>
  <div class="filter-bar">
    <a class="chip<?= $cat === 0 ? ' is-active' : '' ?>" href="?<?= e(http_build_query(['q' => $q, 'sort' => $sort])) ?>">全部</a>
    <?php foreach (categories_all() as $c): ?>
      <a class="chip<?= $cat === (int) $c['id'] ? ' is-active' : '' ?>"
         href="?<?= e(http_build_query(['q' => $q, 'cat' => (int) $c['id'], 'sort' => $sort])) ?>"><?= e($c['name']) ?></a>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php if (!$files): ?>
  <div class="card">
    <div class="empty">
      <div class="empty-icon"><?= icon('file', 22) ?></div>
      <div class="empty-title"><?= $q !== '' ? '没有匹配的文件' : '还没有公开文件' ?></div>
      <div class="empty-text"><?= $q !== '' ? '试试更换关键词，或切换到其他分类。' : '管理员上传文件后会显示在这里。' ?></div>
    </div>
  </div>
<?php else: ?>
  <div class="file-grid">
    <?php foreach ($files as $f): $color = ext_color((string) $f['ext']); ?>
      <article class="file-card">
        <div class="file-top">
          <div class="file-icon <?= e($color) ?>"><?= e($f['ext']) ?></div>
          <div>
            <a class="file-name" href="<?= e(url('/file.php?id=' . $f['token'])) ?>"><?= e($f['title']) ?></a>
            <div class="file-meta" style="margin-top:3px">
              <span><?= e(fmt_bytes((int) $f['size'])) ?></span>
              <span class="meta-dot"></span>
              <span><?= e($f['category_name'] ?: '未分类') ?></span>
            </div>
          </div>
        </div>

        <?php if (trim((string) $f['description']) !== ''): ?>
          <div class="file-desc"><?= e(excerpt((string) $f['description'], 70)) ?></div>
        <?php endif; ?>

        <div class="file-meta">
          <span><?= icon('download', 13) ?> <?= (int) $f['download_count'] ?> 次下载</span>
          <span class="meta-dot"></span>
          <span><?= e(fmt_ago((string) $f['created_at'])) ?></span>
        </div>

        <div class="file-actions">
          <a class="btn btn-primary btn-sm" href="<?= e(url('/download.php?t=' . $f['token'])) ?>"><?= icon('download', 15) ?> 下载</a>
          <a class="btn btn-sm" href="<?= e(url('/file.php?id=' . $f['token'])) ?>">详情</a>
        </div>
      </article>
    <?php endforeach; ?>
  </div>

  <?= render_pagination($page, $total, $per, ['q' => $q, 'cat' => $cat ?: null, 'sort' => $sort]) ?>
<?php endif; ?>

<?php require APP_PATH . '/views/footer.php'; ?>

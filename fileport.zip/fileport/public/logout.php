<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    redirect('/index.php');
}

logout_user();
session_start();
flash('success', '你已安全退出登录。');
redirect('/index.php');

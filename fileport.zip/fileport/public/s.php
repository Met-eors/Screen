<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

$token = (string) ($_GET['t'] ?? '');
$share = find_share($token);

if (!$share) {
    http_response_code(404);
    $pageTitle = '分享不存在';
    require APP_PATH . '/views/header.php';
    echo '<div class="card"><div class="empty"><div class="empty-icon">' . icon('close', 22) . '</div>'
        . '<div class="empty-title">分享链接无效</div><div class="empty-text">链接可能不完整，或分享已被删除。</div>'
        . '<div style="margin-top:18px"><a class="btn" href="' . e(url('/index.php')) . '">返回文件库</a></div></div></div>';
    require APP_PATH . '/views/footer.php';
    exit;
}

$err = share_error($share);
if ($err !== null) {
    http_response_code(410);
    $pageTitle = '分享不可用';
    require APP_PATH . '/views/header.php';
    echo '<div class="card"><div class="empty"><div class="empty-icon">' . icon('clock', 22) . '</div>'
        . '<div class="empty-title">分享链接不可用</div><div class="empty-text">' . e($err) . '</div>'
        . '<div style="margin-top:18px"><a class="btn" href="' . e(url('/index.php')) . '">返回文件库</a></div></div></div>';
    require APP_PATH . '/views/footer.php';
    exit;
}

$needsPassword = !empty($share['password_hash']);
$unlocked      = share_is_unlocked($share);
$error         = '';

if ($needsPassword && !$unlocked && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (rate_exceeded('share_pw', 10, 300)) {
        $error = '尝试次数过多，请 5 分钟后再试。';
    } else {
        rate_hit('share_pw');
        $input = (string) ($_POST['share_password'] ?? '');
        if ($input !== '' && password_verify($input, (string) $share['password_hash'])) {
            $_SESSION['share_ok'][(int) $share['id']] = true;
            audit('share_unlock', '分享 ' . substr((string) $share['token'], 0, 8) . '...', null);
            redirect('/s.php?t=' . $share['token']);
        }
        db_exec(
            'INSERT INTO download_logs (file_id, share_id, user_id, ip, user_agent, result, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$share['file_id'], $share['id'], current_user()['id'] ?? null, client_ip(),
                mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255), 'password', now()]
        );
        $error = '访问密码不正确。';
    }
}

$pageTitle = '分享文件';
$activeNav = 'files';
require APP_PATH . '/views/header.php';
$color = ext_color((string) $share['ext']);
?>
<div class="auth-wrap" style="min-height:auto;padding-top:24px">
  <div class="card card-pad" style="width:min(520px,100%)">
    <div class="detail-head">
      <div class="detail-icon file-icon <?= e($color) ?>"><?= e($share['ext']) ?></div>
      <div style="min-width:0">
        <h1 class="detail-title" style="font-size:19px"><?= e($share['title']) ?></h1>
        <div class="detail-sub"><?= e($share['original_name']) ?> · <?= e(fmt_bytes((int) $share['size'])) ?> · <?= strtoupper(e((string) $share['ext'])) ?></div>
      </div>
    </div>

    <div class="meta-list" style="margin-top:16px">
      <div class="meta-row"><span class="meta-key">分享者</span><span class="meta-val"><?= $share['created_by'] ? '站点用户' : '管理员' ?></span></div>
      <div class="meta-row"><span class="meta-key">有效期</span><span class="meta-val"><?= $share['expires_at'] ? e(fmt_time((string) $share['expires_at'])) . ' 截止' : '长期有效' ?></span></div>
      <div class="meta-row">
        <span class="meta-key">下载额度</span>
        <span class="meta-val">
          <?php if ((int) $share['max_downloads'] > 0): ?>
            剩余 <?= max(0, (int) $share['max_downloads'] - (int) $share['download_count']) ?> 次
          <?php else: ?>
            不限次数
          <?php endif; ?>
        </span>
      </div>
    </div>

    <?php if ($error !== ''): ?>
      <div class="alert alert-error" style="margin-top:16px"><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($needsPassword && !$unlocked): ?>
      <form method="post" class="form-grid" style="margin-top:18px">
        <?= csrf_field() ?>
        <div class="form-row">
          <label class="label" for="share_password">此分享已加密，请输入访问密码</label>
          <input class="field-input" id="share_password" type="password" name="share_password" required maxlength="72" autocomplete="off" autofocus>
        </div>
        <button class="btn btn-primary btn-block" type="submit"><?= icon('lock', 16) ?> 验证并查看</button>
      </form>
    <?php else: ?>
      <a class="btn btn-primary btn-block" style="margin-top:18px" href="<?= e(url('/download.php?s=' . $share['token'])) ?>">
        <?= icon('download', 17) ?> 下载文件
      </a>
      <div class="hint" style="margin-top:10px;text-align:center">
        下载将计入分享额度
      </div>
    <?php endif; ?>

    <div class="auth-note" style="margin-top:20px">
      请勿将链接转发到公开场合。
    </div>
  </div>
</div>
<?php require APP_PATH . '/views/footer.php'; ?>

# 文件下载站

基于原生 PHP + MySQL 构建，带完整后台管理、账号体系与多层防护。对外只暴露随机令牌，真实存储路径与文件名不会出现在任何 URL 中。

界面为浅色现代风格，自适应桌面与移动端，支持系统深色模式。代码不依赖任何前端框架与 CDN 资源。

## 界面预览

| 文件库首页 | 文件详情 |
| --- | --- |
| ![文件库首页](docs/screenshots/home.png) | ![文件详情](docs/screenshots/detail.png) |

| 后台仪表盘 | 后台文件管理 |
| --- | --- |
| ![后台仪表盘](docs/screenshots/admin.png) | ![后台文件管理](docs/screenshots/admin-files.png) |

移动端：

![移动端首页](docs/screenshots/mobile.png)

## 功能一览

**前台**

- 文件库：搜索、分类筛选、按最新/最热排序、分页
- 文件详情：大小、类型、分类、下载次数、SHA-256 校验值
- 安全下载：随机令牌链接、单 IP 每分钟限流、强制附件下载
- 账号：注册（含算术人机验证）、登录、修改密码、我的文件、我的分享
- 用户上传：受后台开关控制，可设置公开或私有
- 分享链接：密码保护、有效期、下载次数上限

**后台**（`/admin/`）

- 仪表盘：文件数、下载量、用户数、限流拦截、7 日趋势图、热门文件、运行状态
- 文件管理：上传、编辑、上下架、删除（同步删除物理文件）
- 分类管理：增删改、排序、删除时自动解绑文件
- 分享管理：查看、复制链接、撤销、清理失效分享
- 用户管理：搜索、禁用、角色调整、重置密码、删除
- 日志审计：下载日志（含结果与 UA）、后台操作审计，可按 IP 与结果筛选
- IP 封禁：支持单个 IP 与 CIDR 网段，可设时长或永久
- 系统设置：站点信息、公告、限流次数、上传大小、上传开关、注册开关、验证码、登录锁定、维护模式

## 环境要求

| 项目 | 要求 |
| --- | --- |
| PHP | 8.1 及以上，扩展：pdo_mysql、fileinfo、mbstring、openssl |
| MySQL | 5.7+ / MariaDB 10.3+，字符集 utf8mb4 |
| Web 服务器 | Nginx 或 Apache，站点根目录必须指向 `public/` |

## 快速开始

1. 上传代码到服务器，例如 `/var/www/fileport`。
2. 配置站点根目录为 `/var/www/fileport/public`，参考 `docs/nginx.conf.example`。
3. 赋予写权限：

   ```bash
   chown -R www-data:www-data storage
   chmod -R 750 storage
   chmod 640 app/config.local.php 2>/dev/null || true
   ```

4. 浏览器访问 `https://你的域名/install.php`，填写数据库信息与管理员账号。安装程序会自动建库建表、写入 `app/config.local.php` 并生成 `storage/installed.lock`。
5. 安装完成后**立即删除 `public/install.php`**。

若无法使用安装向导，可手动导入 `sql/schema.sql`，再复制 `app/config.php` 为 `app/config.local.php` 并填写数据库信息，最后手动插入管理员账号（密码用 `password_hash()` 生成）。

## 目录结构

```
fileport/
├── app/                    应用核心（位于 Web 根之外）
│   ├── bootstrap.php       引导：配置、会话、安全头、全局 CSRF
│   ├── config.php          默认配置（可被 config.local.php 覆盖）
│   ├── db.php              PDO 封装，全部使用预处理语句
│   ├── security.php        会话、限流、封禁、审计、验证码
│   ├── auth.php            登录、注册、密码策略
│   ├── files.php           上传校验、存储、下载响应、分享
│   ├── settings.php        系统设置读写与默认值
│   ├── helpers.php         转义、URL、格式化、图标
│   └── views/              公共头部与页脚
├── public/                 Web 根目录
│   ├── index.php           文件库
│   ├── file.php            文件详情
│   ├── download.php        安全下载入口
│   ├── s.php               分享访问页
│   ├── login.php register.php logout.php account.php upload.php
│   ├── install.php         安装向导（装完请删除）
│   ├── admin/              后台页面
│   └── assets/             CSS 与少量原生 JS
├── storage/                存储目录（禁止 Web 访问）
│   ├── files/              实际文件，随机文件名、按年月分目录
│   └── .htaccess           Apache 拒绝访问
├── sql/schema.sql          数据库结构
├── bin/maintenance.php     定时清理脚本
└── docs/nginx.conf.example Nginx 部署示例
```

## 安全设计

### 注入与跨站

| 风险 | 处理方式 |
| --- | --- |
| SQL 注入 | 全部查询使用 PDO 预处理，`ATTR_EMULATE_PREPARES = false`；排序、分页等动态片段只接受白名单值 |
| XSS | 所有输出经 `e()` 转义；CSP 限制 `script-src 'self'`，页面无内联脚本 |
| CSRF | 全局拦截所有非 GET 请求，校验会话令牌；令牌在登录后轮换 |
| 点击劫持 | `X-Frame-Options: DENY` 与 `frame-ancestors 'none'` |
| MIME 嗅探 | `X-Content-Type-Options: nosniff`，下载统一 `Content-Disposition: attachment` |

### 上传与文件

- 扩展名白名单 + 系统级黑名单（php、phtml、sh、jsp、exe 等），黑名单优先级最高
- `finfo` 检测真实 MIME，拦截伪装成图片的脚本；图片额外用 `getimagesize` 校验
- 文件重命名为 32 字节随机名、无扩展名，按 `年/月` 分目录存于 Web 根之外
- 上传大小同时受后台设置与 `upload_max_filesize`、`post_max_size` 约束，取最小值
- 下载时用 `realpath` 校验路径必须落在存储根目录内，阻断目录穿越
- 对外链接只包含 32 位十六进制令牌，无法推测、无法遍历

### 账号与会话

- 密码 bcrypt（`PASSWORD_DEFAULT`），强度要求 8 位以上且含字母与数字，算法升级时自动 rehash
- 登录失败累计锁定（次数与时长可配），并提供每 IP 每分钟 12 次的尝试限速
- 登录成功与修改密码后调用 `session_regenerate_id(true)`，防止会话固定
- Cookie：`HttpOnly`、`SameSite=Lax`、HTTPS 下自动加 `Secure`
- 空闲超时 2 小时、绝对超时 12 小时
- 账号枚举防护：账号不存在时也执行一次哈希比对，响应文案统一

### 滥用防护

- 单 IP 每分钟下载次数限制，超出返回 429 并给出等待秒数
- 上传、注册、分享密码尝试均有独立限速窗口
- IP 封禁支持单个地址与 CIDR 网段，命中后全站立即返回 403
- 所有下载与后台操作写入日志，可在后台筛选追溯

## 扩展功能

1. **带权限的分享链接**：密码、有效期、下载次数上限，可随时撤销；分享页不暴露文件令牌。
2. **日志与审计**：下载日志记录 IP、UA、结果（成功/限流/密码错误）；后台操作记录操作者、对象、详情与 IP。
3. **IP 风控**：CIDR 网段封禁 + 限流触发统计，后台可直接查看近 24 小时被拦截最多的 IP。
4. **文件完整性校验**：上传时计算 SHA-256，详情页展示，便于用户核对。
5. **分类与检索**：分类管理、关键词搜索、热度排序。
6. **维护模式与公告**：一键切换 503 维护页，管理员仍可进入后台；公告条支持全站提示。
7. **定时维护脚本**：清理过期日志、失效分享、过期封禁与孤立文件。

## 运维

**调整上传上限**（三者需同时放大）：

```ini
; php.ini
upload_max_filesize = 200M
post_max_size = 210M
max_execution_time = 300
```

Nginx 另需 `client_max_body_size 210M;`。后台「系统设置」中的数值只能调小，实际生效值取两者较小者，设置页会实时显示。

**定时任务**：

```cron
0 4 * * * /usr/bin/php /var/www/fileport/bin/maintenance.php >/dev/null 2>&1
```

**备份**：数据库用 `mysqldump`，文件直接打包 `storage/files` 与 `app/config.local.php`。两者需同时备份，否则记录与文件会不一致。

**HTTPS**：强烈建议全站 HTTPS。会话 Cookie 的 `Secure` 标记会自动跟随协议，HSTS 也会自动下发。

## 常见问题

**下载 404 / 文件不存在**
检查 `storage/files` 权限与 `app/config.local.php` 中的 `paths.storage` 是否为正确的绝对路径（迁移服务器后常需修改）。

**上传提示超过服务器允许的大小**
先看后台设置页显示的「实际生效上限」，再对照 php.ini 与 Nginx 的 `client_max_body_size`。

**后台打不开，提示无权访问**
只有 `role = admin` 的账号能进入后台。可在数据库中执行：
`UPDATE users SET role = 'admin' WHERE username = '你的账号';`

**忘记管理员密码**
用 PHP CLI 生成哈希后更新数据库：

```bash
php -r "echo password_hash('NewPass123', PASSWORD_DEFAULT), PHP_EOL;"
```

```sql
UPDATE users SET password_hash = '上一步的输出', failed_attempts = 0, locked_until = NULL WHERE username = 'admin';
```

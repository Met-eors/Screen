-- 从 1.0 升级到 1.1
-- 已有部署执行本文件即可，全新安装无需执行（schema.sql 已包含）

SET NAMES utf8mb4;

-- 文件状态新增「待审核」取值，仅改注释，不改变存储类型
ALTER TABLE `files`
  MODIFY COLUMN `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1=上架 0=下架 2=待审核';

-- 防爬拦截记录
CREATE TABLE IF NOT EXISTS `crawler_hits` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip` VARCHAR(45) NOT NULL,
  `user_agent` VARCHAR(255) NULL DEFAULT NULL,
  `reason` VARCHAR(32) NOT NULL COMMENT 'empty_ua/ua_keyword/page_rate/honeypot/manual',
  `path` VARCHAR(255) NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ip_time` (`ip`, `created_at`),
  KEY `idx_reason_time` (`reason`, `created_at`),
  KEY `idx_time` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 新增设置项由代码内置默认值兜底，首次保存设置时自动写入 settings 表

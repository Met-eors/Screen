-- 从 1.1 升级到 1.2
-- 已有部署执行本文件即可，全新安装无需执行（schema.sql 已包含）

SET NAMES utf8mb4;

-- 用户级上传权限：覆盖全站的「开放用户上传」开关
-- NULL = 跟随全局设置，1 = 允许上传，0 = 禁止上传
ALTER TABLE `users`
  ADD COLUMN `can_upload` TINYINT(1) NULL DEFAULT NULL
    COMMENT '上传权限：NULL=跟随全局设置 1=允许 0=禁止'
    AFTER `status`;

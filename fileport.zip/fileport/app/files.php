<?php
declare(strict_types=1);

/**
 * 文件业务层：上传校验、存储、查询、分享
 */

function ini_to_bytes(string $value): int
{
    $value = trim($value);
    if ($value === '') {
        return 0;
    }
    $unit = strtolower(substr($value, -1));
    $num  = (float) $value;
    return (int) match ($unit) {
        'g' => $num * 1024 ** 3,
        'm' => $num * 1024 ** 2,
        'k' => $num * 1024,
        default => $num,
    };
}

/** 站点允许的最大上传字节数（取后台设置与 PHP 配置的较小值） */
function upload_limit_bytes(): int
{
    $app  = max(1, setting_int('max_upload_mb', 100)) * 1024 * 1024;
    $ini  = ini_to_bytes((string) ini_get('upload_max_filesize')) ?: PHP_INT_MAX;
    $post = ini_to_bytes((string) ini_get('post_max_size')) ?: PHP_INT_MAX;
    $post = $post > 1048576 ? $post - 1048576 : $post;
    return (int) max(1, min($app, $ini, $post));
}

function storage_root(): string
{
    return rtrim((string) $GLOBALS['config']['paths']['storage'], '/');
}

/** 把相对路径安全地拼成绝对路径，并阻断目录穿越 */
function storage_abs(string $relative): ?string
{
    $relative = str_replace('\\', '/', $relative);
    if ($relative === '' || str_contains($relative, '..') || str_starts_with($relative, '/')) {
        return null;
    }
    $root = realpath(storage_root());
    if ($root === false) {
        return null;
    }
    $abs = $root . '/' . $relative;
    $real = realpath($abs);
    if ($real === false || !str_starts_with($real, $root . DIRECTORY_SEPARATOR)) {
        return null;
    }
    return $real;
}

/** 清理用户提交的文件名，去掉路径、控制字符与引号类危险字符 */
function clean_filename(string $name): string
{
    $name = str_replace(['\\', '/', "\0"], '', $name);
    $name = basename($name);
    $name = preg_replace('/[\x00-\x1F\x7F]/u', '', $name) ?? '';
    $name = str_replace(['"', "'", '<', '>', '|', ':', '*', '?'], '_', $name);
    $name = trim($name, " .\t");
    if ($name === '') {
        $name = 'download';
    }
    if (mb_strlen($name) > 180) {
        $ext  = pathinfo($name, PATHINFO_EXTENSION);
        $base = mb_substr(pathinfo($name, PATHINFO_FILENAME), 0, 160);
        $name = $ext !== '' ? $base . '.' . $ext : $base;
    }
    return $name;
}

/** 常见扩展名 -> MIME（仅用于下载响应，不用于安全判断） */
function mime_for_ext(string $ext, string $fallback = 'application/octet-stream'): string
{
    static $map = [
        'txt' => 'text/plain; charset=utf-8', 'md' => 'text/plain; charset=utf-8',
        'csv' => 'text/csv; charset=utf-8', 'pdf' => 'application/pdf',
        'zip' => 'application/zip', 'rar' => 'application/vnd.rar', '7z' => 'application/x-7z-compressed',
        'tar' => 'application/x-tar', 'gz' => 'application/gzip',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls' => 'application/vnd.ms-excel',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt' => 'application/vnd.ms-powerpoint',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif',
        'webp' => 'image/webp', 'bmp' => 'image/bmp', 'svg' => 'image/svg+xml',
        'mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'flac' => 'audio/flac',
        'mp4' => 'video/mp4', 'mkv' => 'video/x-matroska', 'mov' => 'video/quicktime', 'webm' => 'video/webm',
        'apk' => 'application/vnd.android.package-archive', 'epub' => 'application/epub+zip',
    ];
    return $map[strtolower($ext)] ?? $fallback;
}

/**
 * 处理上传。返回 ['ok'=>bool, 'error'=>string, 'file'=>array]
 */
function handle_upload(array $file, string $title, string $description, ?int $categoryId, ?int $userId, bool $isPublic): array
{
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['ok' => false, 'error' => '上传参数无效。', 'file' => []];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $msg = match ($file['error']) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => '文件超过服务器允许的大小。',
            UPLOAD_ERR_PARTIAL   => '文件只上传了一部分，请重试。',
            UPLOAD_ERR_NO_FILE   => '请选择要上传的文件。',
            UPLOAD_ERR_NO_TMP_DIR, UPLOAD_ERR_CANT_WRITE => '服务器存储不可用，请联系管理员。',
            default              => '上传失败，请重试。',
        };
        return ['ok' => false, 'error' => $msg, 'file' => []];
    }

    $tmp = (string) $file['tmp_name'];
    if (!is_uploaded_file($tmp)) {
        return ['ok' => false, 'error' => '非法的上传请求。', 'file' => []];
    }

    $size = (int) $file['size'];
    $limit = upload_limit_bytes();
    if ($size <= 0) {
        return ['ok' => false, 'error' => '不能上传空文件。', 'file' => []];
    }
    if ($size > $limit) {
        return ['ok' => false, 'error' => '文件大小超出限制，最大允许 ' . fmt_bytes($limit) . '。', 'file' => []];
    }

    $original = clean_filename((string) $file['name']);
    $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));

    if ($ext === '' || !preg_match('/^[a-z0-9]{1,16}$/', $ext)) {
        return ['ok' => false, 'error' => '文件缺少有效扩展名。', 'file' => []];
    }
    $allowed = allowed_extensions();
    if (!in_array($ext, $allowed, true) || in_array($ext, hard_blocked_extensions(), true)) {
        return ['ok' => false, 'error' => '不允许上传 .' . e($ext) . ' 类型的文件。', 'file' => []];
    }

    // 真实 MIME 检测，拒绝伪装成普通文件的脚本/可执行文件
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = (string) $finfo->file($tmp);
    $dangerous = [
        'text/x-php', 'application/x-php', 'application/x-httpd-php', 'application/x-httpd-php-source',
        'application/x-sh', 'application/x-shellscript', 'application/x-perl', 'application/x-python',
        'application/x-executable', 'application/x-dosexec', 'application/x-msdownload',
        'application/x-msdos-program', 'text/x-shellscript',
    ];
    if (in_array($mime, $dangerous, true)) {
        return ['ok' => false, 'error' => '检测到不安全的文件内容，已拒绝上传。', 'file' => []];
    }

    $imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
    if (in_array($ext, $imageExts, true)) {
        $info = @getimagesize($tmp);
        if ($info === false) {
            return ['ok' => false, 'error' => '图片文件已损坏或格式不正确。', 'file' => []];
        }
    }

    $sha = hash_file('sha256', $tmp);
    if ($sha === false) {
        return ['ok' => false, 'error' => '无法计算文件校验值。', 'file' => []];
    }

    $relativeDir = date('Y/m');
    $absDir = storage_root() . '/' . $relativeDir;
    if (!is_dir($absDir) && !@mkdir($absDir, 0750, true) && !is_dir($absDir)) {
        return ['ok' => false, 'error' => '无法创建存储目录，请检查 storage 权限。', 'file' => []];
    }

    $storedName = random_token(24) . '.dat';
    $relative   = $relativeDir . '/' . $storedName;
    $target     = $absDir . '/' . $storedName;

    if (!@move_uploaded_file($tmp, $target)) {
        return ['ok' => false, 'error' => '写入存储失败，请检查目录权限。', 'file' => []];
    }
    @chmod($target, 0640);

    $token = random_token(16);
    $title = trim($title) !== '' ? mb_substr(trim($title), 0, 200) : pathinfo($original, PATHINFO_FILENAME);
    $desc  = trim($description) !== '' ? mb_substr(trim($description), 0, 5000) : null;

    db_exec(
        'INSERT INTO files (token, title, description, original_name, stored_path, ext, mime, size, sha256,
            category_id, user_id, download_count, is_public, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 1, ?, ?)',
        [$token, $title, $desc, $original, $relative, $ext, $mime, $size, $sha,
            $categoryId ?: null, $userId, $isPublic ? 1 : 0, now(), now()]
    );

    $id = (int) db()->lastInsertId();
    audit('file_upload', $original, '大小 ' . fmt_bytes($size) . '，ID ' . $id);

    return ['ok' => true, 'error' => '', 'file' => [
        'id' => $id, 'token' => $token, 'title' => $title, 'original_name' => $original,
    ]];
}

/** 通过对外 token 查文件 */
function find_file_by_token(string $token): ?array
{
    if (!preg_match('/^[a-f0-9]{32}$/', $token)) {
        return null;
    }
    return db_one('SELECT * FROM files WHERE token = ? LIMIT 1', [$token]);
}

function file_abs_path(array $file): ?string
{
    return storage_abs((string) $file['stored_path']);
}

/** 删除文件及其物理副本、关联分享 */
function delete_file(int $fileId): bool
{
    $file = db_one('SELECT * FROM files WHERE id = ?', [$fileId]);
    if (!$file) {
        return false;
    }
    $abs = file_abs_path($file);
    if ($abs !== null && is_file($abs)) {
        @unlink($abs);
    }
    db_exec('DELETE FROM shares WHERE file_id = ?', [$fileId]);
    db_exec('DELETE FROM files WHERE id = ?', [$fileId]);
    audit('file_delete', (string) $file['original_name'], 'ID ' . $fileId);
    return true;
}

/** 分类列表 */
function categories_all(): array
{
    static $list = null;
    if ($list === null) {
        $list = db_all('SELECT * FROM categories ORDER BY sort ASC, id ASC');
    }
    return $list;
}

function category_name(?int $id): string
{
    if (!$id) {
        return '未分类';
    }
    foreach (categories_all() as $c) {
        if ((int) $c['id'] === $id) {
            return $c['name'];
        }
    }
    return '未分类';
}

/* ------------------------------ 分享链接 ------------------------------ */

function create_share(int $fileId, ?string $password, ?string $expiresAt, int $maxDownloads, ?int $userId): array
{
    $token = random_token(24);
    db_exec(
        'INSERT INTO shares (file_id, token, password_hash, expires_at, max_downloads, download_count, created_by, status, created_at)
         VALUES (?, ?, ?, ?, ?, 0, ?, 1, ?)',
        [
            $fileId,
            $token,
            $password !== null && $password !== '' ? password_hash($password, PASSWORD_DEFAULT) : null,
            $expiresAt,
            max(0, $maxDownloads),
            $userId,
            now(),
        ]
    );
    audit('share_create', '文件 ID ' . $fileId, '分享 ' . substr($token, 0, 8) . '...');
    return ['id' => (int) db()->lastInsertId(), 'token' => $token];
}

function find_share(string $token): ?array
{
    if (!preg_match('/^[a-f0-9]{48}$/', $token)) {
        return null;
    }
    return db_one(
        'SELECT s.*, f.title, f.original_name, f.ext, f.size, f.mime, f.token AS file_token, f.status AS file_status, f.is_public
         FROM shares s JOIN files f ON f.id = s.file_id
         WHERE s.token = ? LIMIT 1',
        [$token]
    );
}

/** 分享是否可用，返回错误文案或 null */
function share_error(array $share): ?string
{
    if ((int) $share['status'] !== 1) {
        return '该分享链接已被撤销。';
    }
    if ((int) $share['file_status'] !== 1) {
        return '分享的文件已下架。';
    }
    if (!empty($share['expires_at']) && strtotime((string) $share['expires_at']) < time()) {
        return '该分享链接已过期。';
    }
    if ((int) $share['max_downloads'] > 0 && (int) $share['download_count'] >= (int) $share['max_downloads']) {
        return '该分享链接的下载次数已用完。';
    }
    return null;
}

function share_is_unlocked(array $share): bool
{
    if (empty($share['password_hash'])) {
        return true;
    }
    return !empty($_SESSION['share_ok'][(int) $share['id']]);
}

/** 输出文件到浏览器（下载响应） */
function send_file_download(array $file): void
{
    $abs = file_abs_path($file);
    if ($abs === null || !is_file($abs)) {
        http_response_code(404);
        exit('文件不存在或已被移除。');
    }

    $size = (int) filesize($abs);
    $name = clean_filename((string) $file['original_name']);
    $ext  = strtolower((string) $file['ext']);
    $mime = mime_for_ext($ext);

    // 统一强制下载，并禁用 MIME 嗅探，避免浏览器内联执行
    $ascii = preg_replace('/[^\x20-\x7E]/', '_', $name) ?: 'download.' . $ext;
    $ascii = str_replace(['"', '\\'], '_', $ascii);
    $encoded = rawurlencode($name);

    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    ini_set('zlib.output_compression', '0');
    set_time_limit(0);

    header('Content-Type: ' . $mime);
    header('Content-Disposition: attachment; filename="' . $ascii . '"; filename*=UTF-8\'\'' . $encoded);
    header('Content-Length: ' . $size);
    header('Content-Transfer-Encoding: binary');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store, max-age=0');
    header('Pragma: no-cache');

    $fp = fopen($abs, 'rb');
    if ($fp === false) {
        http_response_code(500);
        exit('无法读取文件。');
    }
    while (!feof($fp)) {
        echo fread($fp, 262144);
        flush();
    }
    fclose($fp);
    exit;
}

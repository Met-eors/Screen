<?php
declare(strict_types=1);

/** 系统设置默认值 */
function setting_defaults(): array
{
    return [
        'site_name'            => '文件下载站',
        'site_tagline'         => '',
        'site_notice'          => '',
        'downloads_per_minute' => '5',
        'max_upload_mb'        => '100',
        'allow_user_upload'    => '1',
        'allow_register'       => '1',
        'require_login_download' => '0',
        'maintenance_mode'     => '0',
        'captcha_enabled'      => '1',
        'login_max_attempts'   => '5',
        'login_lock_minutes'   => '15',
        'allowed_extensions'   => 'zip,rar,7z,tar,gz,txt,md,pdf,doc,docx,xls,xlsx,ppt,pptx,csv,jpg,jpeg,png,gif,webp,bmp,mp3,wav,flac,mp4,mkv,mov,webm,apk,epub',
        'default_category'     => '1',
        'per_page'             => '12',

        // 防爬
        'antibot_enabled'       => '1',
        'antibot_block_empty_ua'=> '1',
        'antibot_ua_keywords'   => 'curl,wget,python-requests,python-urllib,scrapy,go-http-client,libwww,httpclient,okhttp,java/,node-fetch,axios,headlesschrome,phantomjs,selenium,puppeteer,bytespider,ahrefsbot,semrushbot',
        'antibot_page_limit'    => '150',
        'antibot_auto_ban'      => '1',
        'antibot_ban_minutes'   => '60',
        'antibot_honeypot'      => '1',
        'antibot_noindex'       => '0',

        // 用户上传
        'user_daily_uploads'    => '10',
        'user_storage_quota_mb' => '500',
        'upload_review'         => '0',
    ];
}

function settings_all(bool $fresh = false): array
{
    static $cache = null;
    if ($cache !== null && !$fresh) {
        return $cache;
    }
    $cache = setting_defaults();
    try {
        foreach (db_all('SELECT k, v FROM settings') as $row) {
            $cache[$row['k']] = $row['v'];
        }
    } catch (Throwable $e) {
        error_log('[settings] ' . $e->getMessage());
    }
    return $cache;
}

function setting(string $key, ?string $default = null): string
{
    $all = settings_all();
    return $all[$key] ?? ($default ?? '');
}

function setting_int(string $key, int $default = 0): int
{
    $v = setting($key, (string) $default);
    return is_numeric($v) ? (int) $v : $default;
}

function setting_bool(string $key): bool
{
    return setting($key) === '1';
}

function setting_set(string $key, string $value): void
{
    db_exec(
        'INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)',
        [$key, $value]
    );
}

/** 允许上传的扩展名数组 */
function allowed_extensions(): array
{
    $raw = strtolower(setting('allowed_extensions'));
    $list = array_filter(array_map('trim', explode(',', $raw)));
    return array_values(array_unique($list));
}

/** 系统级强制黑名单：无论后台如何配置都拒绝的执行类后缀 */
function hard_blocked_extensions(): array
{
    return [
        'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phar', 'phtml', 'pht', 'phps',
        'cgi', 'pl', 'py', 'rb', 'sh', 'bash', 'zsh', 'jsp', 'jspx', 'asp', 'aspx',
        'exe', 'dll', 'so', 'bat', 'cmd', 'com', 'msi', 'scr', 'vbs', 'js', 'jsx',
        'htaccess', 'htpasswd', 'ini', 'conf', 'sql', 'swp', 'shtml', 'shtm',
    ];
}

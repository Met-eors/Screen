<?php
declare(strict_types=1);

/** 是否信任反向代理传来的客户端 IP 头（默认关闭，开启需确保只有可信代理能访问源站） */
function trust_proxy(): bool
{
    return (bool) ($GLOBALS['config']['app']['trust_proxy'] ?? false);
}

/** HTML 转义，所有输出到页面的动态内容必须经过此函数 */
function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** 生成站内绝对地址 */
function base_url(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }

    $configured = trim((string) ($GLOBALS['config']['app']['url'] ?? ''));
    if ($configured !== '') {
        return $base = rtrim($configured, '/');
    }

    $https  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https' && trust_proxy());
    $scheme = $https ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir    = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    if (str_ends_with($dir, '/admin')) {
        $dir = substr($dir, 0, -6);
    }
    return $base = $scheme . '://' . $host . $dir;
}

function url(string $path = ''): string
{
    return base_url() . ($path === '' ? '' : '/' . ltrim($path, '/'));
}

function redirect(string $path, int $code = 302): never
{
    $to = preg_match('#^https?://#i', $path) ? $path : url($path);
    header('Location: ' . $to, true, $code);
    exit;
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

function random_token(int $bytes = 16): string
{
    return bin2hex(random_bytes($bytes));
}

function fmt_bytes(int $bytes, int $precision = 1): string
{
    if ($bytes <= 0) {
        return '0 B';
    }
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = (int) floor(log($bytes, 1024));
    $i = min($i, count($units) - 1);
    return round($bytes / (1024 ** $i), $precision) . ' ' . $units[$i];
}

function fmt_time(?string $dt, string $format = 'Y-m-d H:i'): string
{
    if (!$dt) {
        return '—';
    }
    $ts = strtotime($dt);
    return $ts ? date($format, $ts) : '—';
}

function fmt_ago(?string $dt): string
{
    if (!$dt) {
        return '—';
    }
    $ts = strtotime($dt);
    if (!$ts) {
        return '—';
    }
    $diff = time() - $ts;
    if ($diff < 60) {
        return '刚刚';
    }
    if ($diff < 3600) {
        return floor($diff / 60) . ' 分钟前';
    }
    if ($diff < 86400) {
        return floor($diff / 3600) . ' 小时前';
    }
    if ($diff < 2592000) {
        return floor($diff / 86400) . ' 天前';
    }
    return date('Y-m-d', $ts);
}

/** 一次性提示消息 */
function flash(string $type, string $message): void
{
    $_SESSION['_flash'][] = ['type' => $type, 'msg' => $message];
}

function take_flashes(): array
{
    $list = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $list;
}

function old(string $key, string $default = ''): string
{
    return (string) ($_SESSION['_old'][$key] ?? $default);
}

function keep_old(array $data): void
{
    $_SESSION['_old'] = $data;
}

function clear_old(): void
{
    unset($_SESSION['_old']);
}

/** 上一页地址（用于登录后跳回），仅允许站内相对路径 */
function safe_next(?string $next): string
{
    $next = (string) $next;
    if ($next === '' || $next[0] !== '/' || str_starts_with($next, '//') || str_contains($next, '\\')) {
        return '/index.php';
    }
    return $next;
}

/** 简洁的分页条 */
function render_pagination(int $page, int $total, int $perPage, array $query = []): string
{
    $pages = max(1, (int) ceil($total / $perPage));
    if ($pages <= 1) {
        return '';
    }
    $html = '<nav class="pagination" aria-label="分页">';
    $make = function (int $p, string $label, bool $disabled = false, bool $active = false) use ($query): string {
        $q = $query;
        $q['page'] = $p;
        $href = '?' . http_build_query($q);
        if ($disabled) {
            return '<span class="page-btn is-disabled">' . e($label) . '</span>';
        }
        $cls = $active ? 'page-btn is-active' : 'page-btn';
        return '<a class="' . $cls . '" href="' . e($href) . '">' . e($label) . '</a>';
    };

    $html .= $make($page - 1, '上一页', $page <= 1);
    $start = max(1, $page - 2);
    $end   = min($pages, $page + 2);
    if ($start > 1) {
        $html .= $make(1, '1');
        if ($start > 2) {
            $html .= '<span class="page-dots">...</span>';
        }
    }
    for ($i = $start; $i <= $end; $i++) {
        $html .= $make($i, (string) $i, false, $i === $page);
    }
    if ($end < $pages) {
        if ($end < $pages - 1) {
            $html .= '<span class="page-dots">...</span>';
        }
        $html .= $make($pages, (string) $pages);
    }
    $html .= $make($page + 1, '下一页', $page >= $pages);
    return $html . '</nav>';
}

/** 文件类型对应的显示色（用于图标底色） */
function ext_color(string $ext): string
{
    return match (strtolower($ext)) {
        'pdf'                          => 'red',
        'doc', 'docx'                  => 'blue',
        'xls', 'xlsx', 'csv'           => 'green',
        'ppt', 'pptx'                  => 'orange',
        'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg' => 'violet',
        'mp3', 'wav', 'flac', 'aac'    => 'pink',
        'mp4', 'mkv', 'mov', 'avi', 'webm' => 'cyan',
        'zip', 'rar', '7z', 'tar', 'gz' => 'amber',
        default                        => 'slate',
    };
}

/** 输出图标（纯 SVG，无第三方依赖，避免字符编码问题） */
function icon(string $name, int $size = 18): string
{
    $paths = [
        'download' => '<path d="M12 3v12m0 0l4-4m-4 4l-4-4"/><path d="M4 17v2a2 2 0 002 2h12a2 2 0 002-2v-2"/>',
        'upload'   => '<path d="M12 21V9m0 0l-4 4m4-4l4 4"/><path d="M4 7V5a2 2 0 012-2h12a2 2 0 012 2v2"/>',
        'file'     => '<path d="M14 3v5h5"/><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h9l5 5v11a2 2 0 01-2 2z"/>',
        'search'   => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
        'user'     => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/>',
        'shield'   => '<path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z"/><path d="M9 12l2 2 4-4"/>',
        'grid'     => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
        'users'    => '<circle cx="9" cy="8" r="3.5"/><path d="M2 21c0-3.5 3.1-5.5 7-5.5s7 2 7 5.5"/><path d="M16 4.2a3.5 3.5 0 010 6.6M18 21c0-2.2-.8-3.7-2-4.8"/>',
        'tag'      => '<path d="M20.6 13.4l-7.2 7.2a2 2 0 01-2.8 0l-7.2-7.2a2 2 0 01-.6-1.4V4a1 1 0 011-1h8a2 2 0 011.4.6l7.4 7.4a2 2 0 010 2.8z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
        'link'     => '<path d="M10 13a5 5 0 007 0l3-3a5 5 0 00-7-7l-1 1"/><path d="M14 11a5 5 0 00-7 0l-3 3a5 5 0 007 7l1-1"/>',
        'settings' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.9-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1A1.7 1.7 0 008.9 19a1.7 1.7 0 00-1.9.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.9 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1A1.7 1.7 0 005 8.9a1.7 1.7 0 00-.3-1.9l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.9.3H9.5a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.9-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.9v.1a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>',
        'list'     => '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
        'ban'      => '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>',
        'chart'    => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        'logout'   => '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
        'login'    => '<path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/><path d="M10 17l5-5-5-5M15 12H3"/>',
        'copy'     => '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>',
        'trash'    => '<path d="M3 6h18M8 6V4a1 1 0 011-1h6a1 1 0 011 1v2M19 6l-1 15a1 1 0 01-1 1H7a1 1 0 01-1-1L5 6"/>',
        'edit'     => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>',
        'plus'     => '<path d="M12 5v14M5 12h14"/>',
        'check'    => '<path d="M20 6L9 17l-5-5"/>',
        'close'    => '<path d="M18 6L6 18M6 6l12 12"/>',
        'arrow'    => '<path d="M5 12h14M13 6l6 6-6 6"/>',
        'clock'    => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'lock'     => '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/>',
        'database' => '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
        'home'     => '<path d="M3 10.5L12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/>',
    ];
    $d = $paths[$name] ?? $paths['file'];
    return '<svg class="ico" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>';
}

/** 简易摘要，按字符截断 */
function excerpt(?string $text, int $len = 100): string
{
    $text = trim((string) $text);
    if ($text === '') {
        return '';
    }
    if (mb_strlen($text) <= $len) {
        return $text;
    }
    return mb_substr($text, 0, $len) . '...';
}

/** 下载结果的中文文案 */
function download_result_label(string $result): string
{
    return match ($result) {
        'ok'       => '成功',
        'limited'  => '超限拦截',
        'password' => '密码错误',
        'denied'   => '拒绝访问',
        'banned'   => 'IP 封禁',
        default    => $result,
    };
}

function result_badge_class(string $result): string
{
    return match ($result) {
        'ok'       => 'badge-success',
        'limited'  => 'badge-warning',
        default    => 'badge-danger',
    };
}

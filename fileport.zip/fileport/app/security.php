<?php
declare(strict_types=1);

/**
 * 安全基础层：会话、响应头、CSRF、IP 封禁、限流、审计日志
 */

/** 获取真实客户端 IP（默认只信任 REMOTE_ADDR，避免伪造头绕过限流） */
function client_ip(): string
{
    $remote = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    if (trust_proxy()) {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $candidate = trim(explode(',', (string) $_SERVER[$key])[0]);
                if (filter_var($candidate, FILTER_VALIDATE_IP)) {
                    return $candidate;
                }
            }
        }
    }
    return filter_var($remote, FILTER_VALIDATE_IP) ? $remote : '0.0.0.0';
}

function start_secure_session(): void
{
    $cfg    = $GLOBALS['config']['session'];
    $secure = $cfg['secure'];
    if ($secure === null) {
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (($_SERVER['SERVER_PORT'] ?? '') === '443')
            || (trust_proxy() && ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    }

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.sid_length', '48');
    ini_set('session.sid_bits_per_character', '5');

    session_name($cfg['name']);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => (bool) $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();

    $now = time();
    $expired = false;
    if (isset($_SESSION['_last']) && $now - (int) $_SESSION['_last'] > (int) $cfg['lifetime']) {
        $expired = true;
    }
    if (isset($_SESSION['_start']) && $now - (int) $_SESSION['_start'] > (int) $cfg['absolute']) {
        $expired = true;
    }
    if ($expired) {
        $_SESSION = [];
        session_regenerate_id(true);
    }
    $_SESSION['_start'] ??= $now;
    $_SESSION['_last'] = $now;
}

function security_headers(): void
{
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=()');
    header('Cross-Origin-Opener-Policy: same-origin');
    header('X-XSS-Protection: 0');
    header("Content-Security-Policy: default-src 'self'; base-uri 'self'; form-action 'self'; "
        . "frame-ancestors 'none'; img-src 'self' data: blob:; object-src 'none'; "
        . "script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'");
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
    header_remove('X-Powered-By');
}

function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(): bool
{
    $token = $_POST['_csrf'] ?? '';
    $known = $_SESSION['_csrf'] ?? '';
    return is_string($token) && $token !== '' && $known !== '' && hash_equals($known, $token);
}

/** 全局 CSRF 强制校验：所有非 GET 请求必须携带有效令牌 */
function enforce_csrf(): void
{
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if (!in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        return;
    }

    // POST 体被 php.ini 丢弃（文件过大）时，给出明确提示而不是“令牌无效”
    if (empty($_POST) && empty($_FILES) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        http_response_code(413);
        header('Content-Type: text/html; charset=utf-8');
        exit('<meta charset="utf-8"><p style="font:16px/1.6 system-ui;padding:40px">提交的数据超过了服务器允许的大小，文件未上传。请检查 upload_max_filesize 与 post_max_size 配置。</p>');
    }

    if (!csrf_verify()) {
        http_response_code(419);
        header('Content-Type: text/html; charset=utf-8');
        exit('<meta charset="utf-8"><p style="font:16px/1.6 system-ui;padding:40px">请求校验失败（CSRF 令牌无效或已过期），请返回上一页刷新后重试。</p>');
    }
}

/** 判断 IP 是否匹配规则（支持单个 IP 与 CIDR 网段） */
function ip_matches(string $ip, string $rule): bool
{
    $rule = trim($rule);
    if ($rule === '') {
        return false;
    }
    if (!str_contains($rule, '/')) {
        return $rule === $ip;
    }
    [$subnet, $bits] = explode('/', $rule, 2);
    if (!filter_var($subnet, FILTER_VALIDATE_IP) || !ctype_digit($bits)) {
        return false;
    }
    $ipBin  = @inet_pton($ip);
    $subBin = @inet_pton($subnet);
    if ($ipBin === false || $subBin === false || strlen($ipBin) !== strlen($subBin)) {
        return false;
    }
    $max = strlen($ipBin) * 8;
    $bits = (int) $bits;
    if ($bits < 0 || $bits > $max) {
        return false;
    }
    $bytes = intdiv($bits, 8);
    $rem   = $bits % 8;
    if ($bytes > 0 && substr($ipBin, 0, $bytes) !== substr($subBin, 0, $bytes)) {
        return false;
    }
    if ($rem > 0) {
        $mask = (0xFF << (8 - $rem)) & 0xFF;
        if ((ord($ipBin[$bytes]) & $mask) !== (ord($subBin[$bytes]) & $mask)) {
            return false;
        }
    }
    return true;
}

/** 当前 IP 是否在封禁列表中 */
function is_ip_banned(?string $ip = null): ?array
{
    $ip = $ip ?? client_ip();
    foreach (db_all('SELECT * FROM ip_bans') as $row) {
        if (!ip_matches($ip, (string) $row['ip'])) {
            continue;
        }
        if ($row['expires_at'] !== null && strtotime((string) $row['expires_at']) < time()) {
            db_exec('DELETE FROM ip_bans WHERE id = ?', [$row['id']]);
            continue;
        }
        return $row;
    }
    return null;
}

function enforce_ip_ban(): void
{
    $ban = is_ip_banned();
    if (!$ban) {
        return;
    }
    http_response_code(403);
    $until = $ban['expires_at'] ? '解封时间：' . e(fmt_time((string) $ban['expires_at'])) : '该封禁为永久封禁。';
    $reason = $ban['reason'] ? e((string) $ban['reason']) : '触发访问风控策略';
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>访问受限</title>'
        . '<div style="max-width:520px;margin:15vh auto;font:15px/1.7 system-ui,-apple-system,\'PingFang SC\',sans-serif;color:#101828;padding:0 24px">'
        . '<h1 style="font-size:22px;margin:0 0 12px">访问受限</h1>'
        . '<p style="color:#475467">当前 IP 地址已被限制访问本站。</p>'
        . '<p style="color:#475467">原因：' . $reason . '<br>' . $until . '</p>'
        . '</div></html>';
    exit;
}

function enforce_maintenance(): void
{
    if (!setting_bool('maintenance_mode')) {
        return;
    }
    if (is_admin()) {
        return;
    }
    $script  = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    $isAdmin = str_contains((string) ($_SERVER['SCRIPT_NAME'] ?? ''), '/admin/');
    if ($isAdmin && in_array($script, ['login.php', 'index.php'], true)) {
        return;
    }

    http_response_code(503);
    header('Retry-After: 600');
    header('Content-Type: text/html; charset=utf-8');
    $name = e(setting('site_name'));
    echo '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>维护中 - ' . $name . '</title>'
        . '<div style="max-width:520px;margin:15vh auto;font:15px/1.7 system-ui,-apple-system,\'PingFang SC\',sans-serif;color:#101828;padding:0 24px">'
        . '<div style="font-size:12px;letter-spacing:.14em;color:#4f46e5;font-weight:600;margin-bottom:10px">MAINTENANCE</div>'
        . '<h1 style="font-size:24px;margin:0 0 10px">站点正在维护</h1>'
        . '<p style="color:#475467">我们正在升级服务，请稍后再来。管理员可以直接访问后台。</p>'
        . '<a href="' . e(url('/admin/login.php')) . '" style="display:inline-block;margin-top:18px;padding:9px 16px;border-radius:10px;background:#4f46e5;color:#fff;text-decoration:none;font-size:14px">管理员登录</a>'
        . '</div></html>';
    exit;
}

/** 记录一次限流事件 */
function rate_hit(string $action, ?string $ip = null): void
{
    $ip = $ip ?? client_ip();
    db_exec('INSERT INTO rate_hits (ip, action, created_at) VALUES (?, ?, ?)', [$ip, $action, now()]);
    if (random_int(1, 40) === 1) {
        db_exec('DELETE FROM rate_hits WHERE created_at < ?', [date('Y-m-d H:i:s', time() - 172800)]);
        db_exec('DELETE FROM download_logs WHERE created_at < ?', [date('Y-m-d H:i:s', time() - 7776000)]);
    }
}

/** 统计窗口内次数 */
function rate_count(string $action, int $windowSeconds, ?string $ip = null): int
{
    $ip  = $ip ?? client_ip();
    $since = date('Y-m-d H:i:s', time() - $windowSeconds);
    return (int) db_val(
        'SELECT COUNT(*) FROM rate_hits WHERE ip = ? AND action = ? AND created_at >= ?',
        [$ip, $action, $since],
        0
    );
}

/** 检查是否超限（不写入） */
function rate_exceeded(string $action, int $limit, int $windowSeconds, ?string $ip = null): bool
{
    return rate_count($action, $windowSeconds, $ip) >= $limit;
}

/** 审计日志 */
function audit(string $action, ?string $target = null, ?string $detail = null): void
{
    $user = function_exists('current_user') ? current_user() : null;
    db_exec(
        'INSERT INTO audit_logs (user_id, username, action, target, detail, ip, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [
            $user['id'] ?? null,
            $user['username'] ?? null,
            mb_substr($action, 0, 50),
            $target !== null ? mb_substr($target, 0, 120) : null,
            $detail !== null ? mb_substr($detail, 0, 500) : null,
            client_ip(),
            now(),
        ]
    );
}

/** 输出 JSON 并结束 */function json_out(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ------------------------------ 人机验证 ------------------------------ */

/** 生成或复用一道算术验证题，返回题目文本 */
function captcha_question(): string
{
    $data = $_SESSION['_captcha'] ?? null;
    if (is_array($data) && isset($data['text'], $data['answer'], $data['t'])
        && time() - (int) $data['t'] <= 600) {
        return (string) $data['text'];
    }
    $a = random_int(2, 9);
    $b = random_int(2, 9);
    $_SESSION['_captcha'] = ['answer' => $a + $b, 't' => time(), 'text' => $a . ' + ' . $b];
    return $a . ' + ' . $b;
}

/** 校验验证码（一次性，校验后立即失效） */
function captcha_check(mixed $input): bool
{
    $data = $_SESSION['_captcha'] ?? null;
    unset($_SESSION['_captcha']);
    if (!is_array($data) || time() - (int) ($data['t'] ?? 0) > 600) {
        return false;
    }
    return is_string($input) && ctype_digit(trim($input)) && (int) trim($input) === (int) $data['answer'];
}

<?php
/** 后台公共头部 */
$__admin  = current_user();
$__site   = setting('site_name');
$__title  = $adminTitle ?? '控制台';
$__navKey = $adminNav ?? 'dashboard';

$__items = [
    ['dashboard',  '/admin/index.php',      '仪表盘',   'chart'],
    ['files',      '/admin/files.php',      '文件管理', 'file'],
    ['categories', '/admin/categories.php', '分类管理', 'tag'],
    ['shares',     '/admin/shares.php',     '分享链接', 'link'],
    ['users',      '/admin/users.php',      '用户管理', 'users'],
    ['logs',       '/admin/logs.php',       '日志审计', 'list'],
    ['antibot',    '/admin/antibot.php',    '防爬',     'shield'],
    ['bans',       '/admin/bans.php',       'IP 封禁',  'ban'],
    ['settings',   '/admin/settings.php',   '系统设置', 'settings'],
];
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($__title) ?> · 后台 · <?= e($__site) ?></title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='8' fill='%23111827'/%3E%3Cpath d='M16 8v12m0 0l-4.5-4.5M16 20l4.5-4.5' stroke='white' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E">
<link rel="stylesheet" href="<?= e(url('/assets/css/app.css')) ?>">
</head>
<body class="admin-body">
<div class="admin-shell">
  <aside class="sidebar">
    <a class="sidebar-brand" href="<?= e(url('/admin/index.php')) ?>">
      <span class="brand-mark"><?= icon('download', 18) ?></span>
      <span>
        <strong><?= e($__site) ?></strong>
        <small>管理控制台</small>
      </span>
    </a>

    <nav class="sidebar-nav" aria-label="后台导航">
      <?php foreach ($__items as [$key, $path, $label, $ic]): ?>
        <a class="sidebar-link<?= $__navKey === $key ? ' is-active' : '' ?>" href="<?= e(url($path)) ?>">
          <?= icon($ic, 17) ?><span><?= e($label) ?></span>
        </a>
      <?php endforeach; ?>
    </nav>

    <div class="sidebar-foot">
      <a class="sidebar-link" href="<?= e(url('/index.php')) ?>"><?= icon('home', 17) ?><span>返回前台</span></a>
      <form action="<?= e(url('/logout.php')) ?>" method="post">
        <?= csrf_field() ?>
        <button type="submit" class="sidebar-link sidebar-button"><?= icon('logout', 17) ?><span>退出登录</span></button>
      </form>
    </div>
  </aside>

  <div class="admin-main">
    <header class="admin-topbar">
      <div class="admin-heading">
        <h1><?= e($__title) ?></h1>
        <?php if (!empty($adminSubtitle)): ?><p><?= e($adminSubtitle) ?></p><?php endif; ?>
      </div>
      <div class="admin-user">
        <span class="avatar avatar-sm"><?= e(mb_strtoupper(mb_substr((string) $__admin['username'], 0, 1))) ?></span>
        <span><?= e($__admin['username']) ?></span>
      </div>
    </header>

    <div class="admin-content">
      <?php foreach (take_flashes() as $__f): ?>
        <div class="alert alert-<?= e($__f['type']) ?>"><?= e($__f['msg']) ?></div>
      <?php endforeach; ?>

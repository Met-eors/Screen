</main>

<footer class="site-footer">
  <div class="container footer-inner">
    <div class="footer-brand"><?= e(setting('site_name')) ?></div>
  </div>
</footer>
<script src="<?= e(url('/assets/js/app.js')) ?>" defer></script>
</body>
</html>

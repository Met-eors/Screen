</main>

<footer class="site-footer">
  <div class="container footer-inner">
    <div class="footer-brand"><?= e(setting('site_name')) ?></div>
    <?php if (setting_bool('antibot_honeypot')): ?>
      <a class="hp-link" href="<?= e(url('/trap.php')) ?>" tabindex="-1" aria-hidden="true" rel="nofollow">站点地图</a>
    <?php endif; ?>
  </div>
</footer>
<script src="<?= e(url('/assets/js/app.js')) ?>" defer></script>
</body>
</html>

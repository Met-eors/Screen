</main>

<footer class="site-footer">
  <div class="container footer-inner">
    <div class="footer-brand"><?= e(setting('site_name')) ?></div>
    <?php if (setting_bool('antibot_honeypot')): ?>
      <div class="hp-zone" aria-hidden="true">
        <a class="hp-link" href="<?= e(url('/trap.php')) ?>" tabindex="-1" rel="nofollow"></a>
      </div>
    <?php endif; ?>
  </div>
</footer>
<script src="<?= e(url('/assets/js/app.js')) ?>" defer></script>
</body>
</html>

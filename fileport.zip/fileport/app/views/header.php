<?php
/** 前台公共头部 */
$__user  = current_user();
$__site  = setting('site_name');
$__title = $pageTitle ?? '文件库';
$__nav   = $activeNav ?? 'files';
$__notice = trim(setting('site_notice'));
$__desc   = trim(setting('site_tagline'));
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($__title) ?> · <?= e($__site) ?></title>
<meta name="description" content="<?= e($__desc !== '' ? $__desc : $__site) ?>">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='8' fill='%234f46e5'/%3E%3Cpath d='M16 8v12m0 0l-4.5-4.5M16 20l4.5-4.5' stroke='white' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E">
<link rel="stylesheet" href="<?= e(url('/assets/css/app.css')) ?>">
</head>
<body>
<header class="site-header">
  <div class="header-inner">
    <a class="brand" href="<?= e(url('/index.php')) ?>">
      <span class="brand-mark"><?= icon('download', 18) ?></span>
      <span class="brand-name"><?= e($__site) ?></span>
    </a>

    <nav class="nav" aria-label="主导航">
      <a class="nav-link<?= $__nav === 'files' ? ' is-active' : '' ?>" href="<?= e(url('/index.php')) ?>"><?= icon('grid', 16) ?><span>文件库</span></a>
      <?php if ($__user && (setting_bool('allow_user_upload') || is_admin())): ?>
        <a class="nav-link<?= $__nav === 'upload' ? ' is-active' : '' ?>" href="<?= e(url('/upload.php')) ?>"><?= icon('upload', 16) ?><span>上传</span></a>
      <?php endif; ?>
      <?php if ($__user): ?>
        <a class="nav-link<?= $__nav === 'account' ? ' is-active' : '' ?>" href="<?= e(url('/account.php')) ?>"><?= icon('user', 16) ?><span>我的</span></a>
      <?php endif; ?>
      <?php if (is_admin()): ?>
        <a class="nav-link" href="<?= e(url('/admin/index.php')) ?>"><?= icon('settings', 16) ?><span>后台</span></a>
      <?php endif; ?>
    </nav>

    <div class="header-right">
      <form class="search-mini" action="<?= e(url('/index.php')) ?>" method="get" role="search">
        <span class="search-mini-icon"><?= icon('search', 16) ?></span>
        <input type="search" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="搜索文件" maxlength="80" aria-label="搜索文件">
      </form>
      <?php if ($__user): ?>
        <div class="user-chip" title="<?= e($__user['username']) ?>">
          <span class="avatar"><?= e(mb_strtoupper(mb_substr($__user['username'], 0, 1))) ?></span>
          <span class="user-name"><?= e($__user['username']) ?></span>
        </div>
        <form action="<?= e(url('/logout.php')) ?>" method="post" class="inline-form">
          <?= csrf_field() ?>
          <button type="submit" class="btn btn-ghost btn-sm">退出</button>
        </form>
      <?php else: ?>
        <a class="btn btn-ghost btn-sm" href="<?= e(url('/login.php')) ?>">登录</a>
        <?php if (setting_bool('allow_register')): ?>
          <a class="btn btn-primary btn-sm" href="<?= e(url('/register.php')) ?>">注册</a>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</header>

<?php if ($__notice !== ''): ?>
  <div class="notice-bar"><div class="container notice-inner"><?= e($__notice) ?></div></div>
<?php endif; ?>

<main class="container page">
<?php foreach (take_flashes() as $__f): ?>
  <div class="alert alert-<?= e($__f['type']) ?>"><?= e($__f['msg']) ?></div>
<?php endforeach; ?>

<?php
/**
 * 应用配置
 * 生产环境请通过 install.php 生成 config.local.php，或手动复制本文件为 config.local.php 后修改。
 */
declare(strict_types=1);

$config = [
    'db' => [
        'host'    => getenv('DB_HOST') ?: '127.0.0.1',
        'port'    => (int) (getenv('DB_PORT') ?: 3306),
        'name'    => getenv('DB_NAME') ?: 'fileport',
        'user'    => getenv('DB_USER') ?: 'root',
        'pass'    => getenv('DB_PASS') !== false ? getenv('DB_PASS') : '',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'name'     => 'FilePort',
        'timezone' => 'Asia/Shanghai',
        'debug'    => false,
        'key'      => 'change-this-to-a-random-64-char-string-before-production-use-0000',
    ],
    'paths' => [
        'storage' => dirname(__DIR__) . '/storage/files',
    ],
    'session' => [
        'name'     => 'fp_sid',
        'lifetime' => 7200,   // 空闲超时（秒）
        'absolute' => 43200,  // 绝对超时（秒）
        'secure'   => null,   // null = 自动判断 HTTPS
    ],
];

$local = __DIR__ . '/config.local.php';
if (is_file($local)) {
    /** @var array $override */
    $override = require $local;
    if (is_array($override)) {
        $config = array_replace_recursive($config, $override);
    }
}

return $config;

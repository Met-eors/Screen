<?php
declare(strict_types=1);

/** 当前登录用户（带静态缓存） */
function current_user(bool $refresh = false): ?array
{
    static $user = null;
    static $loaded = false;
    if ($loaded && !$refresh) {
        return $user;
    }
    $loaded = true;
    $user = null;

    $id = (int) ($_SESSION['uid'] ?? 0);
    if ($id > 0) {
        $row = db_one('SELECT * FROM users WHERE id = ? LIMIT 1', [$id]);
        if ($row && (int) $row['status'] === 1) {
            $user = $row;
        } else {
            unset($_SESSION['uid']);
        }
    }
    return $user;
}

function is_admin(): bool
{
    $u = current_user();
    return $u !== null && $u['role'] === 'admin';
}

/**
 * 判断某用户当前能否上传文件。
 * 管理员始终可以；普通用户先看个人权限（users.can_upload），
 * 未单独设置时跟随全站开关 allow_user_upload。
 */
function user_can_upload(?array $user = null): bool
{
    $user = $user ?? current_user();
    if ($user === null) {
        return false;
    }
    if (($user['role'] ?? '') === 'admin') {
        return true;
    }
    if (array_key_exists('can_upload', $user) && $user['can_upload'] !== null && $user['can_upload'] !== '') {
        return (int) $user['can_upload'] === 1;
    }
    return setting_bool('allow_user_upload');
}

/** 用户上传权限的三种状态标注：follow / allow / deny */
function upload_perm_state(?array $user): string
{
    if ($user === null) {
        return 'follow';
    }
    if (!array_key_exists('can_upload', $user) || $user['can_upload'] === null || $user['can_upload'] === '') {
        return 'follow';
    }
    return (int) $user['can_upload'] === 1 ? 'allow' : 'deny';
}

function require_login(): array
{
    $u = current_user();
    if ($u === null) {
        $next = $_SERVER['REQUEST_URI'] ?? '/';
        redirect('/login.php?next=' . urlencode($next));
    }
    return $u;
}

function require_admin(): array
{
    $u = current_user();
    if ($u === null) {
        redirect('/admin/login.php?next=' . urlencode($_SERVER['REQUEST_URI'] ?? '/admin/index.php'));
    }
    if ($u['role'] !== 'admin') {
        http_response_code(403);
        exit('无权访问：需要管理员权限。');
    }
    return $u;
}

/** 密码强度校验，返回错误信息或 null */
function password_policy(string $password): ?string
{
    if (strlen($password) < 8) {
        return '密码至少需要 8 个字符。';
    }
    if (strlen($password) > 72) {
        return '密码不能超过 72 个字符。';
    }
    if (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        return '密码需要同时包含字母和数字。';
    }
    return null;
}

/**
 * 登录。返回 [bool $ok, string $error]
 */
function attempt_login(string $login, string $password): array
{
    $login = trim($login);
    if ($login === '' || $password === '') {
        return [false, '请输入账号和密码。'];
    }

    if (rate_exceeded('login', 12, 60)) {
        return [false, '尝试过于频繁，请等待一分钟后再试。'];
    }
    rate_hit('login');

    $user = db_one(
        'SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1',
        [$login, $login]
    );

    if (!$user) {
        // 恒定时间比较，避免通过响应时间枚举账号
        password_verify($password, '$2y$10$usesomesillystringfore7hnbRJHxXVLeakoG8K30oukPsA.ztMG');
        audit('login_failed', $login, '账号不存在');
        return [false, '账号或密码不正确。'];
    }

    if (!empty($user['locked_until']) && strtotime((string) $user['locked_until']) > time()) {
        audit('login_locked', $login, '账号处于锁定期');
        return [false, '登录失败次数过多，账号已临时锁定，请稍后再试。'];
    }

    if (!password_verify($password, (string) $user['password_hash'])) {
        $max   = max(3, setting_int('login_max_attempts', 5));
        $fails = (int) $user['failed_attempts'] + 1;
        if ($fails >= $max) {
            $lockUntil = date('Y-m-d H:i:s', time() + max(1, setting_int('login_lock_minutes', 15)) * 60);
            db_exec('UPDATE users SET failed_attempts = 0, locked_until = ? WHERE id = ?', [$lockUntil, $user['id']]);
            audit('login_lock', $user['username'], '连续失败触发锁定');
            return [false, '登录失败次数过多，账号已锁定 ' . setting_int('login_lock_minutes', 15) . ' 分钟。'];
        }
        db_exec('UPDATE users SET failed_attempts = ? WHERE id = ?', [$fails, $user['id']]);
        audit('login_failed', $user['username'], '密码错误');
        return [false, '账号或密码不正确。'];
    }

    if ((int) $user['status'] !== 1) {
        audit('login_denied', $user['username'], '账号被禁用');
        return [false, '该账号已被禁用，请联系管理员。'];
    }

    // 密码升级（算法或参数变更时自动重算）
    if (password_needs_rehash((string) $user['password_hash'], PASSWORD_DEFAULT)) {
        db_exec('UPDATE users SET password_hash = ? WHERE id = ?', [
            password_hash($password, PASSWORD_DEFAULT),
            $user['id'],
        ]);
    }

    session_regenerate_id(true);
    $_SESSION['uid'] = (int) $user['id'];
    $_SESSION['_last'] = time();
    unset($_SESSION['_csrf']);

    db_exec(
        'UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = ?, last_login_ip = ? WHERE id = ?',
        [now(), client_ip(), $user['id']]
    );
    audit('login_success', $user['username'], '角色：' . $user['role']);
    current_user(true);

    return [true, ''];
}

/** 注册新用户，返回 [bool, string 错误信息] */
function register_user(string $username, string $email, string $password): array
{
    if (rate_exceeded('register', 6, 3600)) {
        return [false, '当前网络注册次数已达上限，请稍后再试。'];
    }
    rate_hit('register');

    if (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $username)) {
        return [false, '用户名需为 3-20 位字母、数字或下划线。'];
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
        return [false, '请输入有效的邮箱地址。'];
    }
    $pwdError = password_policy($password);
    if ($pwdError !== null) {
        return [false, $pwdError];
    }
    if (db_val('SELECT COUNT(*) FROM users WHERE username = ?', [$username], 0) > 0) {
        return [false, '该用户名已被占用。'];
    }
    if (db_val('SELECT COUNT(*) FROM users WHERE email = ?', [$email], 0) > 0) {
        return [false, '该邮箱已被注册。'];
    }

    try {
        db_exec(
            'INSERT INTO users (username, email, password_hash, role, status, created_at) VALUES (?, ?, ?, ?, 1, ?)',
            [$username, $email, password_hash($password, PASSWORD_DEFAULT), 'user', now()]
        );
    } catch (PDOException $e) {
        error_log('[register] ' . $e->getMessage());
        return [false, '注册失败，请稍后重试。'];
    }

    $uid = (int) db()->lastInsertId();
    session_regenerate_id(true);
    $_SESSION['uid'] = $uid;
    unset($_SESSION['_csrf']);
    audit('register', $username, '新用户注册');
    current_user(true);

    return [true, ''];
}

function logout_user(): void
{
    $u = current_user();
    if ($u) {
        audit('logout', $u['username'], null);
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $p['path'],
            'domain'   => $p['domain'],
            'secure'   => $p['secure'],
            'httponly' => $p['httponly'],
            'samesite' => 'Lax',
        ]);
    }
    session_destroy();
}

<?php
declare(strict_types=1);

/**
 * 防爬层
 * 1. User-Agent 特征拦截（空 UA、脚本/采集器关键字）
 * 2. 单 IP 页面访问频率限制
 * 3. 蜜罐链接：空文本、移出视口、禁用点击，正常用户不可见不可点，被访问即视为采集行为
 * 4. 自动封禁：同一 IP 短时间内多次触发则写入封禁表
 *
 * 后台目录与已登录管理员不受这些规则影响，避免误伤运维操作。
 */

/** 解析 UA 关键字列表（逗号、空格、分号均可分隔） */
function antibot_keywords(): array
{
    $raw = (string) setting('antibot_ua_keywords');
    $out = [];
    foreach (preg_split('/[\s,，;；]+/u', $raw) ?: [] as $kw) {
        $kw = strtolower(trim($kw));
        if ($kw !== '' && mb_strlen($kw) <= 40) {
            $out[$kw] = true;
        }
    }
    return array_keys($out);
}

/** 判断 UA 是否应被拦截，返回原因码或 null */
function antibot_ua_reason(string $ua): ?string
{
    $ua = strtolower(trim($ua));
    if ($ua === '') {
        return setting_bool('antibot_block_empty_ua') ? 'empty_ua' : null;
    }
    foreach (antibot_keywords() as $kw) {
        if (str_contains($ua, $kw)) {
            return 'ua_keyword';
        }
    }
    return null;
}

/** UA 原因的中文文案 */
function antibot_reason_label(string $reason): string
{
    return match ($reason) {
        'empty_ua'   => '空 User-Agent',
        'ua_keyword' => '采集器特征',
        'page_rate'  => '页面请求超频',
        'honeypot'   => '触发蜜罐',
        'manual'     => '手动标记',
        default      => $reason,
    };
}

/** 写入一条拦截记录（失败不影响主流程） */
function antibot_log(string $reason, ?string $path = null): void
{
    try {
        db_exec(
            'INSERT INTO crawler_hits (ip, user_agent, reason, path, created_at) VALUES (?, ?, ?, ?, ?)',
            [
                client_ip(),
                mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
                mb_substr($reason, 0, 32),
                $path !== null ? mb_substr($path, 0, 255) : null,
                now(),
            ]
        );
        if (random_int(1, 50) === 1) {
            db_exec('DELETE FROM crawler_hits WHERE created_at < ?', [date('Y-m-d H:i:s', time() - 2592000)]);
        }
    } catch (Throwable $e) {
        error_log('[antibot] ' . $e->getMessage());
    }
}

/** 封禁当前 IP（分钟数 <= 0 表示永久） */
function antibot_ban_current(string $reason, int $minutes): void
{
    $ip = client_ip();
    $expires = $minutes > 0 ? date('Y-m-d H:i:s', time() + $minutes * 60) : null;
    $text = '防爬规则：' . antibot_reason_label($reason);

    try {
        $existing = db_one('SELECT id FROM ip_bans WHERE ip = ?', [$ip]);
        if ($existing) {
            db_exec(
                'UPDATE ip_bans SET reason = ?, expires_at = ?, created_at = ? WHERE id = ?',
                [$text, $expires, now(), $existing['id']]
            );
        } else {
            db_exec(
                'INSERT INTO ip_bans (ip, reason, expires_at, created_by, created_at) VALUES (?, ?, ?, NULL, ?)',
                [$ip, $text, $expires, now()]
            );
        }
        audit('antibot_ban', $ip, antibot_reason_label($reason));
    } catch (Throwable $e) {
        error_log('[antibot] ban failed: ' . $e->getMessage());
    }
}

/** 同一 IP 在时间窗内的拦截次数 */
function antibot_hit_count(string $ip, int $seconds): int
{
    try {
        return (int) db_val(
            'SELECT COUNT(*) FROM crawler_hits WHERE ip = ? AND created_at >= ?',
            [$ip, date('Y-m-d H:i:s', time() - $seconds)],
            0
        );
    } catch (Throwable $e) {
        return 0;
    }
}

/** 达到阈值则自动封禁 */
function antibot_auto_ban(string $reason): void
{
    if (!setting_bool('antibot_auto_ban')) {
        return;
    }
    $hits = antibot_hit_count(client_ip(), 600);
    if ($hits < 5) {
        return;
    }
    // 已被封禁就不重复写
    if (is_ip_banned() !== null) {
        return;
    }
    antibot_ban_current($reason, max(1, setting_int('antibot_ban_minutes', 60)));
}

/** 输出拦截页并结束 */
function antibot_deny(int $status, string $title, string $message): never
{
    http_response_code($status);
    if ($status === 429) {
        header('Retry-After: 60');
    }
    header('Content-Type: text/html; charset=utf-8');
    $name = e(setting('site_name'));
    echo '<!doctype html><html lang="zh-CN"><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . e($title) . ' - ' . $name . '</title>'
        . '<div style="max-width:520px;margin:16vh auto;font:15px/1.7 system-ui,-apple-system,\'PingFang SC\',sans-serif;color:#101828;padding:0 24px">'
        . '<h1 style="font-size:21px;margin:0 0 10px">' . e($title) . '</h1>'
        . '<p style="color:#475467;margin:0">' . e($message) . '</p>'
        . '<p style="color:#98a2b3;font-size:13px;margin-top:18px">' . $name . '</p>'
        . '</div></html>';
    exit;
}

/** 中间件入口 */
function antibot_guard(): void
{
    if (PHP_SAPI === 'cli' || !setting_bool('antibot_enabled')) {
        return;
    }

    $script = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
    // 后台不做频率限制，避免管理员被自己的操作误伤
    if (str_contains($script, '/admin/')) {
        return;
    }
    if (function_exists('is_admin') && is_admin()) {
        return;
    }

    $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
    $reason = antibot_ua_reason($ua);
    if ($reason !== null) {
        antibot_log($reason, $script);
        antibot_auto_ban($reason);
        antibot_deny(403, '访问被拒绝', '当前客户端不符合本站的访问要求。若使用浏览器正常访问仍看到此页，请更换浏览器或联系管理员。');
    }

    $limit = setting_int('antibot_page_limit', 0);
    if ($limit > 0 && strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'GET') {
        $recent = rate_count('page', 60);
        if ($recent >= $limit) {
            antibot_log('page_rate', $script);
            if ($recent >= $limit * 2) {
                antibot_auto_ban('page_rate');
            }
            antibot_deny(429, '请求过于频繁', '当前网络在一分钟内的页面请求次数过多，请稍后重试。');
        }
        rate_hit('page');
    }
}

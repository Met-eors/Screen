<?php
/**
 * 应用引导：常量、配置、错误处理、数据库、会话、安全响应头
 */
declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));
define('APP_PATH', __DIR__);
define('PUBLIC_PATH', APP_ROOT . '/public');

/** @var array $config */
$config = require __DIR__ . '/config.php';
$GLOBALS['config'] = $config;

date_default_timezone_set($config['app']['timezone']);
mb_internal_encoding('UTF-8');

error_reporting(E_ALL);
ini_set('display_errors', $config['app']['debug'] ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', APP_ROOT . '/storage/php-error.log');

require __DIR__ . '/db.php';
require __DIR__ . '/helpers.php';
require __DIR__ . '/settings.php';
require __DIR__ . '/security.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/files.php';

if (!is_dir(APP_ROOT . '/storage')) {
    @mkdir(APP_ROOT . '/storage', 0755, true);
}

// 会话（CLI 环境下跳过）
if (PHP_SAPI !== 'cli') {
    start_secure_session();
    security_headers();
    enforce_ip_ban();
    enforce_maintenance();
    enforce_csrf();
}
